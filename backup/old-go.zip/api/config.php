<?php

// Settings
define('DEBUG', 1);
define('HTTP_HOST', 'http://xn--grntoverblik-wjb.dk/');

// Slugs
define('DGS_SLUG', 'dgs/side/');
define('DGB_SLUG', 'publikation/');

// DB credentials
define('DB_STATUS', 1);
define('DB_TYPE', 'mysql');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'xn--grntoverblik-wjb.dk');
define('DB_USER', 'root');
define('DB_PASS', 'mysql');
define('DB_PREFIX', 'wp_');



