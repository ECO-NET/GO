<form method="post" action="api">
<input id="url" type="url" name="url">
<input type="submit" id="txt">
</form>
