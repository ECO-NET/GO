<?php

// Models
$container['Post'] = function($container) {

	return new App\Models\Post;

};

$container['PostMeta'] = function($container) {

	return new App\Models\PostMeta;

};

$container['Term'] = function($container) {

	return new App\Models\Term;

};

$container['TermTaxonomy'] = function($container) {

	return new App\Models\TermTaxonomy;

};

$container['TermRelationship'] = function($container) {

	return new App\Models\TermRelationship;

};

$container['Option'] = function($container) {

	return new App\Models\Option;

};

$container['W2dcLocationRelationship'] = function($container) {

	return new App\Models\W2dcLocationRelationship;

};

$container['W2dcLevelRelationship'] = function($container) {

	return new App\Models\W2dcLevelRelationship;

};

$container['Link'] = function($container) {

	return new App\Models\Link;

};

$container['Crawler'] = function($container) {

	return new App\Models\Crawler;

};