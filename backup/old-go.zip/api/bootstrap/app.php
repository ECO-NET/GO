<?php

session_start();

require 'config.php';

// Enable or disable errors
ini_set('display_errors', DEBUG);
ini_set('max_execution_time', 300);

require 'vendor/autoload.php';

$app = new \Slim\App([

	'settings' => [

		'displayErrorDetails' => TRUE,

		'db' => [

			'driver' => DB_TYPE,
			'host' => DB_HOST,
			'database' => DB_NAME,
			'username' => DB_USER,
			'password' => DB_PASS,
			'charset' => 'utf8',
			'collation' => 'utf8_unicode_ci',
			'prefix' => DB_PREFIX,

		]

	]

]);

$container = $app->getContainer();


$container['view'] = function($container) {

	$view = new \Slim\Views\Twig('resources/views', [

		//'cache' => true,

	]);

	$view->addExtension(new \Slim\Views\TwigExtension(

		$container->router,

		$container->request->getUri()

	));

	return $view;

};


$capsule = new \Illuminate\Database\Capsule\Manager;

$capsule->addConnection($container['settings']['db']);

$capsule->setAsGlobal();

$capsule->bootEloquent();

$container['db'] = function($container) use ($capsule) {

	return $capsule;

};

require 'container.php';

require 'functions.php';

require 'app/routes.php';


