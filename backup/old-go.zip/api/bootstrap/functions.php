<?php

// Wordpress functions
require_once '../wp/wp-load.php';


// Custom functions

function getCoordinates($address, $timeout = 10)
{

trim($address);
$address = str_replace(" ", "+", $address); // replace all the white space with "+" sign to match with google search pattern

$url = "http://maps.google.com/maps/api/geocode/json?sensor=false&address=$address";

$opts = array('http' =>
    array(
        'method'  => 'GET',
        'timeout' => $timeout
    )
);

$context  = stream_context_create($opts);

$response = file_get_contents($url, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

$json = json_decode($response,TRUE); //generate array object from the response from the web

$data = $json['results'][0]['geometry']['location']['lat'].",".$json['results'][0]['geometry']['location']['lng'];

return explode(',', $data);

}

function getDkCommune($zip, $timeout = 10)
{

  trim($zip);
  $request = "https://api.websupport.dk/dk/zipcode/$zip";

  $opts = array('http' =>
      array(
          'method'  => 'GET',
          'timeout' => $timeout
      )
  );

  $context  = stream_context_create($opts);

  $response = file_get_contents($request, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

  $data = json_decode($response, true);

  return $data['commune_name'];

}


function getDkRegion($zip, $timeout = 10)
{

  trim($zip);
  $request = "https://api.websupport.dk/dk/zipcode/$zip";
  $opts = array('http' =>
      array(
          'method'  => 'GET',
          'timeout' => $timeout
      )
  );

  $context  = stream_context_create($opts);

  $response = file_get_contents($request, false, $context);

  if(empty($response))
  {
    return FALSE;
  }

  $data = json_decode($response, true);

  return $data['region_name'];
}

function get_random_username($chars, $length = 12) {
  $validCharacters = $chars . '12345abcdefghijklmnopqrstuvwxyz678910';
  $validCharNumber = strlen($validCharacters);
  $result = '';
  for ($i = 0; $i < $length; $i++) {
    $index = mt_rand(0, $validCharNumber - 1);
    $result .= $validCharacters[$index];
  }
  return $result;
}

