<?php

// Test
$app->get('/test', function($request, $response){

    return $this->view->render($response, 'index.html');

});


$app->get('/test/crawler', function($request,$response){
    return $this->view->render($response, 'crawler.twig', ['crawler' => new \App\Models\Crawler]);
});


// API's
$app->get('/crawl/dgs', function($request, $response){

    $next_file = 'resources/storage/dgs/next.php';
	$cat_file = 'resources/storage/dgs/catlist.php';

	$Crawler = $this->Crawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGS-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	    }

	    $catlist = unserialize(file_get_contents($cat_file));

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


$app->get('/crawl/dgb', function($request, $response){

	$next_file = 'resources/storage/dgb/next.php';
	$cat_file = 'resources/storage/dgb/catlist.php';

	$Crawler = $this->Crawler;
	$next = false;

	if(file_exists($next_file))
	{
		$next = file_get_contents($next_file);
	}

	if(!empty($next))
	{

		$Crawler->setURL($next);
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}

	} else {
        
        if(filesize($cat_file) < 5){
		error_log(date('Y-m-d H:i:s') . " DGB-crawl done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	    }

	    $catlist = unserialize(file_get_contents($cat_file));

		$Crawler->setURL(reset($catlist));
		$Crawler->run();

		if($Crawler->next_url)
		{
			file_put_contents($next_file, $Crawler->next_url);
		}
	}


	if($Crawler->done)
	{

	reset($catlist);
	$key = key($catlist);
	unset($catlist[$key]);

	file_put_contents($cat_file, serialize($catlist));

	unlink($next_file);

	}

	echo 'OK';


});


// Create dgs pages
$app->get('/create/dgs', function($request, $response, $args) {

	$link = $this->Link
	->where('link_type', 'dgs')
	->where('link_post_id', 0)
	->where('link_done',0)
	->where('link_error',0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/dgs/vars.php';

		require 'includes/dgs/html.php';

		require 'includes/dgs/api.php';

		require 'includes/dgs/data.php';

		require 'includes/dgs/sql.php';

		require 'includes/dgs/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " DGS-creation done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});


// Create dgb pages
$app->get('/create/dgb', function($request, $response, $args) {

	$link = $this->Link
	->where('link_type', 'dgb')
	->where('link_post_id', 0)
	->where('link_done',0)
	->where('link_error',0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/dgb/vars.php';

		require 'includes/dgb/html.php';

		require 'includes/dgb/data.php';

		require 'includes/dgb/sql.php';

		require 'includes/dgb/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " DGB-creation done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});


// Link dgs and dgs together
$app->get('/link', function($request, $response, $args) {

	$link = $this->Link
	->where('link_rel', 1)
	->where('link_done', 0)
	->where('link_error', 0)
	->where('link_post_id', '>', 0)
	->first();

	if(!empty($link)){

		$url = $link->link_url;

		require 'includes/link/html.php';
		require 'includes/link/sql.php';
		require 'includes/link/terminate.php';

	} else {
		error_log(date('Y-m-d H:i:s') . " Linking done!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
        return die('STOP');
	}

	echo 'OK';

});
