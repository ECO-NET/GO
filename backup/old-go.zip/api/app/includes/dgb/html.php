<?php

// Create DOM from URL or file

$html = file_get_html($link->link_url);

if(!$html){
	$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
	error_log("API ERROR: Timeout or failed to get html from ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
	die('API ERROR! See log for details.');
}

//
$post_title = trim($html->find('td.contentHeader1', 1)->plaintext);
$post_name = sanitize_title($post_title);

// Find content from html and look for rel link

if(!empty($html->find('a[title="Viser denne publikation"]'))){

	$this->Link
	->where('link_id', $link->link_id)
	->update(['link_rel' => 1]);
	
} else {

	$post_content = $html->find('p',2)->outertext . '<br><br><h3>Fakta</h3>';	

	// Find info
	$fakta = $html->find('span.faktaboksheader');

	foreach($fakta as $info)
	{
		$raw_fakta[] = $info->parent;
	}

	$fakta = $raw_fakta[0]->outertext;


	$fakta = strip_tags($fakta, '<br><a><span>');
	$fakta = str_replace('<span class="faktaboksheader">', '<b>', $fakta);
	$fakta = str_replace('</span>', '</b>', $fakta);

	$post_content = $post_content . $fakta;

	$this->Link
	->where('link_id', $link->link_id)
	->update(['link_done' => 1]);
}


// Find categories from html
foreach ($html->find('a[title="Finder publikationer i denne kategori"]') as $category) {
	$categories[] = $category->plaintext;
}

// Find tags from html
foreach ($html->find('a[title="Finder publikationer tilknyttet dette emne"]') as $tag) {
	$tags[] = $tag->plaintext;
}


