<?php

// Create DOM from URL or file

$html = file_get_html($link->link_url);

if(!$html){
	$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
	error_log("API ERROR: Timeout or failed to get html from ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
	die('API ERROR! See log for details.');
}


// DGS

if($link->link_type == 'dgs') 
{

	$content = $html->find('p',3)->outertext . '<br><b>I Det Grønne Bibliotek:</b><br>';

	foreach($html->find('a[title="Viser denne publikation"]') as $t) {

		$title = $t->plaintext;

		$post = $this->Post->where('post_title', $title)->first();

		if(!empty($post))
		{

			$href = HTTP_HOST . DGS_SLUG . $post->post_name;

			$dgs[] = "<a href='$href' title='Viser denne publikation'>$title</a>";

		} else {
			$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
			error_log("API ERROR: Missing '$url'!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
			die('API ERROR! See log for details.');
		}

	}

	$dgs = implode('<br>', $dgs);

	$post_content = $content . $dgs;
} 


// DGB
if($link->link_type == 'dgb') 
{
	$content = $html->find('p',2)->outertext . '<br><b>I De Grønne Sider</b><br>';

	foreach ($html->find('a[title="Viser denne organisation"]') as $t) {

		$title = $t->plaintext;

		$post = $this->Post->where('post_title', $title)->first();

		if(!empty($post))
		{

			$href = HTTP_HOST . DGB_SLUG . $post->post_name;
		
			$dgs[] = "<a href='$href' title='Viser denne organisation'>$title</a>";

		} else {
			$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
			error_log("API ERROR: Missing '$url'!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
			die('API ERROR! See log for details.');
		}
	}

	$dgs = implode('<br>', $dgs);

	$combined_content = $content . $dgs . '<br><br><h3>Fakta</h3>';

	// Find info
	$fakta = $html->find('span.faktaboksheader');

	foreach($fakta as $info)
	{
		$raw_fakta[] = $info->parent;
	}

	$fakta = $raw_fakta[0]->outertext;


	$fakta = strip_tags($fakta, '<br><a><span>');
	$fakta = str_replace('<span class="faktaboksheader">', '<b>', $fakta);
	$fakta = str_replace('</span>', '</b>', $fakta);

	$post_content = $combined_content . $fakta;
}