<?php

if(DB_STATUS){

	// Get taxonomies

	// Categories
	$category_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'w2dc-category')->get();

	foreach ($category_taxonomies as $taxonomy) 
	{

		if (in_array($taxonomy['term']->name, $data['categories'])) {
			$category_ids[] = $taxonomy['term']->term_id;
		}
	}

	foreach ($category_ids as $taxonomy) 
	{
		$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
	}


	// Tags

	$tags_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'w2dc-tag')->get();

	foreach ($tags_taxonomies as $taxonomy) 
	{

		if (in_array($taxonomy['term']->name, $data['tags'])) {
			$tag_ids[] = $taxonomy['term']->term_id;
		}
	}

	foreach ($tag_ids as $taxonomy) 
	{
		$this->TermTaxonomy->where('term_id', '=', $taxonomy)->update(['count' => +1]);
	}


	$location_taxonomies = $this->TermTaxonomy->with('term')->where('taxonomy', '=', 'w2dc-location')->get();

	foreach ($location_taxonomies as $taxonomy) 
	{

		if ($taxonomy['term']->name == $data['city']) {
			$location_id = $taxonomy['term']->term_id;
			$this->TermTaxonomy->where('term_id', '=', $location_id)->update(['count' => +1]);
		}

	}

	if(empty($tag_ids) || empty($category_ids) || empty($location_id))
	{
		$this->Link->where('link_id',$link->link_id)->update(['link_error' => 1]);
		error_log("API ERROR: Taxonomy info missing for '$post_title' ($url)!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
		die('API ERROR! See log for details.');

	}


	// Merge taxonomies
	$taxonomies = array_merge_recursive($category_ids, $tag_ids, array($location_id));

	if(!empty($data['email']))
	{	

	$user_id = email_exists($data['email']);

	if ($user_id) {

	// Create new post from existing user
	$post = $this->Post->create([
		'post_title' => $data['post_title'],
		'post_name' =>  $data['post_name'],
		'post_content' => $data['post_content'],
		'post_type' => $data['post_type'],
		'post_author' => $user_id,
		'guid' => $data['guid']
	]);
		
	} else {
		$parts = explode('@', $data['email']);
		$user_name = get_random_username($parts[0]);
		$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
		$user_id = wp_create_user( $user_name, $random_password, $data['email'] );

		// Create new post from new user
		$post = $this->Post->create([
			'post_title' => $data['post_title'],
			'post_name' =>  $data['post_name'],
			'post_content' => $data['post_content'],
			'post_type' => $data['post_type'],
			'post_author' => $user_id,
			'guid' => $data['guid']
		]);

	}

} else {

	// Create new post with default user
	$post = $this->Post->create([
		'post_title' => $data['post_title'],
		'post_name' =>  $data['post_name'],
		'post_content' => $data['post_content'],
		'post_type' => $data['post_type'],
		'post_author' => $data['post_author'],
		'guid' => $data['guid']
	]);
	
}

	// Postmeta data
	$website = maybe_serialize(serialize(array('url' => $data['website'], 'text' => $data['website_text'])));
	$postmeta = array(
		'_content_field_6' => $data['phone'],
		'_content_field_7' => $website,
		'_content_field_8' => $data['email'],
		'_content_field_9' => $data['fax'],
		'_content_field_10' => $data['contactperson'],
		'_map_zoom' => $data['postmeta']['_map_zoom'],
		'_listing_created' => $data['postmeta']['_listing_created'],
		'_order_date' => $data['postmeta']['_order_date'],
		'_listing_status' => $data['postmeta']['_listing_status']
	);

	// Create post meta
	foreach ($postmeta as $key => $value) {
		$this->PostMeta->create([
			'post_id' => $post->id,
			'meta_key' => $key,
			'meta_value' => $value,
		]);
	}


	// Create taxonomies relationship
	foreach($taxonomies as $term)
	{
		$this->TermRelationship->create([
			'term_taxonomy_id' => $term,
			'object_id' => $post->id,
		]);
	}

	
	// Create location relationship
	$this->W2dcLocationRelationship->create([
		'post_id' => $post->id,
		'location_id' => $location_id,
		'address_line_1' => $data['address'],
		'zip_or_postal_index' => $data['zipcode'],
		'additional_info' => $data['extra'],
		'map_coords_1' => $data['map_coords_1'],
		'map_coords_2'=> $data['map_coords_2'],
	]);

	// Create level relationship
	$this->W2dcLevelRelationship->create([
		'post_id' => $post->id,
		'level_id' => $data['level']
	]);

	// Update status
	$this->Link
	->where('link_id', $link->link_id)
	->update([
		'link_post_id' => $post->id
	]);


}