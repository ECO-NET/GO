<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class W2dcLevelRelationship extends Model
{

	public $timestamps = false;

	protected $table = 'w2dc_levels_relationships';

	protected $fillable = [

		'post_id',
		'level_id',

	];

}