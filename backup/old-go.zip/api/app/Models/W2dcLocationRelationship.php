<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class W2dcLocationRelationship extends Model
{

	public $timestamps = false;

	protected $table = 'w2dc_locations_relationships';

	protected $fillable = [

		'post_id',
		'location_id',
		'address_line_1',
		'zip_or_postal_index',
		'additional_info',
		'map_coords_1',
		'map_coords_2',

	];

}
