<?php
/**
 * Website crawler - concept
 * 
 * Link crawler design for the website http://www.grøntoverblik.dk/
 * 
 * @author  Hans Erik Jepsen                <hanserikjepsen@hotmail.com>
 * @author  Thomas Elvin Schønemann-Lange
 */
namespace App\Models;
use App\Models\Link;
class Crawler {
    private $links = [];
    private $next_page = false;
    public $done = false;
    public $url = [];
    public $next_url = '';

    /**
     * Checks if the url is valid, explodes it and creates an array with the data.
     * 
     * @param   string  $url        Valid url
     * @return  array   $this->url  Array with data from an exploded url
     */
    public function setURL($url) {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            error_log(date('Y-m-d H:i:s') . " API ERROR: Invalid url $url!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
            die('API ERROR!');
        }
        $parts = explode('/', $url);
        $url = array(
            'host' => $parts[0] . '//' . $parts[2],
            'type' => $parts[3],
            'request' => $parts[0] . '//' . $parts[2] . '/' . $parts[3] . '/',
            'link' => $url
        );
        return $this->url = $url;
    }

    /**
     * Finds all links from the html dom on the set URL and adds them to an array.
     * Then it checks if pagination is used and sets the URL for the next page.
     * 
     * @return  string  $this->next_url Contains the URL for the next page
     * @return  boolean $this->done     Gets set to true when the script has finished running
     */
    public function run() {
        $html = @file_get_html($this->url['link']);
        if (!$html) {
            error_log(date('Y-m-d H:i:s') . " API ERROR: Request failed!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
            die('API ERROR!');
        }
        foreach ($html->find('span.contentheader2 a') as $link) {
           $status = $this->addLinkToArray($this->url['request'] . $link->href);
           if(!$status)
           {
            continue;
           }
        }
        $insert = $this->insertArrayIntoDatabase();
        if (!$insert) {
            error_log(date('Y-m-d H:i:s') . " DB ERROR: Insert failed!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
            die('API ERROR!');
        }
        foreach ($html->find('td[name=maincontent] td[valign=top] tr[valign=top] td[align=right] a') as $a) {
            if (1 === preg_match("/n*ste/i", $a->title)) {
                $this->next_page = true;
                $this->next_url = trim($this->url['host'] . $a->href);
            }
        }
        if ($this->next_page) {
          return $this->next_url;
        }
        return $this->done = true;
    }
    
    /**
     * Adds a URL to an array
     * 
     * @param   string  $href   Stores the url
     * @return  boolean         Fails if the script can't get any content from the url
     * @return  null            Returns null if the URL already exists in the array.
     * @return  int             Returns the new number of elements in the array.
     */
    private function addLinkToArray($url) {
        $url_exists = array_search($url, $this->links);
        $content = @file_get_html($url);
        
        if(!$content)
        {
            error_log(date('Y-m-d H:i:s') . " API ERROR: Request failed for $url!" . "\r\n". "\r\n", 3, 'resources/log/error.log');
            return false;
        }
        $array = [
            'url' => $url,
            'type' => $this->url['type']
        ];
        return ($url_exists !== false) ? null : array_push($this->links,$array);
    }
    
    /**
     *  Inserts the array into the database
     * 
     *  @return boolean   Script fails if the $db is not set correctly
     *  @return boolean   Script fails if the $db->create function fails
     *  @return boolean   Returns true when the script has finished running
     */
    private function insertArrayIntoDatabase() {
        $db = new Link;
        if(!$db instanceof Link) {
            return false;
        }
        foreach ($this->links as $link) {
            $db->create([
                'link_url' => $link['url'],
                'link_type' => $link['type']
            ]);
            if(!$db){
                return false;
            }
        }
        return true;
    }
}