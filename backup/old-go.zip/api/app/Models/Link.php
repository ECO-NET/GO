<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{

		   /**
     * The name of the "created at" column.
     *
     * @var string
     */
    const CREATED_AT = 'link_date';

    /**
     * The name of the "updated at" column.
     *
     * @var string
     */
    const UPDATED_AT = 'link_updated';

	protected $table = 'links';

	protected $fillable = [

		'link_post_id',
		'link_url',
		'link_date',
		'link_updated',
		'link_url',
		'link_type',
		'link_rel', // Relation to other
		'link_done',
		'link_error'

	];

}