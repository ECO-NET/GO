<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{

	public $timestamps = false;

	protected $table = 'options';

	protected $fillable = [

		'option_name',
		'option_value',

	];

}