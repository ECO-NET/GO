<?php

// Settings
define('DEBUG', 1);

// DB credentials
define('DB_STATUS', 0);
define('DB_TYPE', 'mysql');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'db');
define('DB_USER', 'root');
define('DB_PASS', 'pass');
define('DB_PREFIX', '_');





