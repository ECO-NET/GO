-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Vært: localhost:3306
-- Genereringstid: 06. 09 2016 kl. 09:19:30
-- Serverversion: 10.0.25-MariaDB-cll-lve
-- PHP-version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `websuppo_go`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_commentmeta`
--

CREATE TABLE IF NOT EXISTS `go_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_comments`
--

CREATE TABLE IF NOT EXISTS `go_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_comments`
--

INSERT INTO `go_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Hr WordPress', '', 'https://wordpress.org/', '', '2016-05-06 09:46:21', '2016-05-06 09:46:21', 'Hej, dette er en kommentar.\nFor at slette en kommentar logger du blot ind og læser indlæggets kommentarer. Der har du mulighed for at redigere eller slette dem.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_bookings`
--

CREATE TABLE IF NOT EXISTS `go_em_bookings` (
  `booking_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned DEFAULT NULL,
  `person_id` bigint(20) unsigned NOT NULL,
  `booking_spaces` int(5) NOT NULL,
  `booking_comment` mediumtext COLLATE utf8mb4_unicode_ci,
  `booking_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `booking_status` tinyint(1) NOT NULL DEFAULT '1',
  `booking_price` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `booking_tax_rate` decimal(7,4) DEFAULT NULL,
  `booking_taxes` decimal(14,4) DEFAULT NULL,
  `booking_meta` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`booking_id`),
  KEY `event_id` (`event_id`),
  KEY `person_id` (`person_id`),
  KEY `booking_status` (`booking_status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_events`
--

CREATE TABLE IF NOT EXISTS `go_em_events` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `event_slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_owner` bigint(20) unsigned DEFAULT NULL,
  `event_status` int(1) DEFAULT NULL,
  `event_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `event_start_time` time DEFAULT NULL,
  `event_end_time` time DEFAULT NULL,
  `event_all_day` int(1) DEFAULT NULL,
  `event_start_date` date DEFAULT NULL,
  `event_end_date` date DEFAULT NULL,
  `post_content` longtext COLLATE utf8mb4_unicode_ci,
  `event_rsvp` tinyint(1) NOT NULL DEFAULT '0',
  `event_rsvp_date` date DEFAULT NULL,
  `event_rsvp_time` time DEFAULT NULL,
  `event_rsvp_spaces` int(5) DEFAULT NULL,
  `event_spaces` int(5) DEFAULT '0',
  `event_private` tinyint(1) NOT NULL DEFAULT '0',
  `location_id` bigint(20) unsigned DEFAULT NULL,
  `recurrence_id` bigint(20) unsigned DEFAULT NULL,
  `event_category_id` bigint(20) unsigned DEFAULT NULL,
  `event_attributes` mediumtext COLLATE utf8mb4_unicode_ci,
  `event_date_created` datetime DEFAULT NULL,
  `event_date_modified` datetime DEFAULT NULL,
  `recurrence` tinyint(1) NOT NULL DEFAULT '0',
  `recurrence_interval` int(4) DEFAULT NULL,
  `recurrence_freq` text COLLATE utf8mb4_unicode_ci,
  `recurrence_byday` text COLLATE utf8mb4_unicode_ci,
  `recurrence_byweekno` int(4) DEFAULT NULL,
  `recurrence_days` int(4) DEFAULT NULL,
  `recurrence_rsvp_days` int(3) DEFAULT NULL,
  `blog_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `event_status` (`event_status`),
  KEY `post_id` (`post_id`),
  KEY `blog_id` (`blog_id`),
  KEY `group_id` (`group_id`),
  KEY `location_id` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_locations`
--

CREATE TABLE IF NOT EXISTS `go_em_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `blog_id` bigint(20) unsigned DEFAULT NULL,
  `location_slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `location_owner` bigint(20) unsigned NOT NULL DEFAULT '0',
  `location_address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_town` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_state` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_postcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_region` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_country` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_latitude` float(10,6) DEFAULT NULL,
  `location_longitude` float(10,6) DEFAULT NULL,
  `post_content` longtext COLLATE utf8mb4_unicode_ci,
  `location_status` int(1) DEFAULT NULL,
  `location_private` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`),
  KEY `location_country` (`location_country`),
  KEY `post_id` (`post_id`),
  KEY `blog_id` (`blog_id`),
  KEY `location_state` (`location_state`(191)),
  KEY `location_region` (`location_region`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_meta`
--

CREATE TABLE IF NOT EXISTS `go_em_meta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  `meta_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`meta_id`),
  KEY `object_id` (`object_id`),
  KEY `meta_key` (`meta_key`(250))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_tickets`
--

CREATE TABLE IF NOT EXISTS `go_em_tickets` (
  `ticket_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `ticket_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticket_description` mediumtext COLLATE utf8mb4_unicode_ci,
  `ticket_price` decimal(14,4) DEFAULT NULL,
  `ticket_start` datetime DEFAULT NULL,
  `ticket_end` datetime DEFAULT NULL,
  `ticket_min` int(10) DEFAULT NULL,
  `ticket_max` int(10) DEFAULT NULL,
  `ticket_spaces` int(11) DEFAULT NULL,
  `ticket_members` int(1) DEFAULT NULL,
  `ticket_members_roles` longtext COLLATE utf8mb4_unicode_ci,
  `ticket_guests` int(1) DEFAULT NULL,
  `ticket_required` int(1) DEFAULT NULL,
  `ticket_meta` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`ticket_id`),
  KEY `event_id` (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_em_tickets_bookings`
--

CREATE TABLE IF NOT EXISTS `go_em_tickets_bookings` (
  `ticket_booking_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) unsigned NOT NULL,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `ticket_booking_spaces` int(6) NOT NULL,
  `ticket_booking_price` decimal(14,4) NOT NULL,
  PRIMARY KEY (`ticket_booking_id`),
  KEY `booking_id` (`booking_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_links`
--

CREATE TABLE IF NOT EXISTS `go_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_options`
--

CREATE TABLE IF NOT EXISTS `go_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2606 ;

--
-- Data dump for tabellen `go_options`
--

INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(3, 'siteurl', 'https://xn--grntoverblik-wjb.dk/wp', 'yes'),
(4, 'home', 'https://xn--grntoverblik-wjb.dk/wp', 'yes'),
(5, 'blogname', 'øko-info', 'yes'),
(6, 'blogdescription', ' Guide til det grønne Danmark - vejen til økologisk information!', 'yes'),
(7, 'users_can_register', '1', 'yes'),
(8, 'admin_email', 'sde.thom855j@gmail.com', 'yes'),
(9, 'start_of_week', '1', 'yes'),
(10, 'use_balanceTags', '0', 'yes'),
(11, 'use_smilies', '1', 'yes'),
(12, 'require_name_email', '1', 'yes'),
(13, 'comments_notify', '1', 'yes'),
(14, 'posts_per_rss', '10', 'yes'),
(15, 'rss_use_excerpt', '1', 'yes'),
(16, 'mailserver_url', 'mail.example.com', 'yes'),
(17, 'mailserver_login', 'login@example.com', 'yes'),
(18, 'mailserver_pass', 'password', 'yes'),
(19, 'mailserver_port', '110', 'yes'),
(20, 'default_category', '1', 'yes'),
(21, 'default_comment_status', 'open', 'yes'),
(22, 'default_ping_status', 'open', 'yes'),
(23, 'default_pingback_flag', '1', 'yes'),
(24, 'posts_per_page', '10', 'yes'),
(25, 'date_format', 'j. F Y', 'yes'),
(26, 'time_format', 'G:i', 'yes'),
(27, 'links_updated_date_format', 'j. F Y H:i', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(31, 'rewrite_rules', 'a:382:{s:29:"kalender/(\\d{4}-\\d{2}-\\d{2})$";s:53:"index.php?pagename=kalender/&calendar_day=$matches[1]";s:15:"kalender/rss/?$";s:35:"index.php?post_type=event&feed=feed";s:16:"kalender/feed/?$";s:35:"index.php?post_type=event&feed=feed";s:20:"kalender/event/(.+)$";s:65:"index.php?pagename=kalender/&em_redirect=1&event_slug=$matches[1]";s:23:"kalender/location/(.+)$";s:68:"index.php?pagename=kalender/&em_redirect=1&location_slug=$matches[1]";s:23:"kalender/category/(.+)$";s:68:"index.php?pagename=kalender/&em_redirect=1&category_slug=$matches[1]";s:11:"kalender/?$";s:27:"index.php?pagename=kalender";s:21:"event/([^/]+)/ical/?$";s:34:"index.php?event=$matches[1]&ical=1";s:25:"locations/([^/]+)/ical/?$";s:37:"index.php?location=$matches[1]&ical=1";s:33:"events/categories/([^/]+)/ical/?$";s:45:"index.php?event-categories=$matches[1]&ical=1";s:27:"events/tags/([^/]+)/ical/?$";s:39:"index.php?event-tags=$matches[1]&ical=1";s:24:"locations/([^/]+)/rss/?$";s:36:"index.php?location=$matches[1]&rss=1";s:28:"(sider)/page/?([0-9]{1,})/?$";s:37:"index.php?page_id=5&paged=$matches[2]";s:10:"(sider)/?$";s:19:"index.php?page_id=5";s:58:"(sider)?/?organisation-kategori/(.+?)/page/?([0-9]{1,})/?$";s:63:"index.php?page_id=5&category-w2dc=$matches[2]&paged=$matches[3]";s:40:"(sider)?/?organisation-kategori/(.+?)/?$";s:45:"index.php?page_id=5&category-w2dc=$matches[2]";s:58:"(sider)?/?organisation-lokation/(.+?)/page/?([0-9]{1,})/?$";s:63:"index.php?page_id=5&location-w2dc=$matches[2]&paged=$matches[3]";s:40:"(sider)?/?organisation-lokation/(.+?)/?$";s:45:"index.php?page_id=5&location-w2dc=$matches[2]";s:61:"(sider)?/?organisation-emneord/([^\\/.]+)/page/?([0-9]{1,})/?$";s:58:"index.php?page_id=5&tag-w2dc=$matches[2]&paged=$matches[3]";s:43:"(sider)?/?organisation-emneord/([^\\/.]+)/?$";s:40:"index.php?page_id=5&tag-w2dc=$matches[2]";s:18:"sider/([^\\/.]+)/?$";s:44:"index.php?page_id=5&listing-w2dc=$matches[1]";s:78:"(sider)?/?(?!(?:199[0-9]|20[012][0-9])/(?:0[1-9]|1[012]))([0-9]+)/([^\\/.]+)/?$";s:44:"index.php?page_id=5&listing-w2dc=$matches[3]";s:40:"(sider)?/?publikation/(.+?)/([^\\/.]+)/?$";s:71:"index.php?page_id=5&tax-slugs-w2dc=$matches[2]&listing-w2dc=$matches[3]";s:34:"(sider)?/?publikation/([^\\/.]+)/?$";s:44:"index.php?page_id=5&listing-w2dc=$matches[2]";s:15:"w2dc_listing/?$";s:32:"index.php?post_type=w2dc_listing";s:45:"w2dc_listing/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=w2dc_listing&feed=$matches[1]";s:40:"w2dc_listing/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?post_type=w2dc_listing&feed=$matches[1]";s:32:"w2dc_listing/page/([0-9]{1,})/?$";s:50:"index.php?post_type=w2dc_listing&paged=$matches[1]";s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:12:"locations/?$";s:28:"index.php?post_type=location";s:42:"locations/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=location&feed=$matches[1]";s:37:"locations/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=location&feed=$matches[1]";s:29:"locations/page/([0-9]{1,})/?$";s:46:"index.php?post_type=location&paged=$matches[1]";s:8:"event/?$";s:25:"index.php?post_type=event";s:38:"event/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:33:"event/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:25:"event/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:8:"butik/?$";s:27:"index.php?post_type=product";s:38:"butik/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:33:"butik/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:25:"butik/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:20:"bibliotek-artikel/?$";s:33:"index.php?post_type=knowledgebase";s:50:"bibliotek-artikel/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_type=knowledgebase&feed=$matches[1]";s:45:"bibliotek-artikel/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_type=knowledgebase&feed=$matches[1]";s:37:"bibliotek-artikel/page/([0-9]{1,})/?$";s:51:"index.php?post_type=knowledgebase&paged=$matches[1]";s:47:"kategori/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"kategori/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"kategori/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"kategori/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"kategori/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"kategori/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:45:"emne/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:40:"emne/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:21:"emne/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:33:"emne/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:30:"emne/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:15:"emne/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"w2dc_listing/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"w2dc_listing/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"w2dc_listing/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"w2dc_listing/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"w2dc_listing/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"w2dc_listing/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"w2dc_listing/([^/]+)/embed/?$";s:45:"index.php?w2dc_listing=$matches[1]&embed=true";s:33:"w2dc_listing/([^/]+)/trackback/?$";s:39:"index.php?w2dc_listing=$matches[1]&tb=1";s:53:"w2dc_listing/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?w2dc_listing=$matches[1]&feed=$matches[2]";s:48:"w2dc_listing/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?w2dc_listing=$matches[1]&feed=$matches[2]";s:41:"w2dc_listing/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?w2dc_listing=$matches[1]&paged=$matches[2]";s:48:"w2dc_listing/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?w2dc_listing=$matches[1]&cpage=$matches[2]";s:38:"w2dc_listing/([^/]+)/wc-api(/(.*))?/?$";s:53:"index.php?w2dc_listing=$matches[1]&wc-api=$matches[3]";s:44:"w2dc_listing/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:55:"w2dc_listing/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:37:"w2dc_listing/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?w2dc_listing=$matches[1]&page=$matches[2]";s:29:"w2dc_listing/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"w2dc_listing/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"w2dc_listing/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"w2dc_listing/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"w2dc_listing/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"w2dc_listing/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:54:"w2dc-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?w2dc-category=$matches[1]&feed=$matches[2]";s:49:"w2dc-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?w2dc-category=$matches[1]&feed=$matches[2]";s:30:"w2dc-category/([^/]+)/embed/?$";s:46:"index.php?w2dc-category=$matches[1]&embed=true";s:42:"w2dc-category/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?w2dc-category=$matches[1]&paged=$matches[2]";s:24:"w2dc-category/([^/]+)/?$";s:35:"index.php?w2dc-category=$matches[1]";s:54:"w2dc-location/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?w2dc-location=$matches[1]&feed=$matches[2]";s:49:"w2dc-location/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?w2dc-location=$matches[1]&feed=$matches[2]";s:30:"w2dc-location/([^/]+)/embed/?$";s:46:"index.php?w2dc-location=$matches[1]&embed=true";s:42:"w2dc-location/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?w2dc-location=$matches[1]&paged=$matches[2]";s:24:"w2dc-location/([^/]+)/?$";s:35:"index.php?w2dc-location=$matches[1]";s:49:"w2dc-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?w2dc-tag=$matches[1]&feed=$matches[2]";s:44:"w2dc-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?w2dc-tag=$matches[1]&feed=$matches[2]";s:25:"w2dc-tag/([^/]+)/embed/?$";s:41:"index.php?w2dc-tag=$matches[1]&embed=true";s:37:"w2dc-tag/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?w2dc-tag=$matches[1]&paged=$matches[2]";s:19:"w2dc-tag/([^/]+)/?$";s:30:"index.php?w2dc-tag=$matches[1]";s:52:"events/tags/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?event-tags=$matches[1]&feed=$matches[2]";s:47:"events/tags/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?event-tags=$matches[1]&feed=$matches[2]";s:28:"events/tags/([^/]+)/embed/?$";s:43:"index.php?event-tags=$matches[1]&embed=true";s:40:"events/tags/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?event-tags=$matches[1]&paged=$matches[2]";s:22:"events/tags/([^/]+)/?$";s:32:"index.php?event-tags=$matches[1]";s:56:"events/categories/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?event-categories=$matches[1]&feed=$matches[2]";s:51:"events/categories/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?event-categories=$matches[1]&feed=$matches[2]";s:32:"events/categories/(.+?)/embed/?$";s:49:"index.php?event-categories=$matches[1]&embed=true";s:44:"events/categories/(.+?)/page/?([0-9]{1,})/?$";s:56:"index.php?event-categories=$matches[1]&paged=$matches[2]";s:26:"events/categories/(.+?)/?$";s:38:"index.php?event-categories=$matches[1]";s:37:"locations/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"locations/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"locations/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"locations/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"locations/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"locations/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"locations/([^/]+)/embed/?$";s:41:"index.php?location=$matches[1]&embed=true";s:30:"locations/([^/]+)/trackback/?$";s:35:"index.php?location=$matches[1]&tb=1";s:50:"locations/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?location=$matches[1]&feed=$matches[2]";s:45:"locations/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?location=$matches[1]&feed=$matches[2]";s:38:"locations/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?location=$matches[1]&paged=$matches[2]";s:45:"locations/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?location=$matches[1]&cpage=$matches[2]";s:35:"locations/([^/]+)/wc-api(/(.*))?/?$";s:49:"index.php?location=$matches[1]&wc-api=$matches[3]";s:41:"locations/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:52:"locations/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:34:"locations/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?location=$matches[1]&page=$matches[2]";s:26:"locations/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"locations/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"locations/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"locations/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"locations/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"locations/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"event/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"event/([^/]+)/embed/?$";s:38:"index.php?event=$matches[1]&embed=true";s:26:"event/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:46:"event/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:41:"event/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:31:"event/([^/]+)/wc-api(/(.*))?/?$";s:46:"index.php?event=$matches[1]&wc-api=$matches[3]";s:37:"event/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:48:"event/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:30:"event/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"event/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"events-recurring/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"events-recurring/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"events-recurring/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"events-recurring/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"events-recurring/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:50:"events-recurring/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"events-recurring/([^/]+)/embed/?$";s:48:"index.php?event-recurring=$matches[1]&embed=true";s:37:"events-recurring/([^/]+)/trackback/?$";s:42:"index.php?event-recurring=$matches[1]&tb=1";s:45:"events-recurring/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?event-recurring=$matches[1]&paged=$matches[2]";s:52:"events-recurring/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?event-recurring=$matches[1]&cpage=$matches[2]";s:42:"events-recurring/([^/]+)/wc-api(/(.*))?/?$";s:56:"index.php?event-recurring=$matches[1]&wc-api=$matches[3]";s:48:"events-recurring/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:59:"events-recurring/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:41:"events-recurring/([^/]+)(?:/([0-9]+))?/?$";s:54:"index.php?event-recurring=$matches[1]&page=$matches[2]";s:33:"events-recurring/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"events-recurring/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"events-recurring/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"events-recurring/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"events-recurring/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"events-recurring/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:55:"produkt-kategori/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"produkt-kategori/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"produkt-kategori/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"produkt-kategori/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"produkt-kategori/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:53:"produkt-emne/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:48:"produkt-emne/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:29:"produkt-emne/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:41:"produkt-emne/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:23:"produkt-emne/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:36:"shop/.+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"shop/.+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"shop/.+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"shop/.+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"shop/.+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"shop/.+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"shop/(.+?)/([^/]+)/embed/?$";s:64:"index.php?product_cat=$matches[1]&product=$matches[2]&embed=true";s:31:"shop/(.+?)/([^/]+)/trackback/?$";s:58:"index.php?product_cat=$matches[1]&product=$matches[2]&tb=1";s:51:"shop/(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:46:"shop/(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:39:"shop/(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&paged=$matches[3]";s:46:"shop/(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&cpage=$matches[3]";s:36:"shop/(.+?)/([^/]+)/wc-api(/(.*))?/?$";s:72:"index.php?product_cat=$matches[1]&product=$matches[2]&wc-api=$matches[4]";s:40:"shop/.+?/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:51:"shop/.+?/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:35:"shop/(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&page=$matches[3]";s:25:"shop/.+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"shop/.+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"shop/.+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"shop/.+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"shop/.+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"shop/.+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"product_variation/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"product_variation/([^/]+)/embed/?$";s:50:"index.php?product_variation=$matches[1]&embed=true";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"product_variation/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"product_variation/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"shop_order_refund/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"shop_order_refund/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"shop_order_refund/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"shop_order_refund/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"shop_order_refund/([^/]+)/embed/?$";s:50:"index.php?shop_order_refund=$matches[1]&embed=true";s:38:"shop_order_refund/([^/]+)/trackback/?$";s:44:"index.php?shop_order_refund=$matches[1]&tb=1";s:46:"shop_order_refund/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&paged=$matches[2]";s:53:"shop_order_refund/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&cpage=$matches[2]";s:43:"shop_order_refund/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?shop_order_refund=$matches[1]&wc-api=$matches[3]";s:49:"shop_order_refund/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"shop_order_refund/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"shop_order_refund/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?shop_order_refund=$matches[1]&page=$matches[2]";s:34:"shop_order_refund/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"shop_order_refund/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"shop_order_refund/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"shop_order_refund/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"bibliotek-artikel/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"bibliotek-artikel/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"bibliotek-artikel/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"bibliotek-artikel/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"bibliotek-artikel/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"bibliotek-artikel/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"bibliotek-artikel/([^/]+)/embed/?$";s:46:"index.php?knowledgebase=$matches[1]&embed=true";s:38:"bibliotek-artikel/([^/]+)/trackback/?$";s:40:"index.php?knowledgebase=$matches[1]&tb=1";s:58:"bibliotek-artikel/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?knowledgebase=$matches[1]&feed=$matches[2]";s:53:"bibliotek-artikel/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?knowledgebase=$matches[1]&feed=$matches[2]";s:46:"bibliotek-artikel/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?knowledgebase=$matches[1]&paged=$matches[2]";s:53:"bibliotek-artikel/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?knowledgebase=$matches[1]&cpage=$matches[2]";s:43:"bibliotek-artikel/([^/]+)/wc-api(/(.*))?/?$";s:54:"index.php?knowledgebase=$matches[1]&wc-api=$matches[3]";s:49:"bibliotek-artikel/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"bibliotek-artikel/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"bibliotek-artikel/([^/]+)(?:/([0-9]+))?/?$";s:52:"index.php?knowledgebase=$matches[1]&page=$matches[2]";s:34:"bibliotek-artikel/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"bibliotek-artikel/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"bibliotek-artikel/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"bibliotek-artikel/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"bibliotek-artikel/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"bibliotek-artikel/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:59:"bibliotek-kategori/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:61:"index.php?knowledgebase_category=$matches[1]&feed=$matches[2]";s:54:"bibliotek-kategori/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:61:"index.php?knowledgebase_category=$matches[1]&feed=$matches[2]";s:35:"bibliotek-kategori/([^/]+)/embed/?$";s:55:"index.php?knowledgebase_category=$matches[1]&embed=true";s:47:"bibliotek-kategori/([^/]+)/page/?([0-9]{1,})/?$";s:62:"index.php?knowledgebase_category=$matches[1]&paged=$matches[2]";s:29:"bibliotek-kategori/([^/]+)/?$";s:44:"index.php?knowledgebase_category=$matches[1]";s:59:"knowledgebase_tags/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?knowledgebase_tags=$matches[1]&feed=$matches[2]";s:54:"knowledgebase_tags/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?knowledgebase_tags=$matches[1]&feed=$matches[2]";s:35:"knowledgebase_tags/([^/]+)/embed/?$";s:51:"index.php?knowledgebase_tags=$matches[1]&embed=true";s:47:"knowledgebase_tags/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?knowledgebase_tags=$matches[1]&paged=$matches[2]";s:29:"knowledgebase_tags/([^/]+)/?$";s:40:"index.php?knowledgebase_tags=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=42&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:62:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$";s:99:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]";s:62:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:73:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:10:{i:0;s:33:"admin-menu-editor/menu-editor.php";i:1;s:65:"codecanyon-6463373-web-20-directory-plugin-for-wordpress/w2dc.php";i:2;s:33:"events-manager/events-manager.php";i:3;s:34:"header-and-footer-scripts/shfs.php";i:4;s:53:"pressapps-knowledge-base/pressapps-knowledge-base.php";i:5;s:27:"redirection/redirection.php";i:6;s:33:"user-switching/user-switching.php";i:7;s:33:"w3-total-cache/w3-total-cache.php";i:8;s:27:"woocommerce/woocommerce.php";i:9;s:24:"wordpress-seo/wp-seo.php";}', 'yes'),
(36, 'category_base', '/kategori', 'yes'),
(37, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(38, 'comment_max_links', '2', 'yes'),
(39, 'gmt_offset', '0', 'yes'),
(40, 'default_email_category', '1', 'yes'),
(41, 'recently_edited', '', 'no'),
(42, 'template', 'storefront', 'yes'),
(43, 'stylesheet', 'storefront', 'yes'),
(44, 'comment_whitelist', '1', 'yes'),
(45, 'blacklist_keys', '', 'no'),
(46, 'comment_registration', '0', 'yes'),
(47, 'html_type', 'text/html', 'yes'),
(48, 'use_trackback', '0', 'yes'),
(49, 'default_role', 'subscriber', 'yes'),
(50, 'db_version', '37965', 'yes'),
(51, 'uploads_use_yearmonth_folders', '1', 'yes'),
(52, 'upload_path', '', 'yes'),
(53, 'blog_public', '1', 'yes'),
(54, 'default_link_category', '2', 'yes'),
(55, 'show_on_front', 'page', 'yes'),
(56, 'tag_base', '/emne', 'yes'),
(57, 'show_avatars', '1', 'yes'),
(58, 'avatar_rating', 'G', 'yes'),
(59, 'upload_url_path', '', 'yes'),
(60, 'thumbnail_size_w', '150', 'yes'),
(61, 'thumbnail_size_h', '150', 'yes'),
(62, 'thumbnail_crop', '1', 'yes'),
(63, 'medium_size_w', '300', 'yes'),
(64, 'medium_size_h', '300', 'yes'),
(65, 'avatar_default', 'mystery', 'yes'),
(66, 'large_size_w', '1024', 'yes'),
(67, 'large_size_h', '1024', 'yes'),
(68, 'image_default_link_type', 'none', 'yes'),
(69, 'image_default_size', '', 'yes'),
(70, 'image_default_align', '', 'yes'),
(71, 'close_comments_for_old_posts', '0', 'yes'),
(72, 'close_comments_days_old', '14', 'yes'),
(73, 'thread_comments', '1', 'yes'),
(74, 'thread_comments_depth', '5', 'yes'),
(75, 'page_comments', '0', 'yes'),
(76, 'comments_per_page', '50', 'yes'),
(77, 'default_comments_page', 'newest', 'yes'),
(78, 'comment_order', 'asc', 'yes'),
(79, 'sticky_posts', 'a:0:{}', 'yes'),
(80, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(83, 'uninstall_plugins', 'a:1:{s:27:"redirection/redirection.php";a:2:{i:0;s:17:"Redirection_Admin";i:1;s:16:"plugin_uninstall";}}', 'no'),
(84, 'timezone_string', '', 'yes'),
(85, 'page_for_posts', '45', 'yes'),
(86, 'page_on_front', '42', 'yes'),
(87, 'default_post_format', '0', 'yes'),
(88, 'link_manager_enabled', '0', 'yes'),
(89, 'finished_splitting_shared_terms', '1', 'yes'),
(90, 'site_icon', '0', 'yes'),
(91, 'medium_large_size_w', '768', 'yes'),
(92, 'medium_large_size_h', '0', 'yes'),
(93, 'initial_db_version', '36686', 'yes');
INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(94, 'go_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:155:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;s:15:"wpseo_bulk_edit";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:58:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:20:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:15:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:12:{s:4:"read";b:1;s:7:"level_0";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes'),
(95, 'WPLANG', 'da_DK', 'yes'),
(96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:10:{s:14:"kbe_cat_widget";a:0:{}s:19:"wp_inactive_widgets";a:0:{}s:9:"pakb-main";a:1:{i:0;s:27:"knowledge_base_categories-2";}s:9:"sidebar-1";a:1:{i:0;s:20:"w2dc_search_widget-2";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(102, 'bedrock_autoloader', 'a:2:{s:7:"plugins";a:0:{}s:5:"count";i:0;}', 'no'),
(103, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'cron', 'a:11:{i:1473148175;a:1:{s:18:"w3_dbcache_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:18:"w3_dbcache_cleanup";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1473148531;a:1:{s:15:"sheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1473149895;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1473155182;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1473155238;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1473155879;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1473170020;a:2:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1473193072;a:1:{s:22:"redirection_log_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1473206400;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1475755200;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:7:"monthly";s:4:"args";a:0:{}s:8:"interval";i:2635200;}}}s:7:"version";i:2;}', 'yes'),
(137, 'recently_activated', 'a:0:{}', 'yes'),
(190, 'w2dc_category_slug', 'organisation-kategori', 'yes'),
(191, 'w2dc_tag_slug', 'organisation-emneord', 'yes'),
(192, 'w2dc_enable_recaptcha', '', 'yes'),
(193, 'w2dc_recaptcha_public_key', '', 'yes'),
(194, 'w2dc_recaptcha_private_key', '', 'yes'),
(195, 'w2dc_show_categories_index', '', 'yes'),
(196, 'w2dc_show_category_count', '1', 'yes'),
(197, 'w2dc_listings_number_index', '6', 'yes'),
(198, 'w2dc_listings_number_excerpt', '6', 'yes'),
(199, 'w2dc_map_on_index', '1', 'yes'),
(200, 'w2dc_map_on_excerpt', '1', 'yes'),
(201, 'w2dc_directory_title', 'DE GRØNNE SIDER', 'yes'),
(202, 'w2dc_categories_nesting_level', '1', 'yes'),
(203, 'w2dc_show_directions', '1', 'yes'),
(204, 'w2dc_send_expiration_notification_days', '1', 'yes'),
(205, 'w2dc_preexpiration_notification', 'Your listing "[listing]" will expiry in [days] days.', 'yes'),
(206, 'w2dc_expiration_notification', 'Your listing "[listing]" had expired. You can renew it here [link]', 'yes'),
(207, 'w2dc_show_what_search', '1', 'yes'),
(208, 'w2dc_show_where_search', '1', 'yes'),
(209, 'w2dc_listings_on_index', '1', 'yes'),
(210, 'w2dc_listing_contact_form', '1', 'yes'),
(211, 'w2dc_favourites_list', '1', 'yes'),
(212, 'w2dc_print_button', '1', 'yes'),
(213, 'w2dc_pdf_button', '', 'yes'),
(214, 'w2dc_default_map_zoom', '11', 'yes'),
(215, 'w2dc_categories_icons', '', 'yes'),
(216, 'w2dc_change_expiration_date', '', 'yes'),
(217, 'w2dc_categories_columns', '2', 'yes'),
(218, 'w2dc_map_style', 'default', 'yes'),
(219, 'w2dc_main_search', '1', 'yes'),
(220, 'w2dc_hide_comments_number_on_index', '', 'yes'),
(221, 'w2dc_hide_listings_creation_date', '', 'yes'),
(222, 'w2dc_hide_author_link', '', 'yes'),
(223, 'w2dc_enable_radius_search_cycle', '1', 'yes'),
(224, 'w2dc_enable_clusters', '1', 'yes'),
(225, 'w2dc_show_location_count_in_search', '1', 'yes'),
(226, 'w2dc_color_scheme', 'green', 'yes'),
(227, 'w2dc_images_lightbox', '1', 'yes'),
(228, 'w2dc_listing_contact_form_7', '', 'yes'),
(229, 'w2dc_show_keywords_search', '1', 'yes'),
(230, 'w2dc_show_locations_search', '1', 'yes'),
(231, 'w2dc_show_address_search', '1', 'yes'),
(232, 'w2dc_subcategories_items', '0', 'yes'),
(233, 'w2dc_default_geocoding_location', 'Denmark', 'yes'),
(234, 'w2dc_show_orderby_links', '1', 'yes'),
(235, 'w2dc_orderby_date', '1', 'yes'),
(236, 'w2dc_orderby_title', '1', 'yes'),
(237, 'w2dc_default_orderby', 'post_date', 'yes'),
(238, 'w2dc_default_order', 'DESC', 'yes'),
(239, 'w2dc_notinclude_jqueryui_css', '', 'yes'),
(240, 'w2dc_logo_animation_effect', '6', 'yes'),
(241, 'w2dc_views_switcher', '1', 'yes'),
(242, 'w2dc_views_switcher_default', 'list', 'yes'),
(243, 'w2dc_views_switcher_grid_columns', '2', 'yes'),
(244, 'w2dc_wrap_logo_list_view', '', 'yes'),
(245, 'w2dc_show_category_count_in_search', '1', 'yes'),
(246, 'w2dc_miles_kilometers_in_search', 'kilometers', 'yes'),
(247, 'w2dc_radius_search_min', '0', 'yes'),
(248, 'w2dc_radius_search_max', '50', 'yes'),
(249, 'w2dc_show_categories_search', '1', 'yes'),
(250, 'w2dc_show_radius_search', '1', 'yes'),
(251, 'w2dc_radius_search_default', '0', 'yes'),
(252, 'w2dc_orderby_distance', '1', 'yes'),
(253, 'w2dc_compare_palettes', '', 'yes'),
(254, 'w2dc_links_color', '#5b9d30', 'yes'),
(255, 'w2dc_links_hover_color', '#64933d', 'yes'),
(256, 'w2dc_button_1_color', '#5b9d30', 'yes'),
(257, 'w2dc_button_2_color', '#64933d', 'yes'),
(258, 'w2dc_button_text_color', '#FFFFFF', 'yes'),
(259, 'w2dc_search_1_color', '#c3ff88', 'yes'),
(260, 'w2dc_search_2_color', '#7ed561', 'yes'),
(261, 'w2dc_search_text_color', '#FFFFFF', 'yes'),
(262, 'w2dc_categories_1_color', '#C5E7C7', 'yes'),
(263, 'w2dc_categories_2_color', '#E2F3E3', 'yes'),
(264, 'w2dc_categories_text_color', '#5b9d30', 'yes'),
(265, 'w2dc_locations_1_color', '#C5E7C7', 'yes'),
(266, 'w2dc_locations_2_color', '#E2F3E3', 'yes'),
(267, 'w2dc_locations_text_color', '#5b9d30', 'yes'),
(268, 'w2dc_primary_color', '#6cc150', 'yes'),
(269, 'w2dc_featured_color', '#effee0', 'yes'),
(270, 'w2dc_listing_thumb_width', '290', 'yes'),
(271, 'w2dc_grid_view_logo_ratio', '56.25', 'yes'),
(272, 'w2dc_listings_bottom_margin', '30', 'yes'),
(273, 'w2dc_listing_title_font', '20', 'yes'),
(274, 'w2dc_default_map_height', '450', 'yes'),
(275, 'w2dc_jquery_ui_schemas', 'le-frog', 'yes'),
(276, 'w2dc_addresses_order', 'a:7:{i:0;s:6:"line_1";i:1;s:6:"comma1";i:2;s:6:"line_2";i:3;s:6:"comma2";i:4;s:3:"zip";i:5;s:6:"space1";i:6;s:8:"location";}', 'yes'),
(277, 'w2dc_orderby_exclude_null', '', 'yes'),
(278, 'w2dc_map_marker_width', '48', 'yes'),
(279, 'w2dc_map_marker_height', '48', 'yes'),
(280, 'w2dc_map_marker_anchor_x', '24', 'yes'),
(281, 'w2dc_map_marker_anchor_y', '48', 'yes'),
(282, 'w2dc_map_infowindow_width', '350', 'yes'),
(283, 'w2dc_map_infowindow_offset', '50', 'yes'),
(284, 'w2dc_map_infowindow_logo_width', '110', 'yes'),
(285, 'w2dc_enable_nologo', '1', 'yes'),
(286, 'w2dc_nologo_url', 'https://project08.websupport.dk/app/uploads/2016/07/go-logo.png', 'yes'),
(287, 'w2dc_excerpt_length', '25', 'yes'),
(288, 'w2dc_cropped_content_as_excerpt', '1', 'yes'),
(289, 'w2dc_strip_excerpt', '1', 'yes'),
(290, 'w2dc_orderby_sticky_featured', '1', 'yes'),
(291, 'w2dc_button_gradient', '', 'yes'),
(292, 'w2dc_enable_description', '1', 'yes'),
(293, 'w2dc_enable_excerpt', '1', 'yes'),
(294, 'w2dc_share_buttons_style', 'arbenta', 'yes'),
(295, 'w2dc_share_buttons', 'a:0:{}', 'yes'),
(296, 'w2dc_share_counter', '1', 'yes'),
(297, 'w2dc_share_buttons_place', 'title', 'yes'),
(298, 'w2dc_share_buttons_width', '40', 'yes'),
(299, 'w2dc_100_single_logo_width', '', 'yes'),
(300, 'w2dc_single_logo_width', '270', 'yes'),
(301, 'w2dc_enable_address_line_1', '1', 'yes'),
(302, 'w2dc_enable_address_line_2', '', 'yes'),
(303, 'w2dc_enable_postal_index', '1', 'yes'),
(304, 'w2dc_enable_additional_info', '1', 'yes'),
(305, 'w2dc_enable_manual_coords', '', 'yes'),
(306, 'w2dc_big_slide_bg_mode', 'cover', 'yes'),
(307, 'w2dc_exclude_logo_from_listing', '', 'yes'),
(308, 'w2dc_enable_lighbox_gallery', '1', 'yes'),
(309, 'w2dc_directions_functionality', 'builtin', 'yes'),
(310, 'w2dc_address_autocomplete', '1', 'yes'),
(311, 'w2dc_address_geocode', '1', 'yes'),
(312, 'w2dc_listings_comments_mode', 'wp_settings', 'yes'),
(313, 'w2dc_listings_tabs_order', 'a:4:{i:0;s:13:"addresses-tab";i:1;s:12:"comments-tab";i:2;s:10:"videos-tab";i:3;s:11:"contact-tab";}', 'yes'),
(314, 'w2dc_listing_slug', 'publikation', 'yes'),
(315, 'w2dc_location_slug', 'organisation-lokation', 'yes'),
(316, 'w2dc_permalinks_structure', 'listing_slug', 'yes'),
(317, 'w2dc_google_api_key', '', 'yes'),
(318, 'w2dc_google_api_key_server', '', 'yes'),
(319, 'w2dc_show_locations_index', '', 'yes'),
(320, 'w2dc_locations_nesting_level', '1', 'yes'),
(321, 'w2dc_locations_columns', '2', 'yes'),
(322, 'w2dc_sublocations_items', '0', 'yes'),
(323, 'w2dc_show_location_count', '1', 'yes'),
(324, 'w2dc_locations_icons', '', 'yes'),
(325, 'w2dc_enable_breadcrumbs', '1', 'yes'),
(326, 'w2dc_hide_home_link_breadcrumb', '1', 'yes'),
(327, 'w2dc_breadcrumbs_mode', 'category', 'yes'),
(328, 'w2dc_auto_slides_gallery', '1', 'yes'),
(329, 'w2dc_auto_slides_gallery_delay', '3000', 'yes'),
(330, 'w2dc_ajax_load', '1', 'yes'),
(331, 'w2dc_ajax_initial_load', '', 'yes'),
(332, 'w2dc_show_more_button', '1', 'yes'),
(333, 'w2dc_map_markers_type', 'icons', 'yes'),
(334, 'w2dc_default_marker_color', '#2393ba', 'yes'),
(335, 'w2dc_default_marker_icon', '', 'yes'),
(336, 'w2dc_search_on_map', '', 'yes'),
(337, 'w2dc_enable_stats', '1', 'yes'),
(338, 'w2dc_enable_draw_panel', '', 'yes'),
(339, 'w2dc_installed_directory', '1', 'yes'),
(340, 'w2dc_installed_directory_version', '1.12.4', 'yes'),
(341, 'widget_w2dc_search_widget', 'a:2:{i:2;a:4:{s:5:"title";s:9:"VIS SIDER";s:3:"uid";s:0:"";s:10:"visibility";s:0:"";s:17:"search_visibility";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes'),
(342, 'widget_w2dc_categories_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(343, 'widget_w2dc_locations_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(344, 'widget_w2dc_listings_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(345, 'widget_w2dc_social_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(349, 'vpt_option', 'a:180:{s:18:"w2dc_fsubmit_addon";s:1:"1";s:19:"w2dc_payments_addon";s:0:"";s:18:"w2dc_ratings_addon";s:1:"1";s:14:"w2dc_ajax_load";s:1:"1";s:22:"w2dc_ajax_initial_load";s:0:"";s:21:"w2dc_show_more_button";s:1:"1";s:20:"w2dc_directory_title";s:16:"DE GRØNNE SIDER";s:0:"";s:0:"";s:17:"w2dc_listing_slug";s:11:"publikation";s:18:"w2dc_category_slug";s:21:"organisation-kategori";s:18:"w2dc_location_slug";s:21:"organisation-lokation";s:13:"w2dc_tag_slug";s:20:"organisation-emneord";s:25:"w2dc_permalinks_structure";s:12:"listing_slug";s:23:"w2dc_fsubmit_login_mode";s:1:"1";s:27:"w2dc_fsubmit_default_status";s:1:"1";s:24:"w2dc_fsubmit_edit_status";s:1:"3";s:19:"w2dc_fsubmit_button";s:1:"1";s:19:"w2dc_hide_admin_bar";s:1:"1";s:23:"w2dc_allow_edit_profile";s:1:"1";s:16:"w2dc_enable_tags";s:1:"1";s:12:"w2dc_tospage";s:2:"20";s:22:"w2dc_submit_login_page";s:2:"10";s:25:"w2dc_dashboard_login_page";s:2:"15";s:24:"w2dc_claim_functionality";s:0:"";s:19:"w2dc_claim_approval";s:0:"";s:16:"w2dc_after_claim";s:6:"active";s:28:"w2dc_hide_claim_contact_form";s:0:"";s:23:"w2dc_hide_claim_metabox";s:0:"";s:22:"w2dc_listings_on_index";s:1:"1";s:26:"w2dc_listings_number_index";s:1:"6";s:28:"w2dc_listings_number_excerpt";s:1:"6";s:25:"w2dc_listing_contact_form";s:1:"1";s:27:"w2dc_listing_contact_form_7";s:0:"";s:20:"w2dc_favourites_list";s:1:"1";s:17:"w2dc_print_button";s:1:"1";s:15:"w2dc_pdf_button";s:0:"";s:27:"w2dc_change_expiration_date";s:0:"";s:34:"w2dc_hide_comments_number_on_index";s:0:"";s:32:"w2dc_hide_listings_creation_date";s:0:"";s:21:"w2dc_hide_author_link";s:0:"";s:27:"w2dc_listings_comments_mode";s:11:"wp_settings";s:24:"w2dc_listings_tabs_order";a:4:{i:0;s:13:"addresses-tab";i:1;s:12:"comments-tab";i:2;s:10:"videos-tab";i:3;s:11:"contact-tab";}s:17:"w2dc_enable_stats";s:1:"1";s:23:"w2dc_enable_breadcrumbs";s:1:"1";s:30:"w2dc_hide_home_link_breadcrumb";s:1:"1";s:21:"w2dc_breadcrumbs_mode";s:8:"category";s:27:"w2dc_enable_lighbox_gallery";s:1:"1";s:24:"w2dc_auto_slides_gallery";s:1:"1";s:30:"w2dc_auto_slides_gallery_delay";s:4:"3000";s:30:"w2dc_exclude_logo_from_listing";s:0:"";s:18:"w2dc_enable_nologo";s:1:"1";s:15:"w2dc_nologo_url";s:63:"https://project08.websupport.dk/app/uploads/2016/07/go-logo.png";s:26:"w2dc_100_single_logo_width";s:0:"";s:22:"w2dc_single_logo_width";s:3:"270";s:22:"w2dc_big_slide_bg_mode";s:5:"cover";s:23:"w2dc_enable_description";s:1:"1";s:19:"w2dc_enable_summary";s:1:"1";s:19:"w2dc_excerpt_length";s:2:"25";s:31:"w2dc_cropped_content_as_excerpt";s:1:"1";s:18:"w2dc_strip_excerpt";s:1:"1";s:19:"w2dc_views_switcher";s:1:"1";s:27:"w2dc_views_switcher_default";s:4:"list";s:32:"w2dc_views_switcher_grid_columns";s:1:"2";s:25:"w2dc_grid_view_logo_ratio";s:5:"56.25";s:24:"w2dc_wrap_logo_list_view";s:0:"";s:24:"w2dc_listing_thumb_width";s:3:"290";s:26:"w2dc_show_categories_index";s:0:"";s:29:"w2dc_categories_nesting_level";s:1:"1";s:23:"w2dc_categories_columns";s:1:"2";s:24:"w2dc_subcategories_items";s:1:"0";s:24:"w2dc_show_category_count";s:1:"1";s:25:"w2dc_show_locations_index";s:0:"";s:28:"w2dc_locations_nesting_level";s:1:"1";s:22:"w2dc_locations_columns";s:1:"2";s:23:"w2dc_sublocations_items";s:1:"0";s:24:"w2dc_show_location_count";s:1:"1";s:23:"w2dc_show_orderby_links";s:1:"1";s:17:"w2dc_orderby_date";s:1:"1";s:18:"w2dc_orderby_title";s:1:"1";s:21:"w2dc_orderby_distance";s:1:"1";s:20:"w2dc_default_orderby";s:9:"post_date";s:18:"w2dc_default_order";s:4:"DESC";s:25:"w2dc_orderby_exclude_null";s:0:"";s:28:"w2dc_orderby_sticky_featured";s:1:"1";s:26:"w2dc_only_registered_users";s:0:"";s:18:"w2dc_rating_on_map";s:1:"1";s:19:"w2dc_manage_ratings";s:0:"";s:19:"w2dc_orderby_rating";s:1:"1";s:16:"w2dc_main_search";s:1:"1";s:21:"w2dc_show_what_search";s:1:"1";s:22:"w2dc_show_where_search";s:1:"1";s:25:"w2dc_show_keywords_search";s:1:"1";s:26:"w2dc_show_locations_search";s:1:"1";s:24:"w2dc_show_address_search";s:1:"1";s:34:"w2dc_show_location_count_in_search";s:1:"1";s:27:"w2dc_show_categories_search";s:1:"1";s:34:"w2dc_show_category_count_in_search";s:1:"1";s:23:"w2dc_show_radius_search";s:1:"1";s:31:"w2dc_miles_kilometers_in_search";s:10:"kilometers";s:22:"w2dc_radius_search_min";s:1:"0";s:22:"w2dc_radius_search_max";s:2:"50";s:26:"w2dc_radius_search_default";s:1:"0";s:17:"w2dc_map_on_index";s:1:"1";s:19:"w2dc_map_on_excerpt";s:1:"1";s:20:"w2dc_show_directions";s:1:"1";s:29:"w2dc_directions_functionality";s:7:"builtin";s:21:"w2dc_default_map_zoom";s:2:"11";s:14:"w2dc_map_style";s:7:"default";s:23:"w2dc_default_map_height";s:3:"450";s:31:"w2dc_enable_radius_search_cycle";s:1:"1";s:20:"w2dc_enable_clusters";s:1:"1";s:25:"w2dc_google_maps_required";s:0:"";s:22:"w2dc_enable_draw_panel";s:0:"";s:18:"w2dc_search_on_map";s:0:"";s:23:"w2dc_enable_full_screen";s:0:"";s:22:"w2dc_enable_wheel_zoom";s:1:"1";s:33:"w2dc_enable_dragging_touchscreens";s:1:"1";s:23:"w2dc_center_map_onclick";s:1:"1";s:30:"w2dc_hide_search_on_map_mobile";s:0:"";s:31:"w2dc_default_geocoding_location";s:7:"Denmark";s:20:"w2dc_addresses_order";a:7:{i:0;s:6:"line_1";i:1;s:6:"comma1";i:2;s:6:"line_2";i:3;s:6:"comma2";i:4;s:3:"zip";i:5;s:6:"space1";i:6;s:8:"location";}s:26:"w2dc_enable_address_line_1";s:1:"1";s:26:"w2dc_enable_address_line_2";s:0:"";s:24:"w2dc_enable_postal_index";s:1:"1";s:27:"w2dc_enable_additional_info";s:1:"1";s:25:"w2dc_enable_manual_coords";s:0:"";s:21:"w2dc_map_markers_type";s:5:"icons";s:25:"w2dc_default_marker_color";s:7:"#2393ba";s:24:"w2dc_default_marker_icon";s:0:"";s:21:"w2dc_map_marker_width";s:2:"48";s:22:"w2dc_map_marker_height";s:2:"48";s:24:"w2dc_map_marker_anchor_x";s:2:"24";s:24:"w2dc_map_marker_anchor_y";s:2:"48";s:25:"w2dc_map_infowindow_width";s:3:"350";s:26:"w2dc_map_infowindow_offset";s:2:"50";s:30:"w2dc_map_infowindow_logo_width";s:3:"110";s:38:"w2dc_send_expiration_notification_days";s:1:"1";s:31:"w2dc_preexpiration_notification";s:52:"Your listing "[listing]" will expiry in [days] days.";s:28:"w2dc_expiration_notification";s:66:"Your listing "[listing]" had expired. You can renew it here [link]";s:25:"w2dc_newuser_notification";s:0:"";s:34:"w2dc_newlisting_admin_notification";s:0:"";s:23:"w2dc_claim_notification";s:0:"";s:32:"w2dc_claim_approval_notification";s:0:"";s:19:"w2dc_google_api_key";s:0:"";s:26:"w2dc_google_api_key_server";s:0:"";s:20:"w2dc_images_lightbox";s:1:"1";s:28:"w2dc_notinclude_jqueryui_css";s:0:"";s:25:"w2dc_address_autocomplete";s:1:"1";s:20:"w2dc_address_geocode";s:1:"1";s:21:"w2dc_enable_recaptcha";s:0:"";s:25:"w2dc_recaptcha_public_key";s:0:"";s:26:"w2dc_recaptcha_private_key";s:0:"";s:21:"w2dc_compare_palettes";s:0:"";s:17:"w2dc_color_scheme";s:5:"green";s:16:"w2dc_links_color";s:7:"#5b9d30";s:22:"w2dc_links_hover_color";s:7:"#64933d";s:19:"w2dc_button_1_color";s:7:"#5b9d30";s:19:"w2dc_button_2_color";s:7:"#64933d";s:22:"w2dc_button_text_color";s:7:"#FFFFFF";s:20:"w2dc_button_gradient";s:0:"";s:19:"w2dc_search_1_color";s:7:"#c3ff88";s:19:"w2dc_search_2_color";s:7:"#7ed561";s:22:"w2dc_search_text_color";s:7:"#FFFFFF";s:23:"w2dc_categories_1_color";s:7:"#C5E7C7";s:23:"w2dc_categories_2_color";s:7:"#E2F3E3";s:26:"w2dc_categories_text_color";s:7:"#5b9d30";s:22:"w2dc_locations_1_color";s:7:"#C5E7C7";s:22:"w2dc_locations_2_color";s:7:"#E2F3E3";s:25:"w2dc_locations_text_color";s:7:"#5b9d30";s:18:"w2dc_primary_color";s:7:"#6cc150";s:19:"w2dc_featured_color";s:7:"#effee0";s:26:"w2dc_logo_animation_effect";s:1:"6";s:27:"w2dc_listings_bottom_margin";s:2:"30";s:23:"w2dc_listing_title_font";s:2:"20";s:22:"w2dc_jquery_ui_schemas";s:7:"le-frog";s:24:"w2dc_share_buttons_style";s:7:"arbenta";s:18:"w2dc_share_buttons";a:0:{}s:18:"w2dc_share_counter";s:1:"1";s:24:"w2dc_share_buttons_place";s:5:"title";s:24:"w2dc_share_buttons_width";s:2:"40";}', 'yes'),
(350, 'w2dc_fsubmit_addon', '1', 'yes'),
(351, 'w2dc_payments_addon', '', 'yes'),
(352, 'w2dc_ratings_addon', '1', 'yes'),
(353, 'w2dc_enable_summary', '1', 'yes'),
(354, 'w2dc_enable_full_screen', '', 'yes'),
(355, 'w2dc_enable_wheel_zoom', '1', 'yes'),
(356, 'w2dc_enable_dragging_touchscreens', '1', 'yes'),
(357, 'w2dc_center_map_onclick', '1', 'yes'),
(358, 'w2dc_hide_search_on_map_mobile', '', 'yes'),
(359, 'w2dc_fsubmit_default_status', '1', 'yes'),
(360, 'w2dc_fsubmit_login_mode', '1', 'yes'),
(361, 'w2dc_fsubmit_edit_status', '3', 'yes'),
(362, 'w2dc_fsubmit_button', '1', 'yes'),
(363, 'w2dc_hide_admin_bar', '1', 'yes'),
(364, 'w2dc_newuser_notification', '', 'yes'),
(365, 'w2dc_allow_edit_profile', '1', 'yes'),
(366, 'w2dc_enable_frontend_translations', '1', 'yes'),
(367, 'w2dc_claim_functionality', '', 'yes'),
(368, 'w2dc_claim_approval', '', 'yes'),
(369, 'w2dc_after_claim', 'active', 'yes'),
(370, 'w2dc_hide_claim_contact_form', '', 'yes'),
(371, 'w2dc_claim_notification', '', 'yes'),
(372, 'w2dc_claim_approval_notification', '', 'yes'),
(373, 'w2dc_newlisting_admin_notification', '', 'yes'),
(374, 'w2dc_enable_tags', '1', 'yes'),
(375, 'w2dc_tospage', '20', 'yes'),
(376, 'w2dc_hide_claim_metabox', '', 'yes'),
(377, 'w2dc_submit_login_page', '10', 'yes'),
(378, 'w2dc_dashboard_login_page', '15', 'yes'),
(379, 'w2dc_installed_fsubmit', '1', 'yes'),
(380, 'w2dc_only_registered_users', '', 'yes'),
(381, 'w2dc_rating_on_map', '1', 'yes'),
(382, 'w2dc_manage_ratings', '', 'yes'),
(383, 'w2dc_orderby_rating', '1', 'yes'),
(384, 'w2dc_installed_ratings', '1', 'yes'),
(385, 'theme_mods_twentyfifteen', 'a:2:{s:18:"nav_menu_locations";a:1:{s:7:"primary";i:54;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1462529172;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(386, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(391, '_transient_twentyfifteen_categories', '1', 'yes'),
(392, 'template_root', '/themes', 'yes'),
(393, 'stylesheet_root', '/themes', 'yes'),
(394, 'current_theme', 'Storefront', 'yes'),
(395, 'theme_mods_storefront', 'a:13:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:7:"primary";i:54;s:8:"handheld";i:54;s:9:"secondary";i:400;}s:17:"storefront_layout";s:4:"left";s:17:"storefront_styles";s:4645:"\n			.main-navigation ul li a,\n			.site-title a,\n			ul.menu li a,\n			.site-branding h1 a,\n			.site-footer .storefront-handheld-footer-bar a:not(.button),\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				color: #ffffff;\n			}\n\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				border-color: #ffffff;\n			}\n\n			.main-navigation ul li a:hover,\n			.main-navigation ul li:hover > a,\n			.site-title a:hover,\n			a.cart-contents:hover,\n			.site-header-cart .widget_shopping_cart a:hover,\n			.site-header-cart:hover > li > a,\n			.site-header ul.menu li.current-menu-item > a {\n				color: #ffffff;\n			}\n\n			table th {\n				background-color: #f8f8f8;\n			}\n\n			table tbody td {\n				background-color: #fdfdfd;\n			}\n\n			table tbody tr:nth-child(2n) td {\n				background-color: #fbfbfb;\n			}\n\n			.site-header,\n			.secondary-navigation ul ul,\n			.main-navigation ul.menu > li.menu-item-has-children:after,\n			.secondary-navigation ul.menu ul,\n			.storefront-handheld-footer-bar,\n			.storefront-handheld-footer-bar ul li > a,\n			.storefront-handheld-footer-bar ul li.search .site-search,\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				background-color: #81d742;\n			}\n\n			p.site-description,\n			.site-header,\n			.storefront-handheld-footer-bar {\n				color: #ffffff;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count,\n			button.menu-toggle:after,\n			button.menu-toggle:before,\n			button.menu-toggle span:before {\n				background-color: #ffffff;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count {\n				color: #81d742;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count {\n				border-color: #81d742;\n			}\n\n			h1, h2, h3, h4, h5, h6 {\n				color: #484c51;\n			}\n\n			.widget h1 {\n				border-bottom-color: #484c51;\n			}\n\n			body,\n			.secondary-navigation a,\n			.onsale,\n			.pagination .page-numbers li .page-numbers:not(.current), .woocommerce-pagination .page-numbers li .page-numbers:not(.current) {\n				color: #43454b;\n			}\n\n			.widget-area .widget a,\n			.hentry .entry-header .posted-on a,\n			.hentry .entry-header .byline a {\n				color: #75777d;\n			}\n\n			a  {\n				color: #cccccc;\n			}\n\n			a:focus,\n			.button:focus,\n			.button.alt:focus,\n			.button.added_to_cart:focus,\n			.button.wc-forward:focus,\n			button:focus,\n			input[type="button"]:focus,\n			input[type="reset"]:focus,\n			input[type="submit"]:focus {\n				outline-color: #cccccc;\n			}\n\n			button, input[type="button"], input[type="reset"], input[type="submit"], .button, .added_to_cart, .widget a.button, .site-header-cart .widget_shopping_cart a.button {\n				background-color: #cccccc;\n				border-color: #cccccc;\n				color: #ffffff;\n			}\n\n			button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, .button:hover, .added_to_cart:hover, .widget a.button:hover, .site-header-cart .widget_shopping_cart a.button:hover {\n				background-color: #b3b3b3;\n				border-color: #b3b3b3;\n				color: #ffffff;\n			}\n\n			button.alt, input[type="button"].alt, input[type="reset"].alt, input[type="submit"].alt, .button.alt, .added_to_cart.alt, .widget-area .widget a.button.alt, .added_to_cart, .pagination .page-numbers li .page-numbers.current, .woocommerce-pagination .page-numbers li .page-numbers.current, .widget a.button.checkout {\n				background-color: #2c2d33;\n				border-color: #2c2d33;\n				color: #ffffff;\n			}\n\n			button.alt:hover, input[type="button"].alt:hover, input[type="reset"].alt:hover, input[type="submit"].alt:hover, .button.alt:hover, .added_to_cart.alt:hover, .widget-area .widget a.button.alt:hover, .added_to_cart:hover, .widget a.button.checkout:hover {\n				background-color: #13141a;\n				border-color: #13141a;\n				color: #ffffff;\n			}\n\n			#comments .comment-list .comment-content .comment-text {\n				background-color: #f8f8f8;\n			}\n\n			.site-footer {\n				background-color: #000000;\n				color: #61656b;\n			}\n\n			.site-footer a:not(.button) {\n				color: #2c2d33;\n			}\n\n			.site-footer h1, .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5, .site-footer h6 {\n				color: #494c50;\n			}\n\n			#order_review,\n			#payment .payment_methods > li .payment_box {\n				background-color: #ffffff;\n			}\n\n			#payment .payment_methods > li {\n				background-color: #fafafa;\n			}\n\n			#payment .payment_methods > li:hover {\n				background-color: #f5f5f5;\n			}\n\n			@media screen and ( min-width: 768px ) {\n				.secondary-navigation ul.menu a:hover {\n					color: #ffffff;\n				}\n\n				.secondary-navigation ul.menu a {\n					color: #ffffff;\n				}\n\n				.site-header-cart .widget_shopping_cart,\n				.main-navigation ul.menu ul.sub-menu,\n				.main-navigation ul.nav-menu ul.children {\n					background-color: #79cf3a;\n				}\n			}";s:29:"storefront_woocommerce_styles";s:1597:"\n			a.cart-contents,\n			.site-header-cart .widget_shopping_cart a {\n				color: #ffffff;\n			}\n\n			table.cart td.product-remove,\n			table.cart td.actions {\n				border-top-color: #ffffff;\n			}\n\n			.woocommerce-tabs ul.tabs li.active a,\n			ul.products li.product .price,\n			.onsale,\n			.widget_search form:before,\n			.widget_product_search form:before {\n				color: #43454b;\n			}\n\n			.woocommerce-breadcrumb a,\n			a.woocommerce-review-link,\n			.product_meta a {\n				color: #75777d;\n			}\n\n			.onsale {\n				border-color: #43454b;\n			}\n\n			.star-rating span:before,\n			.quantity .plus, .quantity .minus,\n			p.stars a:hover:after,\n			p.stars a:after,\n			.star-rating span:before,\n			#payment .payment_methods li input[type=radio]:first-child:checked+label:before {\n				color: #cccccc;\n			}\n\n			.widget_price_filter .ui-slider .ui-slider-range,\n			.widget_price_filter .ui-slider .ui-slider-handle {\n				background-color: #cccccc;\n			}\n\n			.woocommerce-breadcrumb,\n			#reviews .commentlist li .comment_container {\n				background-color: #f8f8f8;\n			}\n\n			.order_details {\n				background-color: #f8f8f8;\n			}\n\n			.order_details li {\n				border-bottom: 1px dotted #e3e3e3;\n			}\n\n			.order_details:before,\n			.order_details:after {\n				background: -webkit-linear-gradient(transparent 0,transparent 0),-webkit-linear-gradient(135deg,#f8f8f8 33.33%,transparent 33.33%),-webkit-linear-gradient(45deg,#f8f8f8 33.33%,transparent 33.33%)\n			}\n\n			@media screen and ( min-width: 768px ) {\n				.site-header-cart .widget_shopping_cart,\n				.site-header .product_list_widget li .quantity {\n					color: #ffffff;\n				}\n			}";s:11:"custom_logo";i:110;s:23:"storefront_accent_color";s:7:"#cccccc";s:34:"storefront_header_background_color";s:7:"#81d742";s:28:"storefront_header_text_color";s:7:"#ffffff";s:28:"storefront_header_link_color";s:7:"#ffffff";s:34:"storefront_button_background_color";s:7:"#cccccc";s:34:"storefront_footer_background_color";s:7:"#000000";s:39:"storefront_woocommerce_extension_styles";s:0:"";}', 'yes'),
(396, 'theme_switched', '', 'yes'),
(402, 'woocommerce_default_country', 'DK', 'yes'),
(403, 'woocommerce_allowed_countries', 'all', 'yes'),
(404, 'woocommerce_specific_allowed_countries', '', 'yes'),
(405, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(406, 'woocommerce_demo_store', 'no', 'yes'),
(407, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'no'),
(408, 'woocommerce_currency', 'DKK', 'yes'),
(409, 'woocommerce_currency_pos', 'left_space', 'yes'),
(410, 'woocommerce_price_thousand_sep', ',', 'yes'),
(411, 'woocommerce_price_decimal_sep', ',', 'yes'),
(412, 'woocommerce_price_num_decimals', '2', 'yes'),
(413, 'woocommerce_weight_unit', 'kg', 'yes'),
(414, 'woocommerce_dimension_unit', 'cm', 'yes'),
(415, 'woocommerce_enable_review_rating', 'yes', 'no'),
(416, 'woocommerce_review_rating_required', 'yes', 'no'),
(417, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(418, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(419, 'woocommerce_shop_page_id', '24', 'yes'),
(420, 'woocommerce_shop_page_display', '', 'yes'),
(421, 'woocommerce_category_archive_display', '', 'yes'),
(422, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(423, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(424, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(425, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";i:1;}', 'yes'),
(426, 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"600";s:6:"height";s:3:"600";s:4:"crop";i:1;}', 'yes'),
(427, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:3:"180";s:6:"height";s:3:"180";s:4:"crop";i:1;}', 'yes'),
(428, 'woocommerce_enable_lightbox', 'yes', 'yes'),
(429, 'woocommerce_manage_stock', 'yes', 'yes'),
(430, 'woocommerce_hold_stock_minutes', '60', 'no'),
(431, 'woocommerce_notify_low_stock', 'yes', 'no'),
(432, 'woocommerce_notify_no_stock', 'yes', 'no'),
(433, 'woocommerce_stock_email_recipient', 'sde.thom855j@gmail.com', 'no'),
(434, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(435, 'woocommerce_notify_no_stock_amount', '0', 'no'),
(436, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(437, 'woocommerce_stock_format', '', 'yes'),
(438, 'woocommerce_file_download_method', 'force', 'no'),
(439, 'woocommerce_downloads_require_login', 'no', 'no'),
(440, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(441, 'woocommerce_calc_taxes', 'no', 'yes'),
(442, 'woocommerce_prices_include_tax', 'no', 'yes'),
(443, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(444, 'woocommerce_shipping_tax_class', 'title', 'yes'),
(445, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(446, 'woocommerce_tax_classes', 'Reduced Rate\r\nZero Rate', 'yes'),
(447, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(448, 'woocommerce_tax_display_cart', 'excl', 'no'),
(449, 'woocommerce_price_display_suffix', '', 'yes'),
(450, 'woocommerce_tax_total_display', 'itemized', 'no'),
(451, 'woocommerce_enable_coupons', 'yes', 'no'),
(452, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(453, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(454, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(455, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(456, 'woocommerce_cart_page_id', '25', 'yes'),
(457, 'woocommerce_checkout_page_id', '26', 'yes'),
(458, 'woocommerce_terms_page_id', '', 'no'),
(459, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(460, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(461, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(462, 'woocommerce_calc_shipping', 'no', 'yes'),
(463, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(464, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(465, 'woocommerce_ship_to_destination', 'billing', 'no'),
(466, 'woocommerce_ship_to_countries', 'disabled', 'yes'),
(467, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(468, 'woocommerce_myaccount_page_id', '27', 'yes'),
(469, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(470, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(471, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(472, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(473, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(474, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(475, 'woocommerce_enable_myaccount_registration', 'yes', 'no'),
(476, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(477, 'woocommerce_registration_generate_username', 'yes', 'no'),
(478, 'woocommerce_registration_generate_password', 'yes', 'no'),
(479, 'woocommerce_email_from_name', 'øko-info', 'no'),
(480, 'woocommerce_email_from_address', 'sde.thom855j@gmail.com', 'no'),
(481, 'woocommerce_email_header_image', '', 'no'),
(482, 'woocommerce_email_footer_text', 'øko-info - Powered by WooCommerce', 'no'),
(483, 'woocommerce_email_base_color', '#557da1', 'no'),
(484, 'woocommerce_email_background_color', '#f5f5f5', 'no'),
(485, 'woocommerce_email_body_background_color', '#fdfdfd', 'no'),
(486, 'woocommerce_email_text_color', '#505050', 'no'),
(487, 'woocommerce_api_enabled', 'yes', 'yes'),
(489, 'woocommerce_admin_notices', 'a:1:{i:1;s:15:"legacy_shipping";}', 'yes'),
(495, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(496, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(497, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(498, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(499, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(500, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(501, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(502, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(503, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(504, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(505, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(506, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(509, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(517, 'woocommerce_paypal_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(518, 'woocommerce_cheque_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(519, 'woocommerce_cod_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(520, 'woocommerce_bacs_settings', 'a:1:{s:7:"enabled";s:3:"yes";}', 'yes'),
(521, 'woocommerce_allow_tracking', 'no', 'yes'),
(548, 'wpseo', 'a:14:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:5:"3.4.2";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(549, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes');
INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(550, 'wpseo_titles', 'a:128:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:23:"content-analysis-active";b:1;s:9:"separator";s:7:"sc-pipe";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:45:"%%name%%, Forfatter på %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:62:"Du søgte efter %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:43:"Siden blev ikke fundet %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:0;s:18:"title-w2dc_listing";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-w2dc_listing";s:0:"";s:20:"metakey-w2dc_listing";s:0:"";s:20:"noindex-w2dc_listing";b:0;s:21:"showdate-w2dc_listing";b:0;s:24:"hideeditbox-w2dc_listing";b:0;s:13:"title-product";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"metadesc-product";s:0:"";s:15:"metakey-product";s:0:"";s:15:"noindex-product";b:0;s:16:"showdate-product";b:0;s:19:"hideeditbox-product";b:0;s:23:"title-kbe_knowledgebase";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:26:"metadesc-kbe_knowledgebase";s:0:"";s:25:"metakey-kbe_knowledgebase";s:0:"";s:25:"noindex-kbe_knowledgebase";b:0;s:26:"showdate-kbe_knowledgebase";b:0;s:29:"hideeditbox-kbe_knowledgebase";b:0;s:28:"title-ptarchive-w2dc_listing";s:49:"%%pt_plural%% Arkiv %%page%% %%sep%% %%sitename%%";s:31:"metadesc-ptarchive-w2dc_listing";s:0:"";s:30:"metakey-ptarchive-w2dc_listing";s:0:"";s:30:"bctitle-ptarchive-w2dc_listing";s:0:"";s:30:"noindex-ptarchive-w2dc_listing";b:0;s:23:"title-ptarchive-product";s:49:"%%pt_plural%% Arkiv %%page%% %%sep%% %%sitename%%";s:26:"metadesc-ptarchive-product";s:0:"";s:25:"metakey-ptarchive-product";s:0:"";s:25:"bctitle-ptarchive-product";s:0:"";s:25:"noindex-ptarchive-product";b:0;s:33:"title-ptarchive-kbe_knowledgebase";s:49:"%%pt_plural%% Arkiv %%page%% %%sep%% %%sitename%%";s:36:"metadesc-ptarchive-kbe_knowledgebase";s:0:"";s:35:"metakey-ptarchive-kbe_knowledgebase";s:0:"";s:35:"bctitle-ptarchive-kbe_knowledgebase";s:0:"";s:35:"noindex-ptarchive-kbe_knowledgebase";b:0;s:23:"title-tax-w2dc-category";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:26:"metadesc-tax-w2dc-category";s:0:"";s:25:"metakey-tax-w2dc-category";s:0:"";s:29:"hideeditbox-tax-w2dc-category";b:0;s:25:"noindex-tax-w2dc-category";b:0;s:23:"title-tax-w2dc-location";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:26:"metadesc-tax-w2dc-location";s:0:"";s:25:"metakey-tax-w2dc-location";s:0:"";s:29:"hideeditbox-tax-w2dc-location";b:0;s:25:"noindex-tax-w2dc-location";b:0;s:18:"title-tax-w2dc-tag";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-w2dc-tag";s:0:"";s:20:"metakey-tax-w2dc-tag";s:0:"";s:24:"hideeditbox-tax-w2dc-tag";b:0;s:20:"noindex-tax-w2dc-tag";b:0;s:22:"title-tax-kbe_taxonomy";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:25:"metadesc-tax-kbe_taxonomy";s:0:"";s:24:"metakey-tax-kbe_taxonomy";s:0:"";s:28:"hideeditbox-tax-kbe_taxonomy";b:0;s:24:"noindex-tax-kbe_taxonomy";b:0;s:18:"title-tax-kbe_tags";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-kbe_tags";s:0:"";s:20:"metakey-tax-kbe_tags";s:0:"";s:24:"hideeditbox-tax-kbe_tags";b:0;s:20:"noindex-tax-kbe_tags";b:0;s:21:"title-tax-product_cat";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-product_cat";s:0:"";s:23:"metakey-tax-product_cat";s:0:"";s:27:"hideeditbox-tax-product_cat";b:0;s:23:"noindex-tax-product_cat";b:0;s:21:"title-tax-product_tag";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-product_tag";s:0:"";s:23:"metakey-tax-product_tag";s:0:"";s:27:"hideeditbox-tax-product_tag";b:0;s:23:"noindex-tax-product_tag";b:0;s:32:"title-tax-product_shipping_class";s:50:"%%term_title%% Arkiv %%page%% %%sep%% %%sitename%%";s:35:"metadesc-tax-product_shipping_class";s:0:"";s:34:"metakey-tax-product_shipping_class";s:0:"";s:38:"hideeditbox-tax-product_shipping_class";b:0;s:34:"noindex-tax-product_shipping_class";b:0;}', 'yes'),
(551, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"39a164a33ddc181fc9e42943314a20c7";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(552, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:64:"Indlægget %%POSTLINK%% blev vist første gang den %%BLOGLINK%%.";}', 'yes'),
(553, 'wpseo_internallinks', 'a:18:{s:20:"breadcrumbs-404crumb";s:32:"Fejl 404: Siden blev ikke fundet";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:11:"Arkiver for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Hjem";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:15:"Du søgte efter";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;s:31:"post_types-w2dc_listing-maintax";i:0;s:26:"post_types-product-maintax";i:0;s:31:"taxonomy-w2dc-category-ptparent";i:0;s:31:"taxonomy-w2dc-location-ptparent";i:0;s:26:"taxonomy-w2dc-tag-ptparent";i:0;s:29:"taxonomy-product_cat-ptparent";i:0;s:29:"taxonomy-product_tag-ptparent";i:0;s:40:"taxonomy-product_shipping_class-ptparent";i:0;}', 'yes'),
(554, 'wpseo_xml', 'a:26:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:33:"user_role-customer-not_in_sitemap";b:0;s:37:"user_role-shop_manager-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:38:"post_types-w2dc_listing-not_in_sitemap";b:0;s:33:"post_types-product-not_in_sitemap";b:0;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;s:39:"taxonomies-w2dc-category-not_in_sitemap";b:0;s:39:"taxonomies-w2dc-location-not_in_sitemap";b:0;s:34:"taxonomies-w2dc-tag-not_in_sitemap";b:0;s:37:"taxonomies-product_cat-not_in_sitemap";b:0;s:37:"taxonomies-product_tag-not_in_sitemap";b:0;s:48:"taxonomies-product_shipping_class-not_in_sitemap";b:0;}', 'yes'),
(555, 'wpseo_flush_rewrite', '1', 'yes'),
(558, 'w3tc_request_data', '', 'no'),
(588, 'wpseo_sitemap_1_cache_validator', '4fiL', 'no'),
(589, 'wpseo_sitemap_revision_cache_validator', 'xlV1', 'no'),
(590, 'wpseo_sitemap_page_cache_validator', '4De9F', 'no'),
(591, 'wpseo_sitemap_post_cache_validator', '53s9M', 'no'),
(592, 'wpseo_sitemap_product_cache_validator', '5cK71', 'yes'),
(593, 'wpseo_sitemap_w2dc_listing_cache_validator', '6joCo', 'no'),
(622, 'wpseo_sitemap_w2dc-tag_cache_validator', '6jksO', 'no'),
(623, 'wpseo_taxonomy_meta', 'a:3:{s:8:"w2dc-tag";a:1:{i:85;a:1:{s:13:"wpseo_linkdex";s:2:"21";}}s:13:"w2dc-category";a:1:{i:109;a:1:{s:13:"wpseo_linkdex";s:2:"16";}}s:13:"w2dc-location";a:3:{i:235;a:1:{s:13:"wpseo_linkdex";s:2:"15";}i:236;a:1:{s:13:"wpseo_linkdex";s:2:"15";}i:234;a:1:{s:13:"wpseo_linkdex";s:2:"15";}}}', 'yes'),
(629, 'wpseo_sitemap_nav_menu_item_cache_validator', '4DD69', 'no'),
(631, 'wpseo_sitemap_cache_validator_global', '6iFkx', 'no'),
(634, 'wpseo_sitemap_nav_menu_cache_validator', '4DD65', 'no'),
(647, 'kbe_settings', 'a:8:{s:15:"kbe_plugin_slug";s:9:"bibliotek";s:15:"kbe_article_qty";i:5;s:18:"kbe_search_setting";i:0;s:23:"kbe_breadcrumbs_setting";i:0;s:16:"kbe_sidebar_home";i:2;s:17:"kbe_sidebar_inner";i:0;s:20:"kbe_comments_setting";i:0;s:11:"kbe_bgcolor";s:0:"";}', 'yes'),
(649, 'widget_kbe_article_widgets', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(674, 'ws_menu_editor', 'a:19:{s:22:"hide_advanced_settings";b:1;s:16:"show_extra_icons";b:0;s:11:"custom_menu";a:3:{s:4:"tree";a:23:{s:9:"index.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Forside";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:101:"Opdateringer <span class=''update-plugins count-0'' title=''''><span class=''update-count''>0</span></span>";s:12:"access_level";s:11:"update_core";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"update-core.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:15:"update-core.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Kontrolpanel";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";s:43:"menu-top menu-top-first menu-icon-dashboard";s:8:"hookname";s:14:"menu-dashboard";s:8:"icon_url";s:19:"dashicons-dashboard";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_4";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_4";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:31:"edit.php?post_type=w2dc_listing";a:31:{s:10:"page_title";N;s:10:"menu_title";s:16:"De grønne sider";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:32:">edit.php?post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:5:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:63:"edit.php?post_type=w2dc_listing>edit.php?post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:18:"Directory listings";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit.php?post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:31:"edit.php?post_type=w2dc_listing";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:63:"edit.php?post_type=w2dc_listing>edit.php?post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit.php?post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:67:"edit.php?post_type=w2dc_listing>post-new.php?post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:18:"Create new listing";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:35:"post-new.php?post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:31:"edit.php?post_type=w2dc_listing";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:67:"edit.php?post_type=w2dc_listing>post-new.php?post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:35:"post-new.php?post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:95:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-category&amp;post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:20:"Directory categories";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:63:"edit-tags.php?taxonomy=w2dc-category&amp;post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:31:"edit.php?post_type=w2dc_listing";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:95:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-category&amp;post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:59:"edit-tags.php?taxonomy=w2dc-category&post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:95:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-location&amp;post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:19:"Directory locations";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:63:"edit-tags.php?taxonomy=w2dc-location&amp;post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:31:"edit.php?post_type=w2dc_listing";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:95:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-location&amp;post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:59:"edit-tags.php?taxonomy=w2dc-location&post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:90:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-tag&amp;post_type=w2dc_listing";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Directory tags";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:58:"edit-tags.php?taxonomy=w2dc-tag&amp;post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:31:"edit.php?post_type=w2dc_listing";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:90:"edit.php?post_type=w2dc_listing>edit-tags.php?taxonomy=w2dc-tag&amp;post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:54:"edit-tags.php?taxonomy=w2dc-tag&post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:18:"Directory listings";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit.php?post_type=w2dc_listing";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";s:31:"menu-top menu-icon-w2dc_listing";s:8:"hookname";s:23:"menu-posts-w2dc_listing";s:8:"icon_url";s:130:"https://project08.websupport.dk/app/plugins/codecanyon-6463373-web-20-directory-plugin-for-wordpress/resources/images/menuicon.png";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:32:">edit.php?post_type=w2dc_listing";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit.php?post_type=w2dc_listing";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:24:"edit.php?post_type=event";a:32:{s:10:"page_title";N;s:10:"menu_title";s:8:"Kalender";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:">edit.php?post_type=event";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:9:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:49:"edit.php?post_type=event>edit.php?post_type=event";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Events";s:12:"access_level";s:11:"edit_events";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"edit.php?post_type=event";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:49:"edit.php?post_type=event>edit.php?post_type=event";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:24:"edit.php?post_type=event";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:53:"edit.php?post_type=event>post-new.php?post_type=event";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:13:"Tilføj event";s:12:"access_level";s:11:"edit_events";s:16:"extra_capability";s:0:"";s:4:"file";s:28:"post-new.php?post_type=event";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:53:"edit.php?post_type=event>post-new.php?post_type=event";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:28:"post-new.php?post_type=event";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:78:"edit.php?post_type=event>edit-tags.php?taxonomy=event-tags&amp;post_type=event";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Event tags";s:12:"access_level";s:21:"edit_event_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:53:"edit-tags.php?taxonomy=event-tags&amp;post_type=event";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:78:"edit.php?post_type=event>edit-tags.php?taxonomy=event-tags&amp;post_type=event";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:49:"edit-tags.php?taxonomy=event-tags&post_type=event";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:84:"edit.php?post_type=event>edit-tags.php?taxonomy=event-categories&amp;post_type=event";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Eventkategorier";s:12:"access_level";s:21:"edit_event_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:59:"edit-tags.php?taxonomy=event-categories&amp;post_type=event";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:84:"edit.php?post_type=event>edit-tags.php?taxonomy=event-categories&amp;post_type=event";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:55:"edit-tags.php?taxonomy=event-categories&post_type=event";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:52:"edit.php?post_type=event>edit.php?post_type=location";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:10:"Lokationer";s:10:"menu_title";s:10:"Lokationer";s:12:"access_level";s:14:"edit_locations";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"edit.php?post_type=location";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:52:"edit.php?post_type=event>edit.php?post_type=location";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"edit.php?post_type=location";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:59:"edit.php?post_type=event>edit.php?post_type=event-recurring";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:22:"Tilbagevendende events";s:10:"menu_title";s:22:"Tilbagevendende events";s:12:"access_level";s:21:"edit_recurring_events";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=event-recurring";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:59:"edit.php?post_type=event>edit.php?post_type=event-recurring";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=event-recurring";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:48:"edit.php?post_type=event>events-manager-bookings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:12:"Tilmeldinger";s:10:"menu_title";s:12:"Tilmeldinger";s:12:"access_level";s:15:"manage_bookings";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"events-manager-bookings";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:48:"edit.php?post_type=event>events-manager-bookings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:53:"edit.php?post_type=event&page=events-manager-bookings";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:47:"edit.php?post_type=event>events-manager-options";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:27:"Event Manager indstillinger";s:10:"menu_title";s:13:"Indstillinger";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"events-manager-options";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:47:"edit.php?post_type=event>events-manager-options";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:52:"edit.php?post_type=event&page=events-manager-options";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:8;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:44:"edit.php?post_type=event>events-manager-help";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:29:"Få hjælp til Events manager";s:10:"menu_title";s:6:"Hjælp";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"events-manager-help";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:24:"edit.php?post_type=event";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:44:"edit.php?post_type=event>events-manager-help";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:49:"edit.php?post_type=event&page=events-manager-help";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Events";s:12:"access_level";s:11:"edit_events";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"edit.php?post_type=event";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-event";s:8:"hookname";s:16:"menu-posts-event";s:8:"icon_url";s:18:"dashicons-calendar";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:">edit.php?post_type=event";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:24:"edit.php?post_type=event";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}s:29:"required_capability_read_only";N;}s:8:"edit.php";a:31:{s:10:"page_title";N;s:10:"menu_title";s:7:"Aktuelt";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Alle indlæg";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Tilføj nyt";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"post-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"post-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Kategorier";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=category";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=category";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Tags";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=post_tag";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=post_tag";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Indlæg";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";s:37:"menu-top menu-icon-post open-if-no-js";s:8:"hookname";s:10:"menu-posts";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:32:"edit.php?post_type=knowledgebase";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:33:">edit.php?post_type=knowledgebase";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:65:"edit.php?post_type=knowledgebase>edit.php?post_type=knowledgebase";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"All Articles";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:32:"edit.php?post_type=knowledgebase";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:32:"edit.php?post_type=knowledgebase";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:65:"edit.php?post_type=knowledgebase>edit.php?post_type=knowledgebase";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:32:"edit.php?post_type=knowledgebase";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:69:"edit.php?post_type=knowledgebase>post-new.php?post_type=knowledgebase";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:36:"post-new.php?post_type=knowledgebase";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:32:"edit.php?post_type=knowledgebase";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:69:"edit.php?post_type=knowledgebase>post-new.php?post_type=knowledgebase";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:36:"post-new.php?post_type=knowledgebase";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:106:"edit.php?post_type=knowledgebase>edit-tags.php?taxonomy=knowledgebase_category&amp;post_type=knowledgebase";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Categories";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:73:"edit-tags.php?taxonomy=knowledgebase_category&amp;post_type=knowledgebase";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:32:"edit.php?post_type=knowledgebase";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:106:"edit.php?post_type=knowledgebase>edit-tags.php?taxonomy=knowledgebase_category&amp;post_type=knowledgebase";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:69:"edit-tags.php?taxonomy=knowledgebase_category&post_type=knowledgebase";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:102:"edit.php?post_type=knowledgebase>edit-tags.php?taxonomy=knowledgebase_tags&amp;post_type=knowledgebase";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Tags";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:69:"edit-tags.php?taxonomy=knowledgebase_tags&amp;post_type=knowledgebase";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:32:"edit.php?post_type=knowledgebase";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:102:"edit.php?post_type=knowledgebase>edit-tags.php?taxonomy=knowledgebase_tags&amp;post_type=knowledgebase";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:65:"edit-tags.php?taxonomy=knowledgebase_tags&post_type=knowledgebase";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Knowledge Base";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:32:"edit.php?post_type=knowledgebase";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";s:32:"menu-top menu-icon-knowledgebase";s:8:"hookname";s:24:"menu-posts-knowledgebase";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:33:">edit.php?post_type=knowledgebase";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:32:"edit.php?post_type=knowledgebase";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:26:"edit.php?post_type=product";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:">edit.php?post_type=product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:5:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:53:"edit.php?post_type=product>edit.php?post_type=product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Products";s:12:"access_level";s:13:"edit_products";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=product";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:26:"edit.php?post_type=product";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:53:"edit.php?post_type=product>edit.php?post_type=product";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:57:"edit.php?post_type=product>post-new.php?post_type=product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Add Product";s:12:"access_level";s:13:"edit_products";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"post-new.php?post_type=product";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:26:"edit.php?post_type=product";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:57:"edit.php?post_type=product>post-new.php?post_type=product";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"post-new.php?post_type=product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:83:"edit.php?post_type=product>edit-tags.php?taxonomy=product_cat&amp;post_type=product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Categories";s:12:"access_level";s:20:"manage_product_terms";s:16:"extra_capability";s:0:"";s:4:"file";s:56:"edit-tags.php?taxonomy=product_cat&amp;post_type=product";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:26:"edit.php?post_type=product";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:83:"edit.php?post_type=product>edit-tags.php?taxonomy=product_cat&amp;post_type=product";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:52:"edit-tags.php?taxonomy=product_cat&post_type=product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:83:"edit.php?post_type=product>edit-tags.php?taxonomy=product_tag&amp;post_type=product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Tags";s:12:"access_level";s:20:"manage_product_terms";s:16:"extra_capability";s:0:"";s:4:"file";s:56:"edit-tags.php?taxonomy=product_tag&amp;post_type=product";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:26:"edit.php?post_type=product";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:83:"edit.php?post_type=product>edit-tags.php?taxonomy=product_tag&amp;post_type=product";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:52:"edit-tags.php?taxonomy=product_tag&post_type=product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:45:"edit.php?post_type=product>product_attributes";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:10:"Attributes";s:10:"menu_title";s:10:"Attributes";s:12:"access_level";s:20:"manage_product_terms";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"product_attributes";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:26:"edit.php?post_type=product";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:45:"edit.php?post_type=product>product_attributes";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:50:"edit.php?post_type=product&page=product_attributes";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Products";s:12:"access_level";s:13:"edit_products";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=product";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";s:26:"menu-top menu-icon-product";s:8:"hookname";s:18:"menu-posts-product";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:">edit.php?post_type=product";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:10:"upload.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Bibliotek";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Tilf&#248;j ny";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"media-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"media-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Medier";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-media";s:8:"hookname";s:10:"menu-media";s:8:"icon_url";s:21:"dashicons-admin-media";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:23:"edit.php?post_type=page";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Alle sider";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Tilføj ny";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"post-new.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"post-new.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Sider";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";s:23:"menu-top menu-icon-page";s:8:"hookname";s:10:"menu-pages";s:8:"icon_url";s:20:"dashicons-admin-page";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:17:"edit-comments.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:1:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:16:"Alle kommentarer";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:17:"edit-comments.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:90:"Kommentarer <span class="awaiting-mod count-0"><span class="pending-count">0</span></span>";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";s:27:"menu-top menu-icon-comments";s:8:"hookname";s:13:"menu-comments";s:8:"icon_url";s:24:"dashicons-admin-comments";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_5";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_5";s:12:"page_heading";s:0:"";s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:10:"themes.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:10:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Temaer";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Tilpas";s:12:"access_level";s:9:"customize";s:16:"extra_capability";s:0:"";s:4:"file";s:80:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:80:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Widgets";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"widgets.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"widgets.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Menuer";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"nav-menus.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"nav-menus.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:65:"themes.php>customize.php?#038;autofocus%5Bcontrol%5D=header_image";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Header";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:121:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor&#038;autofocus%5Bcontrol%5D=header_image";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:65:"themes.php>customize.php?#038;autofocus%5Bcontrol%5D=header_image";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:116:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor&autofocus%5Bcontrol%5D=header_image";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:69:"themes.php>customize.php?#038;autofocus%5Bcontrol%5D=background_image";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Baggrund";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:125:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor&#038;autofocus%5Bcontrol%5D=background_image";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:69:"themes.php>customize.php?#038;autofocus%5Bcontrol%5D=background_image";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:120:"customize.php?return=%2Fwp%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor&autofocus%5Bcontrol%5D=background_image";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:29:"themes.php>storefront-welcome";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:10:"Storefront";s:10:"menu_title";s:10:"Storefront";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"storefront-welcome";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:29:"themes.php>storefront-welcome";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:34:"themes.php?page=storefront-welcome";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>w2dc_settings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"Directory settings";s:10:"menu_title";s:18:"Directory settings";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"w2dc_settings";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>w2dc_settings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"themes.php?page=w2dc_settings";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:8;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>custom-header";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:6:"Header";s:10:"menu_title";s:6:"Header";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"custom-header";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>custom-header";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"themes.php?page=custom-header";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:9;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:28:"themes.php>custom-background";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:8:"Baggrund";s:10:"menu_title";s:8:"Baggrund";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"custom-background";s:12:"page_heading";s:0:"";s:8:"position";i:9;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:28:"themes.php>custom-background";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:33:"themes.php?page=custom-background";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Udseende";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";s:29:"menu-top menu-icon-appearance";s:8:"hookname";s:15:"menu-appearance";s:8:"icon_url";s:26:"dashicons-admin-appearance";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"plugins.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:20:"Installerede plugins";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Tilf&#248;j nyt";s:12:"access_level";s:15:"install_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"plugin-install.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:18:"plugin-install.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:87:"Plugins <span class=''update-plugins count-0''><span class=''plugin-count''>0</span></span>";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";s:26:"menu-top menu-icon-plugins";s:8:"hookname";s:12:"menu-plugins";s:8:"icon_url";s:23:"dashicons-admin-plugins";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"users.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Alle brugere";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Tilføj ny";s:12:"access_level";s:12:"create_users";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"user-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"user-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Din profil";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"profile.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"profile.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Brugere";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-users";s:8:"hookname";s:10:"menu-users";s:8:"icon_url";s:21:"dashicons-admin-users";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"tools.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:25:"Tilgængelige værktøjer";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Importer";s:12:"access_level";s:6:"import";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"import.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"import.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Eksporter";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"export.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"export.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"tools.php>redirection.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"Redirection";s:10:"menu_title";s:11:"Redirection";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"redirection.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"tools.php>redirection.php";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"tools.php?page=redirection.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:19:"V&#230;rkt&#248;jer";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";s:24:"menu-top menu-icon-tools";s:8:"hookname";s:10:"menu-tools";s:8:"icon_url";s:21:"dashicons-admin-tools";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:13:"w2dc_settings";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:14:">w2dc_settings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:6:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w2dc_settings>w2dc_settings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"Directory Settings";s:10:"menu_title";s:18:"Directory Settings";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"w2dc_settings";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w2dc_settings>w2dc_settings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"admin.php?page=w2dc_settings";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"w2dc_settings>w2dc_levels";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:15:"Listings levels";s:10:"menu_title";s:15:"Listings levels";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"w2dc_levels";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"w2dc_settings>w2dc_levels";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=w2dc_levels";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:34:"w2dc_settings>w2dc_manage_upgrades";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:16:"Listings upgrade";s:10:"menu_title";s:16:"Listings upgrade";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:20:"w2dc_manage_upgrades";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:34:"w2dc_settings>w2dc_manage_upgrades";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:35:"admin.php?page=w2dc_manage_upgrades";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:35:"w2dc_settings>w2dc_locations_levels";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:16:"Locations levels";s:10:"menu_title";s:16:"Locations levels";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"w2dc_locations_levels";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:35:"w2dc_settings>w2dc_locations_levels";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"admin.php?page=w2dc_locations_levels";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:33:"w2dc_settings>w2dc_content_fields";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:14:"Content fields";s:10:"menu_title";s:14:"Content fields";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"w2dc_content_fields";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:33:"w2dc_settings>w2dc_content_fields";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:34:"admin.php?page=w2dc_content_fields";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:29:"w2dc_settings>w2dc_csv_import";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:10:"CSV Import";s:10:"menu_title";s:10:"CSV Import";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"w2dc_csv_import";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:13:"w2dc_settings";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:29:"w2dc_settings>w2dc_csv_import";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=w2dc_csv_import";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"Directory Settings";s:10:"menu_title";s:15:"Directory Admin";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"w2dc_settings";s:12:"page_heading";s:0:"";s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";s:36:"menu-top toplevel_page_w2dc_settings";s:8:"hookname";s:27:"toplevel_page_w2dc_settings";s:8:"icon_url";s:130:"https://project08.websupport.dk/app/plugins/codecanyon-6463373-web-20-directory-plugin-for-wordpress/resources/images/menuicon.png";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:14:">w2dc_settings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"admin.php?page=w2dc_settings";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"woocommerce";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:16;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">woocommerce";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:6:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:41:"woocommerce>edit.php?post_type=shop_order";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:6:"Orders";s:10:"menu_title";s:6:"Orders";s:12:"access_level";s:16:"edit_shop_orders";s:16:"extra_capability";s:0:"";s:4:"file";s:29:"edit.php?post_type=shop_order";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:41:"woocommerce>edit.php?post_type=shop_order";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:29:"edit.php?post_type=shop_order";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:42:"woocommerce>edit.php?post_type=shop_coupon";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:7:"Coupons";s:10:"menu_title";s:7:"Coupons";s:12:"access_level";s:17:"edit_shop_coupons";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=shop_coupon";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:42:"woocommerce>edit.php?post_type=shop_coupon";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=shop_coupon";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:22:"woocommerce>wc-reports";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:7:"Reports";s:10:"menu_title";s:7:"Reports";s:12:"access_level";s:24:"view_woocommerce_reports";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"wc-reports";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:22:"woocommerce>wc-reports";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:25:"admin.php?page=wc-reports";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"woocommerce>wc-settings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:20:"WooCommerce Settings";s:10:"menu_title";s:8:"Settings";s:12:"access_level";s:18:"manage_woocommerce";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"wc-settings";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"woocommerce>wc-settings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=wc-settings";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"woocommerce>wc-status";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"WooCommerce Status";s:10:"menu_title";s:13:"System Status";s:12:"access_level";s:18:"manage_woocommerce";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"wc-status";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"woocommerce>wc-status";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:24:"admin.php?page=wc-status";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"woocommerce>wc-addons";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:30:"WooCommerce Add-ons/Extensions";s:10:"menu_title";s:7:"Add-ons";s:12:"access_level";s:18:"manage_woocommerce";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"wc-addons";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:11:"woocommerce";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"woocommerce>wc-addons";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:24:"admin.php?page=wc-addons";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"WooCommerce";s:10:"menu_title";s:11:"WooCommerce";s:12:"access_level";s:18:"manage_woocommerce";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"woocommerce";s:12:"page_heading";s:0:"";s:8:"position";i:16;s:6:"parent";N;s:9:"css_class";s:52:"menu-top menu-icon-generic toplevel_page_woocommerce";s:8:"hookname";s:25:"toplevel_page_woocommerce";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">woocommerce";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"woocommerce";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:19:"options-general.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:17;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:8:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Generelt";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Skrivning";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-writing.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-writing.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"L&#230;sning";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-reading.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-reading.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Diskussion";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"options-discussion.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"options-discussion.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Medier";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"options-media.php";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"options-media.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:16:"Permanente links";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"options-permalink.php";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:21:"options-permalink.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:54:"options-general.php>header-and-footer-scripts/shfs.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:25:"Header and Footer Scripts";s:10:"menu_title";s:25:"Header and Footer Scripts";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"header-and-footer-scripts/shfs.php";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:54:"options-general.php>header-and-footer-scripts/shfs.php";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:59:"options-general.php?page=header-and-footer-scripts/shfs.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"Menu Editor";s:10:"menu_title";s:11:"Menu Editor";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"menu_editor";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"options-general.php?page=menu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:13:"Indstillinger";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:17;s:6:"parent";N;s:9:"css_class";s:27:"menu-top menu-icon-settings";s:8:"hookname";s:13:"menu-settings";s:8:"icon_url";s:24:"dashicons-admin-settings";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_6";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:18;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_6";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_6";s:12:"page_heading";s:0:"";s:8:"position";i:18;s:6:"parent";N;s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_6";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"wpseo_dashboard";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:19;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:16:">wpseo_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:8:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:31:"wpseo_dashboard>wpseo_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:19:"Generel - Yoast SEO";s:10:"menu_title";s:9:"Dashboard";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"wpseo_dashboard";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:31:"wpseo_dashboard>wpseo_dashboard";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=wpseo_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_titles";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:29:"Titler &amp; Meta - Yoast SEO";s:10:"menu_title";s:17:"Titler &amp; Meta";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"wpseo_titles";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_titles";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=wpseo_titles";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_social";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"Social - Yoast SEO";s:10:"menu_title";s:6:"Social";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"wpseo_social";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:28:"wpseo_dashboard>wpseo_social";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=wpseo_social";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"wpseo_dashboard>wpseo_xml";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:24:"XML Sitemaps - Yoast SEO";s:10:"menu_title";s:12:"XML Sitemaps";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"wpseo_xml";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"wpseo_dashboard>wpseo_xml";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:24:"admin.php?page=wpseo_xml";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_advanced";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:21:"Avanceret - Yoast SEO";s:10:"menu_title";s:9:"Avanceret";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"wpseo_advanced";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_advanced";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=wpseo_advanced";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"wpseo_dashboard>wpseo_tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:23:"Værktøjer - Yoast SEO";s:10:"menu_title";s:11:"Værktøjer";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"wpseo_tools";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"wpseo_dashboard>wpseo_tools";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=wpseo_tools";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:36:"wpseo_dashboard>wpseo_search_console";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:23:"Søgekonsol - Yoast SEO";s:10:"menu_title";s:11:"Søgekonsol";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:20:"wpseo_search_console";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:36:"wpseo_dashboard>wpseo_search_console";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:35:"admin.php?page=wpseo_search_console";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_licenses";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:57:"<span style="color:#f18500">Udvidelser</span> - Yoast SEO";s:10:"menu_title";s:45:"<span style="color:#f18500">Udvidelser</span>";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"wpseo_licenses";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:15:"wpseo_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"wpseo_dashboard>wpseo_licenses";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=wpseo_licenses";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:20:"Yoast SEO: Dashboard";s:10:"menu_title";s:157:"SEO <span class="update-plugins count-2"><span class="plugin-count" aria-hidden="true">2</span><span class="screen-reader-text">2 notifications</span></span>";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"wpseo_dashboard";s:12:"page_heading";s:0:"";s:8:"position";i:19;s:6:"parent";N;s:9:"css_class";s:38:"menu-top toplevel_page_wpseo_dashboard";s:8:"hookname";s:29:"toplevel_page_wpseo_dashboard";s:8:"icon_url";s:1110:"data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgc3R5bGU9ImZpbGw6IzgyODc4YyIgdmlld0JveD0iMCAwIDUxMiA1MTIiPjxnPjxnPjxnPjxnPjxwYXRoIGQ9Ik0yMDMuNiwzOTVjNi44LTE3LjQsNi44LTM2LjYsMC01NGwtNzkuNC0yMDRoNzAuOWw0Ny43LDE0OS40bDc0LjgtMjA3LjZIMTE2LjRjLTQxLjgsMC03NiwzNC4yLTc2LDc2VjM1N2MwLDQxLjgsMzQuMiw3Niw3Niw3NkgxNzNDMTg5LDQyNC4xLDE5Ny42LDQxMC4zLDIwMy42LDM5NXoiLz48L2c+PGc+PHBhdGggZD0iTTQ3MS42LDE1NC44YzAtNDEuOC0zNC4yLTc2LTc2LTc2aC0zTDI4NS43LDM2NWMtOS42LDI2LjctMTkuNCw0OS4zLTMwLjMsNjhoMjE2LjJWMTU0Ljh6Ii8+PC9nPjwvZz48cGF0aCBzdHJva2Utd2lkdGg9IjIuOTc0IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIGQ9Ik0zMzgsMS4zbC05My4zLDI1OS4xbC00Mi4xLTEzMS45aC04OS4xbDgzLjgsMjE1LjJjNiwxNS41LDYsMzIuNSwwLDQ4Yy03LjQsMTktMTksMzcuMy01Myw0MS45bC03LjIsMXY3Nmg4LjNjODEuNywwLDExOC45LTU3LjIsMTQ5LjYtMTQyLjlMNDMxLjYsMS4zSDMzOHogTTI3OS40LDM2MmMtMzIuOSw5Mi02Ny42LDEyOC43LTEyNS43LDEzMS44di00NWMzNy41LTcuNSw1MS4zLTMxLDU5LjEtNTEuMWM3LjUtMTkuMyw3LjUtNDAuNywwLTYwbC03NS0xOTIuN2g1Mi44bDUzLjMsMTY2LjhsMTA1LjktMjk0aDU4LjFMMjc5LjQsMzYyeiIvPjwvZz48L2c+PC9zdmc+";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:16:">wpseo_dashboard";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=wpseo_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_7";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:20;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_7";s:12:"page_heading";s:0:"";s:8:"position";i:20;s:6:"parent";N;s:9:"css_class";s:29:"wp-menu-separator woocommerce";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_7";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:14:"w3tc_dashboard";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:21;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:15:">w3tc_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:16:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:29:"w3tc_dashboard>w3tc_dashboard";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:26:"Dashboard | W3 Total Cache";s:10:"menu_title";s:9:"Dashboard";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"w3tc_dashboard";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:29:"w3tc_dashboard>w3tc_dashboard";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=w3tc_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_general";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:33:"General Settings | W3 Total Cache";s:10:"menu_title";s:16:"General Settings";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"w3tc_general";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_general";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=w3tc_general";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_pgcache";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:27:"Page Cache | W3 Total Cache";s:10:"menu_title";s:10:"Page Cache";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"w3tc_pgcache";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_pgcache";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=w3tc_pgcache";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:26:"w3tc_dashboard>w3tc_minify";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:23:"Minify | W3 Total Cache";s:10:"menu_title";s:6:"Minify";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"w3tc_minify";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:26:"w3tc_dashboard>w3tc_minify";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=w3tc_minify";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_dbcache";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:31:"Database Cache | W3 Total Cache";s:10:"menu_title";s:14:"Database Cache";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"w3tc_dbcache";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_dbcache";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=w3tc_dbcache";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:31:"w3tc_dashboard>w3tc_objectcache";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:29:"Object Cache | W3 Total Cache";s:10:"menu_title";s:12:"Object Cache";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:16:"w3tc_objectcache";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:31:"w3tc_dashboard>w3tc_objectcache";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:31:"admin.php?page=w3tc_objectcache";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:32:"w3tc_dashboard>w3tc_browsercache";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:30:"Browser Cache | W3 Total Cache";s:10:"menu_title";s:13:"Browser Cache";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"w3tc_browsercache";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:32:"w3tc_dashboard>w3tc_browsercache";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:32:"admin.php?page=w3tc_browsercache";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:26:"w3tc_dashboard>w3tc_mobile";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:34:"User Agent Groups | W3 Total Cache";s:10:"menu_title";s:17:"User Agent Groups";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"w3tc_mobile";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:26:"w3tc_dashboard>w3tc_mobile";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=w3tc_mobile";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:8;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:28:"w3tc_dashboard>w3tc_referrer";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:32:"Referrer Groups | W3 Total Cache";s:10:"menu_title";s:15:"Referrer Groups";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"w3tc_referrer";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:28:"w3tc_dashboard>w3tc_referrer";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"admin.php?page=w3tc_referrer";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:9;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"w3tc_dashboard>w3tc_cdn";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:41:"Content Delivery Network | W3 Total Cache";s:10:"menu_title";s:55:"<acronym title="Content Delivery Network">CDN</acronym>";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"w3tc_cdn";s:12:"page_heading";s:0:"";s:8:"position";i:9;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"w3tc_dashboard>w3tc_cdn";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:23:"admin.php?page=w3tc_cdn";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:10;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"w3tc_dashboard>w3tc_monitoring";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:27:"Monitoring | W3 Total Cache";s:10:"menu_title";s:10:"Monitoring";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"w3tc_monitoring";s:12:"page_heading";s:0:"";s:8:"position";i:10;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"w3tc_dashboard>w3tc_monitoring";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=w3tc_monitoring";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:11;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"w3tc_dashboard>w3tc_extensions";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:27:"Extensions | W3 Total Cache";s:10:"menu_title";s:10:"Extensions";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"w3tc_extensions";s:12:"page_heading";s:0:"";s:8:"position";i:11;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"w3tc_dashboard>w3tc_extensions";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"admin.php?page=w3tc_extensions";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:12;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"w3tc_dashboard>w3tc_faq";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:20:"FAQ | W3 Total Cache";s:10:"menu_title";s:3:"FAQ";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"w3tc_faq";s:12:"page_heading";s:0:"";s:8:"position";i:12;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"w3tc_dashboard>w3tc_faq";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:23:"admin.php?page=w3tc_faq";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:13;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_support";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:24:"Support | W3 Total Cache";s:10:"menu_title";s:40:"<span style="color: red;">Support</span>";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"w3tc_support";s:12:"page_heading";s:0:"";s:8:"position";i:13;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_support";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=w3tc_support";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:14;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_install";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:24:"Install | W3 Total Cache";s:10:"menu_title";s:7:"Install";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"w3tc_install";s:12:"page_heading";s:0:"";s:8:"position";i:14;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"w3tc_dashboard>w3tc_install";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:27:"admin.php?page=w3tc_install";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:15;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"w3tc_dashboard>w3tc_about";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:22:"About | W3 Total Cache";s:10:"menu_title";s:5:"About";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"w3tc_about";s:12:"page_heading";s:0:"";s:8:"position";i:15;s:6:"parent";s:14:"w3tc_dashboard";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"w3tc_dashboard>w3tc_about";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:25:"admin.php?page=w3tc_about";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"Performance";s:10:"menu_title";s:11:"Performance";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"w3tc_dashboard";s:12:"page_heading";s:0:"";s:8:"position";i:21;s:6:"parent";N;s:9:"css_class";s:37:"menu-top toplevel_page_w3tc_dashboard";s:8:"hookname";s:28:"toplevel_page_w3tc_dashboard";s:8:"icon_url";s:3:"div";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:15:">w3tc_dashboard";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=w3tc_dashboard";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:25:"pressapps-knowledge-base_";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:22;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:26:">pressapps-knowledge-base_";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:50:"pressapps-knowledge-base_>pressapps-knowledge-base";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:14:"Knowledge Base";s:10:"menu_title";s:14:"Knowledge Base";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"pressapps-knowledge-base";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:25:"pressapps-knowledge-base_";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:50:"pressapps-knowledge-base_>pressapps-knowledge-base";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:39:"admin.php?page=pressapps-knowledge-base";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:43:"pressapps-knowledge-base_>pressapps-product";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:8:"Products";s:10:"menu_title";s:8:"Products";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"pressapps-product";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:25:"pressapps-knowledge-base_";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:43:"pressapps-knowledge-base_>pressapps-product";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:32:"admin.php?page=pressapps-product";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:40:"pressapps-knowledge-base_>pressapps-help";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:4:"Help";s:10:"menu_title";s:4:"Help";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"pressapps-help";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:25:"pressapps-knowledge-base_";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:40:"pressapps-knowledge-base_>pressapps-help";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:29:"admin.php?page=pressapps-help";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:9:"PressApps";s:10:"menu_title";s:9:"PressApps";s:12:"access_level";s:25:"pa-nonexistent-capability";s:16:"extra_capability";s:0:"";s:4:"file";s:25:"pressapps-knowledge-base_";s:12:"page_heading";s:0:"";s:8:"position";i:22;s:6:"parent";N;s:9:"css_class";s:66:"menu-top menu-icon-generic toplevel_page_pressapps-knowledge-base_";s:8:"hookname";s:39:"toplevel_page_pressapps-knowledge-base_";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:26:">pressapps-knowledge-base_";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:25:"pressapps-knowledge-base_";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:6:"format";a:3:{s:4:"name";s:22:"Admin Menu Editor menu";s:7:"version";s:3:"6.4";s:13:"is_normalized";b:1;}s:13:"color_presets";a:0:{}}s:18:"first_install_time";i:1463591169;s:21:"display_survey_notice";b:1;s:17:"plugin_db_version";i:140;s:24:"security_logging_enabled";b:0;s:17:"menu_config_scope";s:6:"global";s:13:"plugin_access";s:14:"manage_options";s:15:"allowed_user_id";N;s:28:"plugins_page_allowed_user_id";N;s:27:"show_deprecated_hide_button";b:1;s:37:"dashboard_hiding_confirmation_enabled";b:1;s:21:"submenu_icons_enabled";s:9:"if_custom";s:16:"ui_colour_scheme";s:7:"classic";s:13:"visible_users";a:0:{}s:23:"show_plugin_menu_notice";b:0;s:20:"unused_item_position";s:8:"relative";s:15:"error_verbosity";i:2;}', 'yes');
INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(690, '_transient_external_ip_address_127.0.0.1', '80.62.116.39', 'no'),
(707, 'wpseo_sitemap_w2dc-category_cache_validator', '6jksE', 'no'),
(774, 'wpseo_sitemap_kbe_taxonomy_cache_validator', 'tyPB', 'no'),
(782, 'wpseo_sitemap_kbe_knowledgebase_cache_validator', '5HdAA', 'no'),
(792, 'wpseo_sitemap_kbe_tags_cache_validator', '5HdBk', 'no'),
(814, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(815, 'woocommerce_all_except_countries', '', 'yes'),
(816, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(817, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(818, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(819, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(820, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(834, 'wpseo_sitemap_author_cache_validator', '3D8L', 'no'),
(883, 'wpseo_sitemap_w2dc-location_cache_validator', '6jksJ', 'no'),
(1090, 'w2dc-location_children', 'a:5:{i:234;a:29:{i:0;i:236;i:1;i:237;i:2;i:238;i:3;i:239;i:4;i:240;i:5;i:241;i:6;i:242;i:7;i:243;i:8;i:244;i:9;i:245;i:10;i:246;i:11;i:247;i:12;i:248;i:13;i:249;i:14;i:250;i:15;i:251;i:16;i:252;i:17;i:253;i:18;i:254;i:19;i:255;i:20;i:256;i:21;i:257;i:22;i:258;i:23;i:259;i:24;i:260;i:25;i:261;i:26;i:262;i:27;i:263;i:28;i:264;}i:265;a:22:{i:0;i:269;i:1;i:270;i:2;i:271;i:3;i:272;i:4;i:273;i:5;i:274;i:6;i:275;i:7;i:276;i:8;i:277;i:9;i:278;i:10;i:279;i:11;i:280;i:12;i:281;i:13;i:282;i:14;i:283;i:15;i:284;i:16;i:285;i:17;i:286;i:18;i:287;i:19;i:288;i:20;i:289;i:21;i:290;}i:268;a:17:{i:0;i:291;i:1;i:292;i:2;i:293;i:3;i:294;i:4;i:295;i:5;i:296;i:6;i:297;i:7;i:298;i:8;i:299;i:9;i:300;i:10;i:301;i:11;i:302;i:12;i:303;i:13;i:304;i:14;i:305;i:15;i:306;i:16;i:307;}i:267;a:11:{i:0;i:308;i:1;i:309;i:2;i:310;i:3;i:311;i:4;i:312;i:5;i:313;i:6;i:314;i:7;i:315;i:8;i:316;i:9;i:317;i:10;i:318;}i:266;a:19:{i:0;i:319;i:1;i:320;i:2;i:321;i:3;i:322;i:4;i:323;i:5;i:324;i:6;i:325;i:7;i:326;i:8;i:327;i:9;i:328;i:10;i:329;i:11;i:330;i:12;i:331;i:13;i:332;i:14;i:333;i:15;i:334;i:16;i:335;i:17;i:336;i:18;i:337;}}', 'yes'),
(1104, 'wpseo_sitemap_51_cache_validator', '5DHMZ', 'no'),
(1108, 'wpseo_sitemap_75_cache_validator', '6jksz', 'no'),
(1125, 'wpseo_sitemap_attachment_cache_validator', '5bgKT', 'no'),
(1135, 'wpseo_sitemap_72_cache_validator', '5Gs7P', 'no'),
(1173, 'widget_encyclopdia_related_terms', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1174, 'widget_encyclopedia_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1175, 'widget_encyclopedia_taxonomies', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1176, 'widget_encyclopedia_taxonomy_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1177, 'widget_encyclopedia_terms', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1181, 'wpseo_sitemap_encyclopedia_cache_validator', '6RXNB', 'no'),
(1187, 'news_manager_version', '1.1.0', 'yes'),
(1188, 'news_manager_general', 'a:11:{s:8:"supports";a:9:{s:5:"title";b:1;s:6:"editor";b:1;s:6:"author";b:1;s:9:"thumbnail";b:1;s:7:"excerpt";b:1;s:13:"custom-fields";b:0;s:8:"comments";b:1;s:10:"trackbacks";b:0;s:9:"revisions";b:0;}s:14:"use_categories";b:1;s:18:"builtin_categories";b:0;s:8:"use_tags";b:1;s:12:"builtin_tags";b:0;s:19:"deactivation_delete";b:0;s:13:"news_nav_menu";a:4:{s:4:"show";b:0;s:9:"menu_name";s:0:"";s:7:"menu_id";i:0;s:7:"item_id";i:0;}s:13:"first_weekday";i:1;s:11:"news_in_rss";b:0;s:35:"display_news_in_tags_and_categories";b:1;s:13:"rewrite_rules";b:0;}', 'no'),
(1189, 'news_manager_capabilities', '', 'no'),
(1190, 'news_manager_permalinks', 'a:5:{s:9:"news_slug";s:9:"bibliotek";s:18:"single_news_prefix";b:0;s:23:"single_news_prefix_type";s:8:"category";s:22:"news_tags_rewrite_slug";s:3:"tag";s:28:"news_categories_rewrite_slug";s:8:"kategori";}', 'no'),
(1191, 'widget_news_manager_list_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1192, 'widget_news_manager_archive_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1193, 'widget_news_manager_calendar_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1194, 'widget_news_manager_tags_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1195, 'widget_news_manager_categories_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1203, 'woocommerce_permalinks', 'a:4:{s:13:"category_base";s:16:"produkt-kategori";s:8:"tag_base";s:12:"produkt-emne";s:14:"attribute_base";s:0:"";s:12:"product_base";s:19:"/shop/%product_cat%";}', 'yes'),
(1205, 'widget_yadawiki_toc_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1209, 'wpseo_sitemap_yada_wiki_cache_validator', '5PQwp', 'no'),
(1214, 'wpseo_sitemap_74_cache_validator', '5MpQP', 'no'),
(1217, 'wiki_cats_children', 'a:0:{}', 'yes'),
(1219, 'widget_incsub_wiki', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1220, 'wiki_settings', 'a:1:{s:4:"slug";s:9:"bibliotek";}', 'yes'),
(1222, 'wiki_version', '1.1.0.3', 'yes'),
(1227, 'wpseo_sitemap_incsub_wiki_cache_validator', '5Pepr', 'no'),
(1237, 'PAKB_FLUSH_REWRITE_RULE', '', 'yes'),
(1238, 'widget_knowledge_base_categories', 'a:2:{i:2;a:6:{s:5:"title";s:10:"Kategorier";s:11:"description";s:0:"";s:6:"number";s:2:"10";s:7:"orderby";s:4:"name";s:5:"order";s:3:"ASC";s:5:"count";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes'),
(1239, 'widget_knowledge_base_articles', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1240, 'widget_knowledge_base_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1244, 'pakb_options', 'a:37:{s:16:"pakb_kb_template";s:8:"page.php";s:12:"pakb_kb_slug";s:17:"bibliotek-artikel";s:15:"pakb_kbcat_slug";s:18:"bibliotek-kategori";s:16:"pakb_breadcrumbs";b:1;s:20:"pakb_breadcrumb_text";s:9:"Bibliotek";s:12:"pakb_reorder";s:7:"default";s:12:"pakb_kb_page";s:2:"94";s:12:"pakb_columns";s:1:"2";s:19:"pakb_kb_page_layout";s:1:"1";s:13:"pakb_icon_cat";b:1;s:19:"pakb_category_count";b:1;s:13:"pakb_view_all";b:1;s:19:"pakb_view_all_count";b:1;s:18:"pakb_posts_per_cat";s:1:"5";s:18:"pakb_box_icon_size";s:2:"48";s:13:"pakb_cat_size";s:2:"26";s:16:"pakb_layout_main";a:2:{s:7:"enabled";a:2:{s:6:"search";s:10:"Search Bar";s:4:"main";s:14:"Knowledge Base";}s:8:"disabled";a:2:{s:7:"sidebar";s:7:"Sidebar";s:7:"content";s:12:"Page Content";}}s:17:"pakb_meta_display";s:1:"2";s:9:"pakb_meta";a:3:{i:0;s:7:"updated";i:1;s:8:"category";i:2;s:4:"tags";}s:13:"pakb_comments";b:1;s:21:"pakb_related_articles";b:1;s:18:"pakb_search_enable";b:1;s:26:"pakb_searchbox_placeholder";s:18:"Søg i biblioteket";s:15:"pakb_search_btn";b:1;s:19:"pakb_search_archive";b:1;s:18:"pakb_search_single";b:1;s:16:"pakb_live_search";b:1;s:20:"pakb_search_show_cat";b:1;s:11:"pakb_voting";s:1:"1";s:17:"pakb_vote_dislike";b:1;s:17:"pakb_vote_up_icon";s:13:"si-checkmark3";s:19:"pakb_vote_down_icon";s:9:"si-cross2";s:15:"pakb_link_color";s:7:"#1e73be";s:14:"pakb_cat_color";s:7:"#03A9F4";s:19:"pakb_sec_link_color";s:7:"#1e73be";s:20:"pakb_list_link_color";s:7:"#81d742";s:15:"pakb_custom_css";s:0:"";}', 'yes'),
(1265, 'w2dc_google_maps_required', '', 'yes'),
(1271, '_skelet_knowledgebase_category_338', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1272, 'wpseo_sitemap_knowledgebase_category_cache_validator', 'xlUO', 'no'),
(1277, '_skelet_knowledgebase_category_339', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1279, '_skelet_knowledgebase_category_340', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1281, '_skelet_knowledgebase_category_341', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1283, '_skelet_knowledgebase_category_342', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1285, '_skelet_knowledgebase_category_343', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1287, '_skelet_knowledgebase_category_344', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1289, '_skelet_knowledgebase_category_345', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1291, '_skelet_knowledgebase_category_346', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1293, '_skelet_knowledgebase_category_347', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1295, '_skelet_knowledgebase_category_348', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1297, '_skelet_knowledgebase_category_349', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1299, '_skelet_knowledgebase_category_350', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1301, '_skelet_knowledgebase_category_351', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1302, 'knowledgebase_category_children', 'a:0:{}', 'yes'),
(1303, '_skelet_knowledgebase_category_352', 'a:1:{s:4:"icon";s:10:"si-folder4";}', 'yes'),
(1306, 'wpseo_sitemap_knowledgebase_tags_cache_validator', 'xlUT', 'no'),
(1307, 'wpseo_sitemap_knowledgebase_cache_validator', 'xlV8', 'no'),
(1325, 'wpseo_sitemap_99_cache_validator', '6jksX', 'no'),
(1341, 'redirection_version', '2.3.2', 'yes'),
(1347, '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:4:"p=25";i:1;s:6:"/kurv/";i:2;s:4:"p=26";i:3;s:7:"/kasse/";i:4;s:4:"p=27";i:5;s:7:"/konto/";}', 'yes'),
(1387, 'wpseo_sitemap_117_cache_validator', '6jkta', 'no'),
(1405, 'wpseo_sitemap_133_cache_validator', '6jktf', 'no'),
(1429, 'shfs_insert_header', '<style>\r\n.site-search {\r\n    display: none;\r\n}\r\n</style>', 'yes'),
(1430, 'shfs_insert_footer', '', 'yes'),
(1483, 'wpseo_sitemap_148_cache_validator', '6jktl', 'no'),
(1487, 'wpseo_sitemap_152_cache_validator', '6jktw', 'no'),
(1550, 'wpseo_sitemap_168_cache_validator', '6jkuo', 'no'),
(1551, 'wpseo_sitemap_162_cache_validator', '6jkui', 'no'),
(1552, 'wpseo_sitemap_161_cache_validator', '6jkuc', 'no'),
(1553, 'wpseo_sitemap_160_cache_validator', '6jku5', 'no'),
(1554, 'wpseo_sitemap_159_cache_validator', '6jktY', 'no'),
(1555, 'wpseo_sitemap_158_cache_validator', '6jktT', 'no'),
(1556, 'wpseo_sitemap_157_cache_validator', '6jktO', 'no'),
(1558, 'wpseo_sitemap_156_cache_validator', '6jktI', 'no'),
(1562, 'wpseo_sitemap_154_cache_validator', '6jktC', 'no'),
(1564, 'wpseo_sitemap_151_cache_validator', '6jktq', 'no'),
(1619, 'wpseo_sitemap_182_cache_validator', '6jkwt', 'no'),
(1624, 'wpseo_sitemap_184_cache_validator', '6jkwN', 'no'),
(1631, 'wpseo_sitemap_189_cache_validator', '6jkxz', 'no'),
(1637, 'wpseo_sitemap_129_cache_validator', '6RXNk', 'no'),
(1665, 'wpseo_sitemap_190_cache_validator', '6jkxG', 'no'),
(1686, '_transient_wc_count_comments', 'O:8:"stdClass":7:{s:8:"approved";s:1:"1";s:14:"total_comments";i:1;s:3:"all";i:1;s:9:"moderated";i:0;s:4:"spam";i:0;s:5:"trash";i:0;s:12:"post-trashed";i:0;}', 'yes'),
(1796, 'w2dc-category_children', 'a:10:{i:105;a:3:{i:0;i:106;i:1;i:107;i:2;i:108;}i:109;a:2:{i:0;i:110;i:1;i:111;}i:112;a:8:{i:0;i:113;i:1;i:114;i:2;i:115;i:3;i:116;i:4;i:117;i:5;i:118;i:6;i:119;i:7;i:120;}i:121;a:6:{i:0;i:122;i:1;i:123;i:2;i:124;i:3;i:125;i:4;i:126;i:5;i:127;}i:128;a:9:{i:0;i:129;i:1;i:130;i:2;i:131;i:3;i:132;i:4;i:133;i:5;i:134;i:6;i:135;i:7;i:136;i:8;i:137;}i:138;a:2:{i:0;i:139;i:1;i:140;}i:141;a:10:{i:0;i:142;i:1;i:143;i:2;i:144;i:3;i:145;i:4;i:146;i:5;i:147;i:6;i:148;i:7;i:149;i:8;i:150;i:9;i:151;}i:152;a:2:{i:0;i:153;i:1;i:154;}i:155;a:4:{i:0;i:156;i:1;i:157;i:2;i:158;i:3;i:159;}i:160;a:4:{i:0;i:161;i:1;i:162;i:2;i:163;i:3;i:164;}}', 'yes'),
(1859, 'widget_em_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1860, 'widget_em_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1861, 'dbem_events_page', '204', 'yes'),
(1862, 'dbem_locations_page', '205', 'yes'),
(1863, 'dbem_categories_page', '206', 'yes'),
(1864, 'dbem_tags_page', '207', 'yes'),
(1865, 'dbem_my_bookings_page', '208', 'yes'),
(1866, 'dbem_hello_to_user', '0', 'yes'),
(1867, 'dbem_time_format', 'G:i', 'yes'),
(1868, 'dbem_date_format', 'd/m/Y', 'yes'),
(1869, 'dbem_date_format_js', 'dd-mm-yy', 'yes'),
(1870, 'dbem_dates_separator', ' - ', 'yes'),
(1871, 'dbem_times_separator', ' - ', 'yes'),
(1872, 'dbem_default_category', '-1', 'yes'),
(1873, 'dbem_default_location', '0', 'yes'),
(1874, 'dbem_events_default_orderby', 'event_start_date,event_start_time,event_name', 'yes'),
(1875, 'dbem_events_default_order', 'ASC', 'yes'),
(1876, 'dbem_events_default_limit', '10', 'yes'),
(1877, 'dbem_search_form_submit', 'Søg', 'yes'),
(1878, 'dbem_search_form_advanced', '1', 'yes'),
(1879, 'dbem_search_form_advanced_hidden', '1', 'yes'),
(1880, 'dbem_search_form_advanced_show', 'Show Advanced Search', 'yes'),
(1881, 'dbem_search_form_advanced_hide', 'Hide Advanced Search', 'yes'),
(1882, 'dbem_search_form_text', '1', 'yes'),
(1883, 'dbem_search_form_text_label', 'Søg', 'yes'),
(1884, 'dbem_search_form_geo', '1', 'yes'),
(1885, 'dbem_search_form_geo_label', 'I nærheden af ...', 'yes'),
(1886, 'dbem_search_form_geo_units', '1', 'yes'),
(1887, 'dbem_search_form_geo_units_label', 'Inden', 'yes'),
(1888, 'dbem_search_form_geo_unit_default', 'mi', 'yes'),
(1889, 'dbem_search_form_geo_distance_default', '25', 'yes'),
(1890, 'dbem_search_form_geo_distance_options', '5,10,25,50,100', 'yes'),
(1891, 'dbem_search_form_dates', '1', 'yes'),
(1892, 'dbem_search_form_dates_label', 'Datoer', 'yes'),
(1893, 'dbem_search_form_dates_separator', 'og', 'yes'),
(1894, 'dbem_search_form_categories', '1', 'yes'),
(1895, 'dbem_search_form_categories_label', 'Alle kategorier', 'yes'),
(1896, 'dbem_search_form_category_label', 'Kategori', 'yes'),
(1897, 'dbem_search_form_countries', '1', 'yes'),
(1898, 'dbem_search_form_default_country', '0', 'yes'),
(1899, 'dbem_search_form_countries_label', 'Alle lande', 'yes'),
(1900, 'dbem_search_form_country_label', 'Land', 'yes'),
(1901, 'dbem_search_form_regions', '1', 'yes'),
(1902, 'dbem_search_form_regions_label', 'Alle regioner', 'yes'),
(1903, 'dbem_search_form_region_label', 'område', 'yes'),
(1904, 'dbem_search_form_states', '1', 'yes'),
(1905, 'dbem_search_form_states_label', 'Alle stater', 'yes'),
(1906, 'dbem_search_form_state_label', 'Stat / amt', 'yes'),
(1907, 'dbem_search_form_towns', '0', 'yes'),
(1908, 'dbem_search_form_towns_label', 'Alle byer', 'yes'),
(1909, 'dbem_search_form_town_label', 'By / Town', 'yes'),
(1910, 'dbem_events_form_editor', '1', 'yes'),
(1911, 'dbem_events_form_reshow', '1', 'yes'),
(1912, 'dbem_events_form_result_success', 'Du har tilføjet din event med succes, der vil blive udgivet som afventer godkendelse.', 'yes'),
(1913, 'dbem_events_form_result_success_updated', 'You have successfully updated your event, which will be republished pending approval.', 'yes'),
(1914, 'dbem_events_anonymous_submissions', '0', 'yes'),
(1915, 'dbem_events_anonymous_user', '2', 'yes'),
(1916, 'dbem_events_anonymous_result_success', 'Du har tilføjet din event med succes, der vil blive udgivet som afventer godkendelse.', 'yes'),
(1917, 'dbem_event_submitted_email_admin', '', 'yes'),
(1918, 'dbem_event_submitted_email_subject', 'Tilføjet event afventer godkendelse', 'yes'),
(1919, 'dbem_event_submitted_email_body', 'Der er tilføjet en ny event af #_CONTACTNAME.\r\n\r\nNavn: #_EVENTNAME \r\n\r\nDato: #_EVENTDATES \r\n\r\nTid: #_EVENTTIMES \r\n\r\nBesøg venligst https://project08.websupport.dk/wp/wp-admin/post.php?action=edit&post=#_EVENTPOSTID for at gennemse denne event for godkendelse.\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(1920, 'dbem_event_resubmitted_email_subject', 'Re-Submitted Event Awaiting Approval', 'yes'),
(1921, 'dbem_event_resubmitted_email_body', 'A previously published event has been modified by #_CONTACTNAME, and this event is now unpublished and pending your approval.\r\n\r\nName : #_EVENTNAME \r\n\r\nDate : #_EVENTDATES \r\n\r\nTime : #_EVENTTIMES \r\n\r\nPlease visit https://project08.websupport.dk/wp/wp-admin/post.php?action=edit&post=#_EVENTPOSTID to review this event for approval.\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(1922, 'dbem_event_published_email_subject', 'Published Event - #_EVENTNAME', 'yes'),
(1923, 'dbem_event_published_email_body', 'A new event has been published by #_CONTACTNAME.\r\n\r\nName : #_EVENTNAME \r\n\r\nDate : #_EVENTDATES \r\n\r\nTime : #_EVENTTIMES \r\n\r\nEdit this event - https://project08.websupport.dk/wp/wp-admin/post.php?action=edit&post=#_EVENTPOSTID \r\n\r\n View this event - #_EVENTURL\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(1924, 'dbem_event_approved_email_subject', 'Event godkendt - #_EVENTNAME', 'yes'),
(1925, 'dbem_event_approved_email_body', 'Kære #_CONTACTNAME, \r\n\r\nDin event #_EVENTNAME den #_EVENTDATES er blevet godkendt.\r\n\r\nDu kan se din event her: #_EVENTURL\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(1926, 'dbem_event_reapproved_email_subject', 'Event godkendt - #_EVENTNAME', 'yes'),
(1927, 'dbem_event_reapproved_email_body', 'Kære #_CONTACTNAME, \r\n\r\nDin event #_EVENTNAME den #_EVENTDATES er blevet godkendt.\r\n\r\nDu kan se din event her: #_EVENTURL\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(1928, 'dbem_events_page_title', 'Events', 'yes'),
(1929, 'dbem_events_page_scope', 'future', 'yes'),
(1930, 'dbem_events_page_search_form', '1', 'yes'),
(1931, 'dbem_event_list_item_format_header', '<table cellpadding="0" cellspacing="0" class="events-table" >\r\n    <thead>\r\n        <tr>\r\n			<th class="event-time" width="150">Dato/klokkeslæt</th>\r\n			<th class="event-description" width="*">Event</th>\r\n		</tr>\r\n   	</thead>\r\n    <tbody>', 'yes'),
(1932, 'dbem_event_list_item_format', '<tr>\r\n			<td>\r\n                #_EVENTDATES<br/>\r\n                #_EVENTTIMES\r\n            </td>\r\n            <td>\r\n                #_EVENTLINK\r\n                {has_location}<br/><i>#_LOCATIONNAME, #_LOCATIONTOWN #_LOCATIONSTATE</i>{/has_location}\r\n            </td>\r\n        </tr>', 'yes'),
(1933, 'dbem_event_list_item_format_footer', '</tbody></table>', 'yes'),
(1934, 'dbem_event_list_groupby', '0', 'yes'),
(1935, 'dbem_event_list_groupby_format', '', 'yes'),
(1936, 'dbem_event_list_groupby_header_format', '<h2>#s</h2>', 'yes'),
(1937, 'dbem_display_calendar_in_events_page', '0', 'yes'),
(1938, 'dbem_single_event_format', '<div style="float:right; margin:0px 0px 15px 15px;">#_LOCATIONMAP</div>\r\n<p>\r\n	<strong>Dato/klokkeslæt</strong><br/>\r\n	Date(s) - #_EVENTDATES<br /><i>#_EVENTTIMES</i>\r\n</p>\r\n{has_location}\r\n<p>\r\n	<strong>Lokation</strong><br/>\r\n	#_LOCATIONLINK\r\n</p>\r\n{/has_location}\r\n<p>\r\n	<strong>Kategori</strong>\r\n	#_CATEGORIES\r\n</p>\r\n<br style="clear:both" />\r\n#_EVENTNOTES\r\n{has_bookings}\r\n<h3>Bookings</h3>\r\n#_BOOKINGFORM\r\n{/has_bookings}', 'yes'),
(1939, 'dbem_event_excerpt_format', '#_EVENTDATES @ #_EVENTTIMES - #_EVENTEXCERPT', 'yes'),
(1940, 'dbem_event_excerpt_alt_format', '#_EVENTDATES @ #_EVENTTIMES - #_EVENTEXCERPT{55}', 'yes'),
(1941, 'dbem_event_page_title_format', '#_EVENTNAME', 'yes'),
(1942, 'dbem_event_all_day_message', 'Hele dagen', 'yes'),
(1943, 'dbem_no_events_message', 'Ingen Events', 'yes'),
(1944, 'dbem_locations_default_orderby', 'location_name', 'yes'),
(1945, 'dbem_locations_default_order', 'ASC', 'yes'),
(1946, 'dbem_locations_default_limit', '10', 'yes'),
(1947, 'dbem_locations_page_title', 'Event Lokationer', 'yes'),
(1948, 'dbem_locations_page_search_form', '1', 'yes'),
(1949, 'dbem_no_locations_message', 'Ingen Lokationer', 'yes'),
(1950, 'dbem_location_default_country', '0', 'yes'),
(1951, 'dbem_location_list_item_format_header', '<ul class="em-locations-list">', 'yes'),
(1952, 'dbem_location_list_item_format', '<li>#_LOCATIONLINK<ul><li>#_LOCATIONFULLLINE</li></ul></li>', 'yes'),
(1953, 'dbem_location_list_item_format_footer', '</ul>', 'yes'),
(1954, 'dbem_location_page_title_format', '#_LOCATIONNAME', 'yes'),
(1955, 'dbem_single_location_format', '<div style="float:right; margin:0px 0px 15px 15px;">#_LOCATIONMAP</div>\r\n<p>\r\n	<strong>Adresse</strong><br/>\r\n	#_LOCATIONADDRESS<br/>\r\n	#_LOCATIONTOWN<br/>\r\n	#_LOCATIONSTATE<br/>\r\n	#_LOCATIONREGION<br/>\r\n	#_LOCATIONPOSTCODE<br/>\r\n	#_LOCATIONCOUNTRY\r\n</p>\r\n<br style="clear:both" />\r\n#_LOCATIONNOTES\r\n\r\n<h3>Begivenheder</h3>\r\n<p>#_LOCATIONNEXTEVENTS</p>', 'yes'),
(1956, 'dbem_location_excerpt_format', '#_LOCATIONEXCERPT', 'yes'),
(1957, 'dbem_location_excerpt_alt_format', '#_LOCATIONEXCERPT{55}', 'yes'),
(1958, 'dbem_location_no_events_message', '<li>No events in this location</li>', 'yes'),
(1959, 'dbem_location_event_list_item_header_format', '<ul>', 'yes'),
(1960, 'dbem_location_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'),
(1961, 'dbem_location_event_list_item_footer_format', '</ul>', 'yes'),
(1962, 'dbem_location_event_list_limit', '20', 'yes'),
(1963, 'dbem_location_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'),
(1964, 'dbem_location_no_event_message', 'No events in this location', 'yes'),
(1965, 'dbem_categories_default_limit', '10', 'yes'),
(1966, 'dbem_categories_default_orderby', 'name', 'yes'),
(1967, 'dbem_categories_default_order', 'ASC', 'yes'),
(1968, 'dbem_categories_list_item_format_header', '<ul class="em-categories-list">', 'yes'),
(1969, 'dbem_categories_list_item_format', '<li>#_CATEGORYLINK</li>', 'yes'),
(1970, 'dbem_categories_list_item_format_footer', '</ul>', 'yes'),
(1971, 'dbem_no_categories_message', 'Ingen Kategori', 'yes'),
(1972, 'dbem_category_page_title_format', '#_CATEGORYNAME', 'yes'),
(1973, 'dbem_category_page_format', '#_CATEGORYNOTES<h3>Begivenheder</h3>#_CATEGORYNEXTEVENTS', 'yes'),
(1974, 'dbem_category_no_events_message', '<li>No events in this category</li>', 'yes'),
(1975, 'dbem_category_event_list_item_header_format', '<ul>', 'yes'),
(1976, 'dbem_category_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'),
(1977, 'dbem_category_event_list_item_footer_format', '</ul>', 'yes'),
(1978, 'dbem_category_event_list_limit', '20', 'yes'),
(1979, 'dbem_category_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'),
(1980, 'dbem_category_no_event_message', 'No events in this category', 'yes'),
(1981, 'dbem_category_default_color', '#a8d144', 'yes'),
(1982, 'dbem_tags_default_limit', '10', 'yes'),
(1983, 'dbem_tags_default_orderby', 'name', 'yes'),
(1984, 'dbem_tags_default_order', 'ASC', 'yes'),
(1985, 'dbem_tags_list_item_format_header', '<ul class="em-tags-list">', 'yes'),
(1986, 'dbem_tags_list_item_format', '<li>#_TAGLINK</li>', 'yes'),
(1987, 'dbem_tags_list_item_format_footer', '</ul>', 'yes'),
(1988, 'dbem_no_tags_message', 'Ingen Tags', 'yes'),
(1989, 'dbem_tag_page_title_format', '#_TAGNAME', 'yes'),
(1990, 'dbem_tag_page_format', '<h3>Begivenheder</h3>#_TAGNEXTEVENTS', 'yes'),
(1991, 'dbem_tag_no_events_message', '<li>No events with this tag</li>', 'yes'),
(1992, 'dbem_tag_event_list_item_header_format', '<ul class="em-tags-list">', 'yes'),
(1993, 'dbem_tag_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'),
(1994, 'dbem_tag_event_list_item_footer_format', '</ul>', 'yes'),
(1995, 'dbem_tag_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'),
(1996, 'dbem_tag_no_event_message', 'No events with this tag', 'yes'),
(1997, 'dbem_tag_event_list_limit', '20', 'yes'),
(1998, 'dbem_rss_limit', '0', 'yes'),
(1999, 'dbem_rss_scope', 'future', 'yes'),
(2000, 'dbem_rss_main_title', 'øko-info - Events', 'yes'),
(2001, 'dbem_rss_main_description', 'Endnu en WordPress-blog - Events', 'yes'),
(2002, 'dbem_rss_description_format', '#_EVENTDATES - #_EVENTTIMES <br/>#_LOCATIONNAME <br/>#_LOCATIONADDRESS <br/>#_LOCATIONTOWN', 'yes'),
(2003, 'dbem_rss_title_format', '#_EVENTNAME', 'yes'),
(2004, 'dbem_rss_order', 'ASC', 'yes'),
(2005, 'dbem_rss_orderby', 'event_start_date,event_start_time,event_name', 'yes'),
(2006, 'em_rss_pubdate', 'Fri, 05 Aug 2016 13:52:39 +0000', 'yes'),
(2007, 'dbem_ical_limit', '0', 'yes'),
(2008, 'dbem_ical_scope', 'future', 'yes'),
(2009, 'dbem_ical_description_format', '#_EVENTNAME', 'yes'),
(2010, 'dbem_ical_real_description_format', '#_EVENTEXCERPT', 'yes'),
(2011, 'dbem_ical_location_format', '#_LOCATIONNAME, #_LOCATIONFULLLINE, #_LOCATIONCOUNTRY', 'yes'),
(2012, 'dbem_gmap_is_active', '1', 'yes'),
(2013, 'dbem_google_maps_browser_key', '', 'yes'),
(2014, 'dbem_map_default_width', '400px', 'yes'),
(2015, 'dbem_map_default_height', '300px', 'yes'),
(2016, 'dbem_location_baloon_format', '<strong>#_LOCATIONNAME</strong><br/>#_LOCATIONADDRESS - #_LOCATIONTOWN<br/><a href="#_LOCATIONPAGEURL">Events</a>', 'yes'),
(2017, 'dbem_map_text_format', '<strong>#_LOCATIONNAME</strong><p>#_LOCATIONADDRESS</p><p>#_LOCATIONTOWN</p>', 'yes'),
(2018, 'dbem_email_disable_registration', '0', 'yes'),
(2019, 'dbem_rsvp_mail_port', '465', 'yes'),
(2020, 'dbem_smtp_host', 'localhost', 'yes'),
(2021, 'dbem_mail_sender_name', '', 'yes'),
(2022, 'dbem_rsvp_mail_send_method', 'wp_mail', 'yes'),
(2023, 'dbem_rsvp_mail_SMTPAuth', '1', 'yes'),
(2024, 'dbem_smtp_html', '1', 'yes'),
(2025, 'dbem_smtp_html_br', '1', 'yes'),
(2026, 'dbem_image_max_width', '700', 'yes'),
(2027, 'dbem_image_max_height', '700', 'yes'),
(2028, 'dbem_image_min_width', '50', 'yes'),
(2029, 'dbem_image_min_height', '50', 'yes'),
(2030, 'dbem_image_max_size', '204800', 'yes'),
(2031, 'dbem_list_date_title', 'Events - #j #M #y', 'yes'),
(2032, 'dbem_full_calendar_month_format', 'M Y', 'yes'),
(2033, 'dbem_full_calendar_event_format', '<li>#_EVENTLINK</li>', 'yes'),
(2034, 'dbem_full_calendar_long_events', '0', 'yes'),
(2035, 'dbem_full_calendar_initials_length', '0', 'yes'),
(2036, 'dbem_full_calendar_abbreviated_weekdays', '1', 'yes'),
(2037, 'dbem_display_calendar_day_single_yes', '1', 'yes'),
(2038, 'dbem_small_calendar_month_format', 'M Y', 'yes'),
(2039, 'dbem_small_calendar_event_title_format', '#_EVENTNAME', 'yes'),
(2040, 'dbem_small_calendar_event_title_separator', ', ', 'yes'),
(2041, 'dbem_small_calendar_initials_length', '1', 'yes'),
(2042, 'dbem_small_calendar_abbreviated_weekdays', '0', 'yes'),
(2043, 'dbem_small_calendar_long_events', '0', 'yes'),
(2044, 'dbem_display_calendar_order', 'ASC', 'yes'),
(2045, 'dbem_display_calendar_orderby', 'event_name,event_start_time', 'yes'),
(2046, 'dbem_display_calendar_events_limit', '3', 'yes'),
(2047, 'dbem_display_calendar_events_limit_msg', 'mere...', 'yes'),
(2048, 'dbem_calendar_direct_links', '1', 'yes'),
(2049, 'dbem_require_location', '0', 'yes'),
(2050, 'dbem_locations_enabled', '1', 'yes'),
(2051, 'dbem_use_select_for_locations', '0', 'yes'),
(2052, 'dbem_attributes_enabled', '1', 'yes'),
(2053, 'dbem_recurrence_enabled', '1', 'yes'),
(2054, 'dbem_rsvp_enabled', '1', 'yes'),
(2055, 'dbem_categories_enabled', '1', 'yes'),
(2056, 'dbem_tags_enabled', '1', 'yes'),
(2057, 'dbem_placeholders_custom', '', 'yes'),
(2058, 'dbem_location_attributes_enabled', '1', 'yes'),
(2059, 'dbem_location_placeholders_custom', '', 'yes'),
(2060, 'dbem_bookings_registration_disable', '0', 'yes'),
(2061, 'dbem_bookings_registration_disable_user_emails', '0', 'yes'),
(2062, 'dbem_bookings_registration_user', '', 'yes'),
(2063, 'dbem_bookings_approval', '1', 'yes'),
(2064, 'dbem_bookings_approval_reserved', '0', 'yes'),
(2065, 'dbem_bookings_approval_overbooking', '0', 'yes'),
(2066, 'dbem_bookings_double', '0', 'yes'),
(2067, 'dbem_bookings_user_cancellation', '1', 'yes'),
(2068, 'dbem_bookings_currency', 'USD', 'yes'),
(2069, 'dbem_bookings_currency_decimal_point', ',', 'yes'),
(2070, 'dbem_bookings_currency_thousands_sep', '.', 'yes'),
(2071, 'dbem_bookings_currency_format', '@#', 'yes'),
(2072, 'dbem_bookings_tax', '0', 'yes'),
(2073, 'dbem_bookings_tax_auto_add', '0', 'yes'),
(2074, 'dbem_bookings_submit_button', 'Send din tilmelding', 'yes'),
(2075, 'dbem_bookings_login_form', '1', 'yes'),
(2076, 'dbem_bookings_anonymous', '1', 'yes'),
(2077, 'dbem_bookings_form_max', '20', 'yes'),
(2078, 'dbem_bookings_form_msg_disabled', 'Online-tilmeldinger er ikke mulige til denne event.', 'yes'),
(2079, 'dbem_bookings_form_msg_closed', 'Tilmeldinger er lukket til denne event.', 'yes'),
(2080, 'dbem_bookings_form_msg_full', 'Denne event er fuldt booket.', 'yes'),
(2081, 'dbem_bookings_form_msg_attending', 'Du deltager i øjeblikket i denne event.', 'yes'),
(2082, 'dbem_bookings_form_msg_bookings_link', 'Administrer mine tilmeldinger', 'yes'),
(2083, 'dbem_booking_warning_cancel', 'Er du sikker på at du vil annullere din tilmelding?', 'yes'),
(2084, 'dbem_booking_feedback_cancelled', 'Tilmelding Annulleret', 'yes'),
(2085, 'dbem_booking_feedback_pending', 'Tilmelding gennemført, bekræftelse afventer godkendelse (du vil også modtage en E-mail efter at den er bekræftet).', 'yes'),
(2086, 'dbem_booking_feedback', 'Tilmelding fuldført.', 'yes'),
(2087, 'dbem_booking_feedback_full', 'Tilmelding kan ikke udføres, der er ikke ledige pladser nok!', 'yes'),
(2088, 'dbem_booking_feedback_log_in', 'Du skal logge ind eller registrere dig for at oprette en tilmelding.', 'yes'),
(2089, 'dbem_booking_feedback_nomail', 'Men, der var nogle problemer ved afsendelse af en bekræftelses E-mails til dig og / eller event-kontaktperson. Du ønsker måske at kontakte dem direkte, og lade dem vide af denne fejl.', 'yes'),
(2090, 'dbem_booking_feedback_error', 'Tilmelding kunne ikke oprettes:', 'yes'),
(2091, 'dbem_booking_feedback_email_exists', 'Denne E-mail eksisterer allerede i vores system, venligst logind for at fortsætte med din tilmelding.', 'yes'),
(2092, 'dbem_booking_feedback_new_user', 'En ny brugerkonto er oprettet til dig. Kontroller venligst din E-mail for adgangsdetaljer.', 'yes'),
(2093, 'dbem_booking_feedback_reg_error', 'Der var et problem med oprettelse af en brugerkonto, kontakt venligst en administrator på hjemmesiden.', 'yes'),
(2094, 'dbem_booking_feedback_already_booked', 'Du har allerede tilmeldt dig en plads til denne event.', 'yes'),
(2095, 'dbem_booking_feedback_min_space', 'Du skal anmode om mindst en plads for at tilmelde en event.', 'yes'),
(2096, 'dbem_booking_feedback_spaces_limit', 'You cannot book more than %d spaces for this event.', 'yes'),
(2097, 'dbem_booking_button_msg_book', 'Tilmeld dig nu', 'yes'),
(2098, 'dbem_booking_button_msg_booking', 'Tilmelder...', 'yes'),
(2099, 'dbem_booking_button_msg_booked', 'Tilmelding tilføjet', 'yes'),
(2100, 'dbem_booking_button_msg_already_booked', 'Allerede Reserveret', 'yes'),
(2101, 'dbem_booking_button_msg_error', 'Tilmelding fejl. Prøv igen?', 'yes'),
(2102, 'dbem_booking_button_msg_full', 'Sold Out', 'yes'),
(2103, 'dbem_booking_button_msg_closed', 'Tilmeldinger Lukket', 'yes'),
(2104, 'dbem_booking_button_msg_cancel', 'Annullér', 'yes'),
(2105, 'dbem_booking_button_msg_canceling', 'Afbestiller...', 'yes'),
(2106, 'dbem_booking_button_msg_cancelled', 'Annulleret', 'yes'),
(2107, 'dbem_booking_button_msg_cancel_error', 'Afbestilling fejl. Prøv igen?', 'yes'),
(2108, 'dbem_bookings_notify_admin', '0', 'yes'),
(2109, 'dbem_bookings_contact_email', '1', 'yes'),
(2110, 'dbem_bookings_contact_email_pending_subject', 'Tilmelding afventer godkendelse', 'yes'),
(2111, 'dbem_bookings_contact_email_pending_body', 'The following booking is afventer godkendelse :\r\n\r\n#_EVENTNAME - #_EVENTDATES @ #_EVENTTIMES\r\n\r\nNow there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.\r\n\r\nDETALJER OM TILMELDING\r\n\r\nNavn : #_BOOKINGNAME\r\nE-mail : #_BOOKINGEMAIL\r\n\r\n#_BOOKINGSUMMARY\r\n\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2112, 'dbem_bookings_contact_email_confirmed_subject', 'Tilmelding bekræftet', 'yes'),
(2113, 'dbem_bookings_contact_email_confirmed_body', 'The following booking is bekræftet :\r\n\r\n#_EVENTNAME - #_EVENTDATES @ #_EVENTTIMES\r\n\r\nNow there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.\r\n\r\nDETALJER OM TILMELDING\r\n\r\nNavn : #_BOOKINGNAME\r\nE-mail : #_BOOKINGEMAIL\r\n\r\n#_BOOKINGSUMMARY\r\n\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2114, 'dbem_bookings_contact_email_rejected_subject', 'Tilmelding afvist', 'yes'),
(2115, 'dbem_bookings_contact_email_rejected_body', 'The following booking is afvist :\r\n\r\n#_EVENTNAME - #_EVENTDATES @ #_EVENTTIMES\r\n\r\nNow there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.\r\n\r\nDETALJER OM TILMELDING\r\n\r\nNavn : #_BOOKINGNAME\r\nE-mail : #_BOOKINGEMAIL\r\n\r\n#_BOOKINGSUMMARY\r\n\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2116, 'dbem_bookings_contact_email_cancelled_subject', 'Tilmelding annulleret', 'yes'),
(2117, 'dbem_bookings_contact_email_cancelled_body', 'The following booking is annulleret :\r\n\r\n#_EVENTNAME - #_EVENTDATES @ #_EVENTTIMES\r\n\r\nNow there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.\r\n\r\nDETALJER OM TILMELDING\r\n\r\nNavn : #_BOOKINGNAME\r\nE-mail : #_BOOKINGEMAIL\r\n\r\n#_BOOKINGSUMMARY\r\n\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2118, 'dbem_bookings_email_pending_subject', 'Tilmelding afventer godkendelse', 'yes'),
(2119, 'dbem_bookings_email_pending_body', 'Kære #_BOOKINGNAME, \r\n\r\nDu har anmodet om #_BOOKINGSPACES plads/pladser til #_EVENTNAME.\r\n\r\nHvornår: #_EVENTDATES @ #_EVENTTIMES\r\n\r\nHvor: #_LOCATIONNAME - #_LOCATIONFULLLINE\r\n\r\nDin tilmelding afventer for nuværende godkendelse af vores administratorer. Du modtager automatisk en bekræftelse efter godkendelse .\r\n\r\nVenlig hilsen,\r\n\r\n#_CONTACTNAME\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2120, 'dbem_bookings_email_rejected_subject', 'Tilmelding afvist', 'yes'),
(2121, 'dbem_bookings_email_rejected_body', 'Kære #_BOOKINGNAME, \r\n\r\nDin anmodning om tilmelding af #_BOOKINGSPACES pladser til #_EVENTNAME den #_EVENTDATES er blevet afvist.\r\n\r\nVenlig hilsen,\r\n\r\n#_CONTACTNAME\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2122, 'dbem_bookings_email_confirmed_subject', 'Tilmelding bekræftet', 'yes'),
(2123, 'dbem_bookings_email_confirmed_body', 'Dear #_BOOKINGNAME, \r\n\r\nYou have successfully reserved #_BOOKINGSPACES space/spaces for #_EVENTNAME.\r\n\r\nWhen : #_EVENTDATES @ #_EVENTTIMES\r\n\r\nWhere : #_LOCATIONNAME - #_LOCATIONFULLLINE\r\n\r\nYours faithfully,\r\n\r\n#_CONTACTNAME\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2124, 'dbem_bookings_email_cancelled_subject', 'Tilmelding annulleret', 'yes'),
(2125, 'dbem_bookings_email_cancelled_body', 'Kære #_BOOKINGNAME, \r\n\r\nDin tilmelding af #_BOOKINGSPACES pladser til #_EVENTNAME den #_EVENTDATES er blevet aflyst.\r\n\r\nVenlig hilsen,\r\n\r\n#_CONTACTNAME\r\n\r\n\r\n-------------------------------\r\n\r\nPowered by Events Manager - http://wp-events-plugin.com', 'yes'),
(2126, 'dbem_bookings_email_registration_subject', '[øko-info] Dit brugernavn og adgangskode', 'yes'),
(2127, 'dbem_bookings_email_registration_body', 'You have successfully created an account at øko-info\r\n\r\nYou can log into our site here : https://project08.websupport.dk/wp/wp-login.php\r\n\r\nBrugernavn : %username%\r\n\r\nAdgangskode : %password%\r\n\r\nTo view your bookings, please visit https://project08.websupport.dk/events/mine-tilmeldinger/ after logging in.', 'yes'),
(2128, 'dbem_bookings_tickets_orderby', 'ticket_price DESC, ticket_name ASC', 'yes'),
(2129, 'dbem_bookings_tickets_priority', '0', 'yes'),
(2130, 'dbem_bookings_tickets_show_unavailable', '0', 'yes'),
(2131, 'dbem_bookings_tickets_show_loggedout', '1', 'yes'),
(2132, 'dbem_bookings_tickets_single', '0', 'yes'),
(2133, 'dbem_bookings_tickets_single_form', '0', 'yes'),
(2134, 'dbem_bookings_my_title_format', 'Mine tilmeldinger', 'yes'),
(2135, 'dbem_bp_events_list_format_header', '<ul class="em-events-list">', 'yes'),
(2136, 'dbem_bp_events_list_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES<ul><li>#_LOCATIONLINK - #_LOCATIONADDRESS, #_LOCATIONTOWN</li></ul></li>', 'yes'),
(2137, 'dbem_bp_events_list_format_footer', '</ul>', 'yes'),
(2138, 'dbem_bp_events_list_none_format', '<p class="em-events-list">Ingen events</p>', 'yes'),
(2139, 'dbem_css_editors', '1', 'yes'),
(2140, 'dbem_css_rsvp', '1', 'yes'),
(2141, 'dbem_css_rsvpadmin', '1', 'yes'),
(2142, 'dbem_css_evlist', '1', 'yes'),
(2143, 'dbem_css_search', '1', 'yes'),
(2144, 'dbem_css_loclist', '1', 'yes'),
(2145, 'dbem_css_catlist', '1', 'yes'),
(2146, 'dbem_css_taglist', '1', 'yes'),
(2147, 'dbem_cp_events_slug', 'event', 'yes'),
(2148, 'dbem_cp_locations_slug', 'locations', 'yes'),
(2149, 'dbem_taxonomy_category_slug', 'events/categories', 'yes'),
(2150, 'dbem_taxonomy_tag_slug', 'events/tags', 'yes'),
(2151, 'dbem_cp_events_template', '', 'yes'),
(2152, 'dbem_cp_events_body_class', '', 'yes'),
(2153, 'dbem_cp_events_post_class', '', 'yes'),
(2154, 'dbem_cp_events_formats', '1', 'yes'),
(2155, 'dbem_cp_events_has_archive', '1', 'yes'),
(2156, 'dbem_events_default_archive_orderby', '_start_ts', 'yes'),
(2157, 'dbem_events_default_archive_order', 'ASC', 'yes'),
(2158, 'dbem_events_archive_scope', 'past', 'yes'),
(2159, 'dbem_cp_events_archive_formats', '1', 'yes'),
(2160, 'dbem_cp_events_excerpt_formats', '1', 'yes'),
(2161, 'dbem_cp_events_search_results', '0', 'yes'),
(2162, 'dbem_cp_events_custom_fields', '0', 'yes'),
(2163, 'dbem_cp_events_comments', '1', 'yes'),
(2164, 'dbem_cp_locations_template', '', 'yes'),
(2165, 'dbem_cp_locations_body_class', '', 'yes'),
(2166, 'dbem_cp_locations_post_class', '', 'yes'),
(2167, 'dbem_cp_locations_formats', '1', 'yes'),
(2168, 'dbem_cp_locations_has_archive', '1', 'yes'),
(2169, 'dbem_locations_default_archive_orderby', 'title', 'yes'),
(2170, 'dbem_locations_default_archive_order', 'ASC', 'yes'),
(2171, 'dbem_cp_locations_archive_formats', '1', 'yes'),
(2172, 'dbem_cp_locations_excerpt_formats', '1', 'yes'),
(2173, 'dbem_cp_locations_search_results', '0', 'yes'),
(2174, 'dbem_cp_locations_custom_fields', '0', 'yes'),
(2175, 'dbem_cp_locations_comments', '1', 'yes'),
(2176, 'dbem_cp_categories_formats', '1', 'yes'),
(2177, 'dbem_categories_default_archive_orderby', '_start_ts', 'yes'),
(2178, 'dbem_categories_default_archive_order', 'ASC', 'yes'),
(2179, 'dbem_cp_tags_formats', '1', 'yes'),
(2180, 'dbem_tags_default_archive_orderby', '_start_ts', 'yes'),
(2181, 'dbem_tags_default_archive_order', 'ASC', 'yes'),
(2182, 'dbem_disable_thumbnails', '0', 'yes'),
(2183, 'dbem_feedback_reminder', '1470405159', 'yes'),
(2184, 'dbem_credits', '1', 'yes'),
(2185, 'dbem_time_24h', '1', 'yes'),
(2186, 'dbem_version', '5.6624', 'yes'),
(2187, 'widget_em_locations_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(2193, 'dbem_thumbnails_enabled', '0', 'yes'),
(2194, 'dbem_js_limit', '0', 'yes'),
(2195, 'dbem_js_limit_general', '0', 'yes'),
(2196, 'dbem_js_limit_search', '', 'yes'),
(2197, 'dbem_js_limit_events_form', '', 'yes'),
(2198, 'dbem_js_limit_edit_bookings', '', 'yes'),
(2199, 'dbem_css_limit', '0', 'yes'),
(2200, 'dbem_css_limit_include', '0', 'yes'),
(2201, 'dbem_css_limit_exclude', '0', 'yes'),
(2202, 'dbem_pro_dev_updates', '0', 'yes'),
(2203, 'dbem_disable_title_rewrites', '0', 'yes'),
(2204, 'dbem_title_html', '', 'yes'),
(2205, 'dbem_events_current_are_past', '0', 'yes'),
(2206, 'dbem_bookings_default_orderby', 'event_name', 'yes'),
(2207, 'dbem_bookings_default_order', 'ASC', 'yes'),
(2208, 'dbem_edit_events_page', '', 'yes'),
(2209, 'dbem_edit_locations_page', '', 'yes'),
(2210, 'dbem_edit_bookings_page', '', 'yes'),
(2211, 'dbem_display_calendar_day_single', '0', 'yes'),
(2212, 'dbem_bookings_tickets_show_member_tickets', '0', 'yes'),
(2213, 'dbem_mail_sender_address', '', 'yes'),
(2214, 'dbem_smtp_username', 'thom855j', 'yes'),
(2215, 'dbem_smtp_password', 'sde101292', 'yes'),
(2218, 'woocommerce_db_version', '2.6.4', 'yes'),
(2219, 'woocommerce_version', '2.6.4', 'yes'),
(2221, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(2245, 'wpseo_sitemap_category_cache_validator', '4E9ih', 'no'),
(2392, 'category_children', 'a:0:{}', 'yes'),
(2510, '_site_transient_timeout_browser_aa7adcc5662813180f8b2225f232c91f', '1473521537', 'yes'),
(2511, '_site_transient_browser_aa7adcc5662813180f8b2225f232c91f', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"52.0.2743.116";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'),
(2512, '_transient_timeout_w3tc.verify_plugins', '1473521537', 'no'),
(2513, '_transient_w3tc.verify_plugins', '1', 'no'),
(2532, '_transient_timeout_feed_2d03479375c5e7dc6bd87d3d7aa75972', '1473149854', 'no');
INSERT INTO `go_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2533, '_transient_feed_2d03479375c5e7dc6bd87d3d7aa75972', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n\n\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"\n	\n	\n	\n	\n	\n	\n	\n	\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"BlogSynthesis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://www.blogsynthesis.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:18:"How to blog better";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 May 2016 12:51:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:28:"https://wordpress.org/?v=4.6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:33:"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Add NGINX as NodeBB Proxy Server";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/mZNUKkyqjvE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Dec 2015 10:04:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:5:"Nginx";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"NodeBB";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=2013";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:623:"<p>Since you already have a domain name and server (droplet) ip point domain or subdomain to the IP address with A record. It will take a few minutes to a few hour to work. In the meantime we will configure Nginx. In the previous page of the tutorial we have already NGINX and running. It [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/nginx-as-nodebb-proxy/">Add NGINX as NodeBB Proxy Server</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/mZNUKkyqjvE" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:51:"http://www.blogsynthesis.com/nginx-as-nodebb-proxy/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"\n		\n		\n		\n		\n				\n		\n\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Install NodeBB on DigitalOcean Cloud In 5 minutes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/WAxshy2JCPk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Dec 2015 08:26:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"NodeBB";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=2004";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:539:"<p>It''s really easy to install NodeBB on DigitalOcean Droplet. It will take nearly 5 minutes to start a server and install NodeBB and a few more minutes to configure Nginx as proxy server.</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/install-nodebb-on-digitalocean/">Install NodeBB on DigitalOcean Cloud In 5 minutes</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/WAxshy2JCPk" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.blogsynthesis.com/install-nodebb-on-digitalocean/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:39:"\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"The right way to customize WordPress Themes!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/Tuv2Ti_8DlU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Mar 2015 13:09:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:19:"WordPress Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"Child Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"How to";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1951";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:650:"<p>You are not the only person who wants to customize your WordPress Theme. And there is no single way to tweak your site. There might be multiple ways to do the same thing. In this post we will discuss the right way to modify or customize WordPress theme. What’s in the post? What options are [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/wordpress-theme-customization/">The right way to customize WordPress Themes!</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/Tuv2Ti_8DlU" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:59:"http://www.blogsynthesis.com/wordpress-theme-customization/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:36:"\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"How to make WordPress Print Friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/GMH0uh_oQOQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Dec 2014 12:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"How to";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WP Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1849";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:676:"<p>Offering print friendly version of blog posts not only gives an extra feature but also helps your user to keep their loved article. By default, no WordPress theme offers such feature. This is due to conflicts with plugin and customizations. There is some 3rd party service which offers good features but that could not be solution [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/print-friendly-wordpress/">How to make WordPress Print Friendly</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/GMH0uh_oQOQ" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:54:"http://www.blogsynthesis.com/print-friendly-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:36:"\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"How to install WordPress on Localhost";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/AFKBS3zpAsc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Aug 2014 12:38:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:12:"Installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"localhost";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:15:"WP Installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1598";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:479:"<p>It is easy to install WordPress on Localhost or your PC. We just need XAMPP and WordPress on your WIndows PC. Read the Post of details.</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/localhost-wordpress-installation/">How to install WordPress on Localhost</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/AFKBS3zpAsc" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.blogsynthesis.com/localhost-wordpress-installation/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"\n		\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"3 Steps To Get Yandex Mail For Your Domain With 1000 Users";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/jFNOk9MsE4c/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.blogsynthesis.com/yandex-mail-setup-for-custom-domains/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 17 Aug 2014 09:04:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Email Hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"Yandex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1534";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<p>Sometimes 10, 20 or 50 email accounts might not be enough for your company or organisation. But even then you might not want to invest on email hosting and increase your budget on IT. In this condition Yandex Mails for domains could be a solution. Definitely many people do not want to rely Russian or Chinese [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/yandex-mail-setup-for-custom-domains/">3 Steps To Get Yandex Mail For Your Domain With 1000 Users</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/jFNOk9MsE4c" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.blogsynthesis.com/yandex-mail-setup-for-custom-domains/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.blogsynthesis.com/yandex-mail-setup-for-custom-domains/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"How to Setup Zoho Free Email Hosting (Google Apps &amp; Outlook Custom Domain alternative)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/UW5EFqyWVvc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.blogsynthesis.com/zoho-free-email-hosting/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 16:46:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:8:"Internet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"Email Hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Zoho";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1508";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:632:"<p>Zoho Mail is still free for small business and personal use. In the post Free Outlook for Custom domain and Google Apps, this is the most reliable and free service available. Here is how to Setup Zoho mail for your custom domain email hosting.</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/zoho-free-email-hosting/">How to Setup Zoho Free Email Hosting (Google Apps &#038; Outlook Custom Domain alternative)</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/UW5EFqyWVvc" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.blogsynthesis.com/zoho-free-email-hosting/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"23";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:53:"http://www.blogsynthesis.com/zoho-free-email-hosting/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"How to Track WordPress Login, Register and Dashboard Activity with Google Analytics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/r4mTFYkKnEI/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.blogsynthesis.com/track-wordpress-login-register-and-dashboard/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 16 Feb 2014 11:20:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Analytics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"Google+";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:17:"Intermediate Tuts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:12:"WP Dashboard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1442";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:730:"<p>If you have a multi-author blog or a forum or some membership site based on WordPress. Then, you might like to add Google Analytics to WordPress Login, Register or even dashboard. It will help you to understand better about your users&#8217; requirement and help you to how they are using your site. Another good thing [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/track-wordpress-login-register-and-dashboard/">How to Track WordPress Login, Register and Dashboard Activity with Google Analytics</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/r4mTFYkKnEI" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.blogsynthesis.com/track-wordpress-login-register-and-dashboard/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.blogsynthesis.com/track-wordpress-login-register-and-dashboard/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"\n		\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"How to add Google Analytics to WordPress sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/2RBKv3b1ZGU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.blogsynthesis.com/google-analytics-to-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Feb 2014 13:59:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Analytics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"Google+";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1435";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:676:"<p>Google Analytics is a fabulous analytics tool enabled on more than 10 million websites across the globe. Here we will add Google Analytics to WordPress site. Obviously, we will need a Google Account first. Here I will skip this because most of us already have a GMail or Adsense Account or even an account associated [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/google-analytics-to-wordpress/">How to add Google Analytics to WordPress sites</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/2RBKv3b1ZGU" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:64:"http://www.blogsynthesis.com/google-analytics-to-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:59:"http://www.blogsynthesis.com/google-analytics-to-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"\n		\n		\n		\n		\n		\n				\n		\n		\n		\n		\n\n		\n		\n		\n		\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"How to Create Google Chrome App in Less Than 5 Minutes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/BlogSynthesis/~3/jQi5OwV2tqM/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.blogsynthesis.com/create-chrome-app-in-minutes/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 19 Jan 2014 11:17:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:9:"Tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Apps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"Chrome";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"Google+";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"How to";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://www.blogsynthesis.com/?p=1411";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:648:"<p>With Google Chrome, a lot of things are very easy to do. One of them is creating your own app. Yes, we can create an app in less than 5 minutes. (Considering an image icon of 128&#215;128 px is ready to use). Prerequisites: A credit card for $5 setup fee (Google will charge it for [&#8230;]</p>\n<p>The post <a rel="nofollow" href="http://www.blogsynthesis.com/create-chrome-app-in-minutes/">How to Create Google Chrome App in Less Than 5 Minutes</a> appeared first on <a rel="nofollow" href="http://www.blogsynthesis.com">BlogSynthesis</a>.</p><img src="http://feeds.feedburner.com/~r/BlogSynthesis/~4/jQi5OwV2tqM" height="1" width="1" alt=""/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Anand Kumar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.blogsynthesis.com/create-chrome-app-in-minutes/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.blogsynthesis.com/create-chrome-app-in-minutes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/BlogSynthesis";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"blogsynthesis";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"BlogSynthesis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:29:"https://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:28:"http://www.w3.org/1999/xhtml";a:1:{s:4:"meta";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"name";s:6:"robots";s:7:"content";s:7:"noindex";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:22:"http://pipes.yahoo.com";a:1:{s:4:"meta";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"name";s:5:"pipes";s:7:"content";s:9:"noprocess";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"CcbE8zyEzk/ej2Nyx3VRqSrG2fg";s:13:"last-modified";s:29:"Mon, 05 Sep 2016 19:12:05 GMT";s:16:"content-encoding";s:4:"gzip";s:4:"date";s:29:"Mon, 05 Sep 2016 20:17:34 GMT";s:7:"expires";s:29:"Mon, 05 Sep 2016 20:17:34 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}s:5:"build";s:14:"20160503071608";}', 'no'),
(2534, '_transient_timeout_feed_mod_2d03479375c5e7dc6bd87d3d7aa75972', '1473149854', 'no'),
(2535, '_transient_feed_mod_2d03479375c5e7dc6bd87d3d7aa75972', '1473106654', 'no'),
(2538, '_transient_timeout_wc_report_sales_by_date', '1473232738', 'no'),
(2539, '_transient_wc_report_sales_by_date', 'a:14:{s:32:"b9e0ec78926b8fdc691d2b0ebf4473d8";a:0:{}s:32:"d86996a4aae0dad308e86ae4a5645dd0";a:0:{}s:32:"bbc70726001453db6895b5fb5ba27539";a:0:{}s:32:"d68f971fa0266f65774819174a9219fc";N;s:32:"5acb9a82098cc6eb6b81c915ab2d801b";a:0:{}s:32:"4ff61b14847c4033d17608d749dd5ad7";a:0:{}s:32:"350c5991868df9ca7db38fd044deb27f";a:0:{}s:32:"74a67b2e3559a4dda6fe206781b53b01";a:0:{}s:32:"5f6b183170a20695b51ac64466f9b58f";a:0:{}s:32:"1ab6ee64875df9add329a2d70bc49a6a";a:0:{}s:32:"d9c890abd5bf01252d8164cd0b52400b";N;s:32:"95a4816d2a3e73330c78dbc929f11ac5";a:0:{}s:32:"86335906b996e074323755e7381c76e4";a:0:{}s:32:"fe9dfdb06e520fb8a637a4865c994fe9";a:0:{}}', 'no'),
(2540, '_transient_timeout_wc_low_stock_count', '1475698654', 'no'),
(2541, '_transient_wc_low_stock_count', '0', 'no'),
(2542, '_transient_timeout_wc_outofstock_count', '1475698654', 'no'),
(2543, '_transient_wc_outofstock_count', '0', 'no'),
(2544, '_transient_timeout_wc_admin_report', '1473232708', 'no'),
(2545, '_transient_wc_admin_report', 'a:2:{s:32:"9e9fc48ed7c870177e470b9ddc7f3cb7";a:0:{}s:32:"3d754dd07514e24773c7a48e762ea408";a:0:{}}', 'no'),
(2548, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1473146296;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:9:{s:33:"admin-menu-editor/menu-editor.php";O:8:"stdClass":6:{s:2:"id";s:5:"11743";s:4:"slug";s:17:"admin-menu-editor";s:6:"plugin";s:33:"admin-menu-editor/menu-editor.php";s:11:"new_version";s:5:"1.7.2";s:3:"url";s:48:"https://wordpress.org/plugins/admin-menu-editor/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/admin-menu-editor.1.7.2.zip";}s:33:"events-manager/events-manager.php";O:8:"stdClass":6:{s:2:"id";s:4:"4075";s:4:"slug";s:14:"events-manager";s:6:"plugin";s:33:"events-manager/events-manager.php";s:11:"new_version";s:7:"5.6.6.1";s:3:"url";s:45:"https://wordpress.org/plugins/events-manager/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/events-manager.5.6.6.1.zip";}s:34:"header-and-footer-scripts/shfs.php";O:8:"stdClass":6:{s:2:"id";s:5:"48115";s:4:"slug";s:25:"header-and-footer-scripts";s:6:"plugin";s:34:"header-and-footer-scripts/shfs.php";s:11:"new_version";s:5:"1.3.4";s:3:"url";s:56:"https://wordpress.org/plugins/header-and-footer-scripts/";s:7:"package";s:74:"https://downloads.wordpress.org/plugin/header-and-footer-scripts.1.3.4.zip";}s:27:"redirection/redirection.php";O:8:"stdClass":6:{s:2:"id";s:3:"935";s:4:"slug";s:11:"redirection";s:6:"plugin";s:27:"redirection/redirection.php";s:11:"new_version";s:5:"2.4.5";s:3:"url";s:42:"https://wordpress.org/plugins/redirection/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/redirection.2.4.5.zip";}s:33:"user-switching/user-switching.php";O:8:"stdClass":7:{s:2:"id";s:4:"6923";s:4:"slug";s:14:"user-switching";s:6:"plugin";s:33:"user-switching/user-switching.php";s:11:"new_version";s:5:"1.0.9";s:3:"url";s:45:"https://wordpress.org/plugins/user-switching/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/user-switching.1.0.9.zip";s:14:"upgrade_notice";s:86:"Remove the bundled languages in favour of language packs from translate.wordpress.org.";}s:33:"w3-total-cache/w3-total-cache.php";O:8:"stdClass":7:{s:2:"id";s:4:"9376";s:4:"slug";s:14:"w3-total-cache";s:6:"plugin";s:33:"w3-total-cache/w3-total-cache.php";s:11:"new_version";s:7:"0.9.4.1";s:3:"url";s:45:"https://wordpress.org/plugins/w3-total-cache/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.4.1.zip";s:14:"upgrade_notice";s:140:"Thanks for using W3 Total Cache! This release includes important security updates designed to contribute to a secure WordPress installation.";}s:27:"woocommerce/woocommerce.php";O:8:"stdClass":6:{s:2:"id";s:5:"25331";s:4:"slug";s:11:"woocommerce";s:6:"plugin";s:27:"woocommerce/woocommerce.php";s:11:"new_version";s:5:"2.6.4";s:3:"url";s:42:"https://wordpress.org/plugins/woocommerce/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/woocommerce.2.6.4.zip";}s:25:"wp-user-frontend/wpuf.php";O:8:"stdClass":6:{s:2:"id";s:5:"19815";s:4:"slug";s:16:"wp-user-frontend";s:6:"plugin";s:25:"wp-user-frontend/wpuf.php";s:11:"new_version";s:6:"2.3.15";s:3:"url";s:47:"https://wordpress.org/plugins/wp-user-frontend/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/wp-user-frontend.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:5:"3.4.2";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-seo.3.4.2.zip";}}}', 'no'),
(2549, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1473146298;s:7:"checked";a:2:{s:10:"storefront";s:5:"2.1.1";s:13:"twentyfifteen";s:3:"1.6";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(2551, 'db_upgraded', '', 'yes'),
(2553, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:63:"https://downloads.wordpress.org/release/da_DK/wordpress-4.6.zip";s:6:"locale";s:5:"da_DK";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:63:"https://downloads.wordpress.org/release/da_DK/wordpress-4.6.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.6";s:7:"version";s:3:"4.6";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.4";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1473146296;s:15:"version_checked";s:3:"4.6";s:12:"translations";a:0:{}}', 'no'),
(2554, 'can_compress_scripts', '0', 'no'),
(2555, '_transient_timeout_yoast_i18n_wordpress-seo_da_DK', '1473193321', 'no'),
(2556, '_transient_yoast_i18n_wordpress-seo_da_DK', 'O:8:"stdClass":12:{s:2:"id";s:2:"11";s:4:"name";s:6:"Danish";s:4:"slug";s:7:"default";s:10:"project_id";s:1:"1";s:6:"locale";s:2:"da";s:13:"current_count";i:919;s:18:"untranslated_count";i:55;s:13:"waiting_count";i:0;s:11:"fuzzy_count";i:8;s:18:"percent_translated";i:94;s:9:"wp_locale";s:5:"da_DK";s:13:"last_modified";s:19:"2016-08-17 09:52:17";}', 'no'),
(2558, 'wpseo_sitemap_170_cache_validator', '6jkuH', 'no'),
(2559, 'wpseo_sitemap_171_cache_validator', '6jkuW', 'no'),
(2560, 'wpseo_sitemap_172_cache_validator', '6jkv8', 'no'),
(2561, 'wpseo_sitemap_174_cache_validator', '6jkvh', 'no'),
(2562, 'wpseo_sitemap_175_cache_validator', '6jkvr', 'no'),
(2563, 'wpseo_sitemap_177_cache_validator', '6jkvC', 'no'),
(2564, 'wpseo_sitemap_178_cache_validator', '6jkvI', 'no'),
(2565, 'wpseo_sitemap_179_cache_validator', '6jkvT', 'no'),
(2566, 'wpseo_sitemap_180_cache_validator', '6jkw5', 'no'),
(2567, 'wpseo_sitemap_181_cache_validator', '6jkwm', 'no'),
(2568, 'wpseo_sitemap_183_cache_validator', '6jkwH', 'no'),
(2569, 'wpseo_sitemap_185_cache_validator', '6jkwX', 'no'),
(2570, 'wpseo_sitemap_186_cache_validator', '6jkxb', 'no'),
(2571, 'wpseo_sitemap_187_cache_validator', '6jkxk', 'no'),
(2572, 'wpseo_sitemap_188_cache_validator', '6jkxv', 'no'),
(2573, 'wpseo_sitemap_196_cache_validator', '6jkxU', 'no'),
(2574, 'wpseo_sitemap_198_cache_validator', '6jky4', 'no'),
(2575, 'wpseo_sitemap_199_cache_validator', '6jkyg', 'no'),
(2576, 'wpseo_sitemap_98_cache_validator', 'xlUJ', 'no'),
(2577, 'wpseo_sitemap_112_cache_validator', 'xlVk', 'no'),
(2578, 'wpseo_sitemap_113_cache_validator', 'xlVu', 'no'),
(2579, 'wpseo_sitemap_114_cache_validator', 'xlVO', 'no'),
(2580, 'wpseo_sitemap_115_cache_validator', 'xlVY', 'no'),
(2581, 'wpseo_sitemap_116_cache_validator', 'xlW7', 'no'),
(2582, 'wpseo_sitemap_119_cache_validator', '6jr98', 'no'),
(2583, 'wpseo_sitemap_120_cache_validator', '6jr9l', 'no'),
(2584, 'wpseo_sitemap_121_cache_validator', '6jr9w', 'no'),
(2585, 'wpseo_sitemap_123_cache_validator', '6jr9H', 'no'),
(2586, 'wpseo_sitemap_124_cache_validator', '6jr9Q', 'no'),
(2587, 'wpseo_sitemap_125_cache_validator', '6jr9Y', 'no'),
(2588, 'wpseo_sitemap_126_cache_validator', '6jra8', 'no'),
(2589, 'wpseo_sitemap_127_cache_validator', '6jrak', 'no'),
(2590, 'wpseo_sitemap_128_cache_validator', '6jrav', 'no'),
(2591, 'wpseo_sitemap_130_cache_validator', '6jraC', 'no'),
(2592, 'wpseo_sitemap_131_cache_validator', '6jraO', 'no'),
(2593, 'wpseo_sitemap_132_cache_validator', '6jraY', 'no'),
(2594, 'wpseo_sitemap_145_cache_validator', '6jrb7', 'no'),
(2595, 'wpseo_sitemap_147_cache_validator', '6jrbe', 'no'),
(2596, 'wpseo_sitemap_149_cache_validator', '6jrbm', 'no'),
(2597, 'wpseo_sitemap_150_cache_validator', '6jrbz', 'no'),
(2598, '_transient_is_multi_author', '0', 'yes'),
(2599, '_transient_timeout_wpseo-dashboard-totals', '1473232738', 'no'),
(2600, '_transient_wpseo-dashboard-totals', 'a:1:{i:1;a:1:{i:3;a:5:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Indlæg uden fokusnøgleord";s:5:"class";s:15:"wpseo-glance-na";s:10:"icon_class";s:2:"na";s:5:"count";s:1:"1";}}}', 'no'),
(2601, '_transient_timeout_plugin_slugs', '1473193486', 'no'),
(2602, '_transient_plugin_slugs', 'a:10:{i:0;s:33:"admin-menu-editor/menu-editor.php";i:1;s:33:"events-manager/events-manager.php";i:2;s:34:"header-and-footer-scripts/shfs.php";i:3;s:53:"pressapps-knowledge-base/pressapps-knowledge-base.php";i:4;s:27:"redirection/redirection.php";i:5;s:33:"user-switching/user-switching.php";i:6;s:33:"w3-total-cache/w3-total-cache.php";i:7;s:65:"codecanyon-6463373-web-20-directory-plugin-for-wordpress/w2dc.php";i:8;s:27:"woocommerce/woocommerce.php";i:9;s:24:"wordpress-seo/wp-seo.php";}', 'no'),
(2604, '_site_transient_timeout_theme_roots', '1473148097', 'no'),
(2605, '_site_transient_theme_roots', 'a:2:{s:10:"storefront";s:7:"/themes";s:13:"twentyfifteen";s:71:"/home/websuppo/public_html/project08.websupport.dk/wp/wp-content/themes";}', 'no');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_postmeta`
--

CREATE TABLE IF NOT EXISTS `go_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1052 ;

--
-- Data dump for tabellen `go_postmeta`
--

INSERT INTO `go_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7, 5, '_edit_last', '2'),
(8, 5, '_edit_lock', '1468392580:1'),
(9, 9, '_menu_item_type', 'post_type'),
(10, 9, '_menu_item_menu_item_parent', '0'),
(11, 9, '_menu_item_object_id', '5'),
(12, 9, '_menu_item_object', 'page'),
(13, 9, '_menu_item_target', ''),
(14, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(15, 9, '_menu_item_xfn', ''),
(16, 9, '_menu_item_url', ''),
(18, 10, '_edit_last', '1'),
(19, 10, '_edit_lock', '1462529353:1'),
(20, 12, '_menu_item_type', 'post_type'),
(21, 12, '_menu_item_menu_item_parent', '9'),
(22, 12, '_menu_item_object_id', '10'),
(23, 12, '_menu_item_object', 'page'),
(24, 12, '_menu_item_target', ''),
(25, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 12, '_menu_item_xfn', ''),
(27, 12, '_menu_item_url', ''),
(29, 10, '_wp_page_template', 'default'),
(30, 15, '_edit_last', '1'),
(31, 15, '_edit_lock', '1467836565:1'),
(32, 15, '_wp_page_template', 'default'),
(33, 20, '_edit_last', '1'),
(34, 20, '_edit_lock', '1463589026:1'),
(35, 20, '_wp_page_template', 'default'),
(36, 22, '_menu_item_type', 'post_type'),
(37, 22, '_menu_item_menu_item_parent', '9'),
(38, 22, '_menu_item_object_id', '20'),
(39, 22, '_menu_item_object', 'page'),
(40, 22, '_menu_item_target', ''),
(41, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(42, 22, '_menu_item_xfn', ''),
(43, 22, '_menu_item_url', ''),
(45, 23, '_menu_item_type', 'post_type'),
(46, 23, '_menu_item_menu_item_parent', '9'),
(47, 23, '_menu_item_object_id', '15'),
(48, 23, '_menu_item_object', 'page'),
(49, 23, '_menu_item_target', ''),
(50, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(51, 23, '_menu_item_xfn', ''),
(52, 23, '_menu_item_url', ''),
(53, 42, '_edit_last', '1'),
(54, 42, '_wp_page_template', 'default'),
(55, 42, '_edit_lock', '1470404972:1'),
(56, 45, '_edit_last', '1'),
(57, 45, '_wp_page_template', 'default'),
(58, 45, '_edit_lock', '1463588999:1'),
(59, 47, '_menu_item_type', 'post_type'),
(60, 47, '_menu_item_menu_item_parent', '0'),
(61, 47, '_menu_item_object_id', '45'),
(62, 47, '_menu_item_object', 'page'),
(63, 47, '_menu_item_target', ''),
(64, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(65, 47, '_menu_item_xfn', ''),
(66, 47, '_menu_item_url', ''),
(121, 79, '_wp_attached_file', '2016/07/go-logo.png'),
(122, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:6842;s:6:"height";i:2344;s:4:"file";s:19:"2016/07/go-logo.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"go-logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"go-logo-300x103.png";s:5:"width";i:300;s:6:"height";i:103;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:19:"go-logo-768x263.png";s:5:"width";i:768;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:20:"go-logo-1024x351.png";s:5:"width";i:1024;s:6:"height";i:351;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"go-logo-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"go-logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:19:"go-logo-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(152, 94, '_edit_lock', '1467831329:1'),
(153, 94, '_edit_last', '1'),
(154, 94, '_wp_page_template', 'default'),
(155, 94, '_yoast_wpseo_content_score', '30'),
(158, 97, '_menu_item_type', 'post_type'),
(159, 97, '_menu_item_menu_item_parent', '0'),
(160, 97, '_menu_item_object_id', '94'),
(161, 97, '_menu_item_object', 'page'),
(162, 97, '_menu_item_target', ''),
(163, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(164, 97, '_menu_item_xfn', ''),
(165, 97, '_menu_item_url', ''),
(188, 25, '_edit_last', '1'),
(189, 25, '_edit_lock', '1467836489:1'),
(190, 26, '_edit_last', '1'),
(191, 26, '_edit_lock', '1467836503:1'),
(192, 27, '_edit_last', '1'),
(193, 27, '_edit_lock', '1467836515:1'),
(194, 24, '_edit_last', '1'),
(195, 24, '_edit_lock', '1467836579:1'),
(196, 110, '_wp_attached_file', '2016/07/cropped-go-logo.png'),
(197, 110, '_wp_attachment_context', 'custom-logo'),
(198, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:372;s:6:"height";i:110;s:4:"file";s:27:"2016/07/cropped-go-logo.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"cropped-go-logo-150x110.png";s:5:"width";i:150;s:6:"height";i:110;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"cropped-go-logo-300x89.png";s:5:"width";i:300;s:6:"height";i:89;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"cropped-go-logo-180x110.png";s:5:"width";i:180;s:6:"height";i:110;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"cropped-go-logo-300x110.png";s:5:"width";i:300;s:6:"height";i:110;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(318, 134, '_menu_item_type', 'post_type'),
(319, 134, '_menu_item_menu_item_parent', '0'),
(320, 134, '_menu_item_object_id', '10'),
(321, 134, '_menu_item_object', 'page'),
(322, 134, '_menu_item_target', ''),
(323, 134, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(324, 134, '_menu_item_xfn', ''),
(325, 134, '_menu_item_url', ''),
(326, 135, '_menu_item_type', 'post_type'),
(327, 135, '_menu_item_menu_item_parent', '0'),
(328, 135, '_menu_item_object_id', '15'),
(329, 135, '_menu_item_object', 'page'),
(330, 135, '_menu_item_target', ''),
(331, 135, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(332, 135, '_menu_item_xfn', ''),
(333, 135, '_menu_item_url', ''),
(334, 136, '_menu_item_type', 'post_type'),
(335, 136, '_menu_item_menu_item_parent', '0'),
(336, 136, '_menu_item_object_id', '20'),
(337, 136, '_menu_item_object', 'page'),
(338, 136, '_menu_item_target', ''),
(339, 136, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(340, 136, '_menu_item_xfn', ''),
(341, 136, '_menu_item_url', ''),
(342, 137, '_menu_item_type', 'post_type'),
(343, 137, '_menu_item_menu_item_parent', '0'),
(344, 137, '_menu_item_object_id', '27'),
(345, 137, '_menu_item_object', 'page'),
(346, 137, '_menu_item_target', ''),
(347, 137, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(348, 137, '_menu_item_xfn', ''),
(349, 137, '_menu_item_url', ''),
(350, 138, '_menu_item_type', 'post_type'),
(351, 138, '_menu_item_menu_item_parent', '0'),
(352, 138, '_menu_item_object_id', '10'),
(353, 138, '_menu_item_object', 'page'),
(354, 138, '_menu_item_target', ''),
(355, 138, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(356, 138, '_menu_item_xfn', ''),
(357, 138, '_menu_item_url', ''),
(358, 139, '_menu_item_type', 'post_type'),
(359, 139, '_menu_item_menu_item_parent', '0'),
(360, 139, '_menu_item_object_id', '15'),
(361, 139, '_menu_item_object', 'page'),
(362, 139, '_menu_item_target', ''),
(363, 139, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(364, 139, '_menu_item_xfn', ''),
(365, 139, '_menu_item_url', ''),
(366, 140, '_menu_item_type', 'post_type'),
(367, 140, '_menu_item_menu_item_parent', '0'),
(368, 140, '_menu_item_object_id', '20'),
(369, 140, '_menu_item_object', 'page'),
(370, 140, '_menu_item_target', ''),
(371, 140, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(372, 140, '_menu_item_xfn', ''),
(373, 140, '_menu_item_url', ''),
(374, 141, '_menu_item_type', 'post_type'),
(375, 141, '_menu_item_menu_item_parent', '0'),
(376, 141, '_menu_item_object_id', '27'),
(377, 141, '_menu_item_object', 'page'),
(378, 141, '_menu_item_target', ''),
(379, 141, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(380, 141, '_menu_item_xfn', ''),
(381, 141, '_menu_item_url', ''),
(382, 42, '_yoast_wpseo_content_score', '60'),
(543, 5, '_wp_page_template', 'template-fullwidth.php'),
(544, 5, '_yoast_wpseo_content_score', '60'),
(862, 204, '_edit_last', '1'),
(863, 204, '_edit_lock', '1470405411:1'),
(864, 211, '_menu_item_type', 'post_type'),
(865, 211, '_menu_item_menu_item_parent', '0'),
(866, 211, '_menu_item_object_id', '204'),
(867, 211, '_menu_item_object', 'page'),
(868, 211, '_menu_item_target', ''),
(869, 211, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(870, 211, '_menu_item_xfn', ''),
(871, 211, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_posts`
--

CREATE TABLE IF NOT EXISTS `go_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=218 ;

--
-- Data dump for tabellen `go_posts`
--

INSERT INTO `go_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-05-06 09:46:21', '2016-05-06 09:46:21', 'Velkommen til WordPress. Dette er dit første indlæg. Ret eller slet det og begynd derefter at skrive!', 'Hej Verden!', '', 'publish', 'open', 'open', '', 'hej-verden', '', '', '2016-05-06 09:46:21', '2016-05-06 09:46:21', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=1', 0, 'post', '', 1),
(5, 1, '2016-05-06 09:50:27', '2016-05-06 09:50:27', '[webdirectory]', 'DE GRØNNE SIDER', '', 'publish', 'closed', 'closed', '', 'sider', '', '', '2016-07-11 18:07:51', '2016-07-11 18:07:51', '', 0, 'http://www.xn--grntoverblik-wjb.dk/web-2-0-directory/', 0, 'page', '', 0),
(7, 1, '2016-05-06 09:53:45', '2016-05-06 09:53:45', '[webdirectory]', 'projekter', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-05-06 09:53:45', '2016-05-06 09:53:45', '', 5, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/5-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2016-05-06 09:54:11', '2016-05-06 09:54:11', '[webdirectory]', 'DE GRØNNE SIDER', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-05-06 09:54:11', '2016-05-06 09:54:11', '', 5, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/5-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2016-05-06 09:54:35', '2016-05-06 09:54:35', ' ', '', '', 'publish', 'closed', 'closed', '', '9', '', '', '2016-08-05 13:58:23', '2016-08-05 13:58:23', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2016-05-06 09:58:22', '2016-05-06 09:58:22', '[webdirectory-submit]', 'Opret', '', 'publish', 'closed', 'closed', '', 'opret', '', '', '2016-05-06 10:09:13', '2016-05-06 10:09:13', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?page_id=10', 0, 'page', '', 0),
(11, 1, '2016-05-06 09:58:22', '2016-05-06 09:58:22', '', 'Opret', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-06 09:58:22', '2016-05-06 09:58:22', '', 10, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2016-05-06 09:59:34', '2016-05-06 09:59:34', ' ', '', '', 'publish', 'closed', 'closed', '', '12', '', '', '2016-08-05 13:58:23', '2016-08-05 13:58:23', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=12', 2, 'nav_menu_item', '', 0),
(13, 1, '2016-05-06 10:06:45', '2016-05-06 10:06:45', '[webdirectory-submit]', 'Opret', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-06 10:06:45', '2016-05-06 10:06:45', '', 10, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/10-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2016-05-06 10:07:36', '2016-05-06 10:07:36', '[webdirectory-dashboard] ', 'Mine sider', '', 'publish', 'closed', 'closed', '', 'bruger-sider', '', '', '2016-07-06 20:22:45', '2016-07-06 20:22:45', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?page_id=15', 0, 'page', '', 0),
(16, 1, '2016-05-06 10:07:36', '2016-05-06 10:07:36', '[webdirectory-dashboard] ', 'Mine projekter', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2016-05-06 10:07:36', '2016-05-06 10:07:36', '', 15, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/15-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-05-06 10:11:02', '2016-05-06 10:11:02', '', 'Betingelser', '', 'publish', 'closed', 'closed', '', 'betingelser', '', '', '2016-05-18 16:30:25', '2016-05-18 16:30:25', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?page_id=20', 0, 'page', '', 0),
(21, 1, '2016-05-06 10:11:02', '2016-05-06 10:11:02', '', 'Betinelser', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-06 10:11:02', '2016-05-06 10:11:02', '', 20, 'http://www.xn--grntoverblik-wjb.dk/2016/05/06/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2016-05-06 10:11:28', '2016-05-06 10:11:28', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2016-08-05 13:58:24', '2016-08-05 13:58:24', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=22', 4, 'nav_menu_item', '', 0),
(23, 1, '2016-05-06 10:11:28', '2016-05-06 10:11:28', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2016-08-05 13:58:24', '2016-08-05 13:58:24', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=23', 3, 'nav_menu_item', '', 0),
(24, 1, '2016-05-06 10:17:21', '2016-05-06 10:17:21', '', 'Butik', '', 'publish', 'closed', 'closed', '', 'butik', '', '', '2016-07-06 20:22:58', '2016-07-06 20:22:58', '', 0, 'http://www.xn--grntoverblik-wjb.dk/shop/', 0, 'page', '', 0),
(25, 1, '2016-05-06 10:17:21', '2016-05-06 10:17:21', '[woocommerce_cart]', 'Kurv', '', 'publish', 'closed', 'closed', '', 'kurv', '', '', '2016-07-06 20:21:28', '2016-07-06 20:21:28', '', 0, 'http://www.xn--grntoverblik-wjb.dk/cart/', 0, 'page', '', 0),
(26, 2, '2016-05-06 10:17:21', '2016-05-06 10:17:21', '[woocommerce_checkout]', 'Kasse', '', 'publish', 'closed', 'closed', '', 'kasse', '', '', '2016-07-06 20:21:43', '2016-07-06 20:21:43', '', 0, 'http://www.xn--grntoverblik-wjb.dk/checkout/', 0, 'page', '', 0),
(27, 2, '2016-05-06 10:17:21', '2016-05-06 10:17:21', '[woocommerce_my_account]', 'Konto', '', 'publish', 'closed', 'closed', '', 'konto', '', '', '2016-07-06 20:21:55', '2016-07-06 20:21:55', '', 0, 'http://www.xn--grntoverblik-wjb.dk/my-account/', 0, 'page', '', 0),
(41, 1, '2016-05-18 16:30:25', '2016-05-18 16:30:25', '', 'Betingelser', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-18 16:30:25', '2016-05-18 16:30:25', '', 20, 'http://www.xn--grntoverblik-wjb.dk/2016/05/18/20-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2016-05-18 16:30:50', '2016-05-18 16:30:50', '<table style="height: 180px;" border="0" width="436" cellspacing="0" cellpadding="4" align="center">\r\n<tbody>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/sider/">De Grønne Sider</a> </span><span class="footer">- det økologiske modstykke til De Gule Sider</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/kalender">Øko-Kalenderen</a></span><span class="footer"> - guide til grønne events, kurser mv.</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/bibliotek/">Det Grønne Bibliotek</a></span><span class="footer"> - økologisk videns-samling</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/aktuelt/">Aktuelt</a></span><span class="footer"> - Nyheder og andet aktualitetsstof</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'SEKTIONER', '', 'publish', 'closed', 'closed', '', 'forside', '', '', '2016-08-05 13:50:51', '2016-08-05 13:50:51', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?page_id=42', 0, 'page', '', 0),
(45, 1, '2016-05-18 16:32:14', '2016-05-18 16:32:14', '', 'AKTUELT', '', 'publish', 'closed', 'closed', '', 'aktuelt', '', '', '2016-05-18 16:32:14', '2016-05-18 16:32:14', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?page_id=45', 0, 'page', '', 0),
(46, 1, '2016-05-18 16:32:14', '2016-05-18 16:32:14', '', 'AKTUELT', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2016-05-18 16:32:14', '2016-05-18 16:32:14', '', 45, 'http://www.xn--grntoverblik-wjb.dk/2016/05/18/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2016-05-18 16:38:04', '2016-05-18 16:38:04', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2016-08-05 13:58:24', '2016-08-05 13:58:24', '', 0, 'http://www.xn--grntoverblik-wjb.dk/?p=47', 7, 'nav_menu_item', '', 0),
(79, 2, '2016-07-06 17:45:42', '2016-07-06 17:45:42', '', 'go-logo', '', 'inherit', 'open', 'closed', '', 'go-logo', '', '', '2016-07-06 17:45:42', '2016-07-06 17:45:42', '', 0, 'https://xn--grntoverblik-wjb.dk/app/uploads/2016/07/go-logo.png', 0, 'attachment', 'image/png', 0),
(94, 1, '2016-07-06 18:50:59', '2016-07-06 18:50:59', '', 'DET GRØNNE BIBLIOTEK', '', 'publish', 'closed', 'closed', '', 'bibliotek', '', '', '2016-07-06 18:50:59', '2016-07-06 18:50:59', '', 0, 'https://xn--grntoverblik-wjb.dk/?page_id=94', 0, 'page', '', 0),
(95, 1, '2016-07-06 18:50:59', '2016-07-06 18:50:59', '', 'DET GRØNNE BIBLIOTEK', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2016-07-06 18:50:59', '2016-07-06 18:50:59', '', 94, 'https://xn--grntoverblik-wjb.dk/2016/07/06/94-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2016-07-06 18:56:39', '2016-07-06 18:56:39', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2016-08-05 13:58:24', '2016-08-05 13:58:24', '', 0, 'https://xn--grntoverblik-wjb.dk/?p=97', 5, 'nav_menu_item', '', 0),
(104, 1, '2016-07-06 20:21:28', '2016-07-06 20:21:28', '[woocommerce_cart]', 'Kurv', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-07-06 20:21:28', '2016-07-06 20:21:28', '', 25, 'https://xn--grntoverblik-wjb.dk/2016/07/06/25-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2016-07-06 20:21:43', '2016-07-06 20:21:43', '[woocommerce_checkout]', 'Kasse', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-07-06 20:21:43', '2016-07-06 20:21:43', '', 26, 'https://xn--grntoverblik-wjb.dk/2016/07/06/26-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2016-07-06 20:21:55', '2016-07-06 20:21:55', '[woocommerce_my_account]', 'Konto', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2016-07-06 20:21:55', '2016-07-06 20:21:55', '', 27, 'https://xn--grntoverblik-wjb.dk/2016/07/06/27-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2016-07-06 20:22:45', '2016-07-06 20:22:45', '[webdirectory-dashboard] ', 'Mine sider', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2016-07-06 20:22:45', '2016-07-06 20:22:45', '', 15, 'https://xn--grntoverblik-wjb.dk/2016/07/06/15-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2016-07-06 20:22:58', '2016-07-06 20:22:58', '', 'Butik', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-07-06 20:22:58', '2016-07-06 20:22:58', '', 24, 'https://xn--grntoverblik-wjb.dk/2016/07/06/24-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2016-07-07 16:01:51', '2016-07-07 16:01:51', 'https://xn--grntoverblik-wjb.dk/app/uploads/2016/07/cropped-go-logo.png', 'cropped-go-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-go-logo-png', '', '', '2016-07-07 16:01:51', '2016-07-07 16:01:51', '', 0, 'https://xn--grntoverblik-wjb.dk/app/uploads/2016/07/cropped-go-logo.png', 0, 'attachment', 'image/png', 0),
(134, 2, '2016-07-07 18:19:11', '2016-07-07 18:19:11', ' ', '', '', 'publish', 'closed', 'closed', '', '134', '', '', '2016-07-07 18:19:11', '2016-07-07 18:19:11', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/134/', 1, 'nav_menu_item', '', 0),
(135, 2, '2016-07-07 18:19:12', '2016-07-07 18:19:12', ' ', '', '', 'publish', 'closed', 'closed', '', '135', '', '', '2016-07-07 18:19:12', '2016-07-07 18:19:12', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/135/', 2, 'nav_menu_item', '', 0),
(136, 2, '2016-07-07 18:19:13', '2016-07-07 18:19:13', ' ', '', '', 'publish', 'closed', 'closed', '', '136', '', '', '2016-07-07 18:19:13', '2016-07-07 18:19:13', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/136/', 4, 'nav_menu_item', '', 0),
(137, 2, '2016-07-07 18:19:13', '2016-07-07 18:19:13', ' ', '', '', 'publish', 'closed', 'closed', '', '137', '', '', '2016-07-07 18:19:13', '2016-07-07 18:19:13', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/137/', 3, 'nav_menu_item', '', 0),
(138, 2, '2016-07-07 18:19:14', '2016-07-07 18:19:14', ' ', '', '', 'publish', 'closed', 'closed', '', '138', '', '', '2016-07-07 18:19:14', '2016-07-07 18:19:14', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/138/', 1, 'nav_menu_item', '', 0),
(139, 2, '2016-07-07 18:19:15', '2016-07-07 18:19:15', ' ', '', '', 'publish', 'closed', 'closed', '', '139', '', '', '2016-07-07 18:19:15', '2016-07-07 18:19:15', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/139/', 2, 'nav_menu_item', '', 0),
(140, 2, '2016-07-07 18:19:15', '2016-07-07 18:19:15', ' ', '', '', 'publish', 'closed', 'closed', '', '140', '', '', '2016-07-07 18:19:15', '2016-07-07 18:19:15', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/140/', 4, 'nav_menu_item', '', 0),
(141, 2, '2016-07-07 18:19:15', '2016-07-07 18:19:15', ' ', '', '', 'publish', 'closed', 'closed', '', '141', '', '', '2016-07-07 18:19:15', '2016-07-07 18:19:15', '', 0, 'https://xn--grntoverblik-wjb.dk/2016/07/07/141/', 3, 'nav_menu_item', '', 0),
(142, 1, '2016-08-05 13:50:14', '2016-08-05 13:50:14', '<table border="0" cellspacing="0" cellpadding="4" align="center">\n<tbody>\n<tr>\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/sider/">De Grønne Sider</a> </span><span class="footer">- det økologiske modstykke til De Gule Sider</span></td>\n</tr>\n<tr>\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/kalender">Øko-Kalenderen</a></span><span class="footer"> - guide til grønne events, kurser mv.</span></td>\n</tr>\n<tr>\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/bibliotek/">Det Grønne Bibliotek</a></span><span class="footer"> - økologisk videns-samling</span></td>\n</tr>\n<tr>\n<td colspan="2"></td>\n</tr>\n<tr>\n<td colspan="2"><span class="homeHeader"><a href="https://xn--grntoverblik-wjb.dk/aktuelt/">Aktuelt</a></span><span class="footer"> - Nyheder og andet aktualitetsstof</span></td>\n</tr>\n</tbody>\n</table>', 'SEKTIONER', '', 'inherit', 'closed', 'closed', '', '42-autosave-v1', '', '', '2016-08-05 13:50:14', '2016-08-05 13:50:14', '', 42, 'https://xn--grntoverblik-wjb.dk/2016/07/07/42-autosave-v1/', 0, 'revision', '', 0),
(143, 1, '2016-07-07 18:23:56', '2016-07-07 18:23:56', '<table border="0" cellspacing="0" cellpadding="4" align="center">\r\n<tbody>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://xn--grntoverblik-wjb.dk/sider/">De Grønne Sider</a> </span><span class="footer">- det økologiske modstykke til De Gule Sider</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="http://www.xn--grntoverblik-wjb.dk/ok/index.asp">Øko-Kalenderen</a></span><span class="footer"> - guide til grønne events, kurser mv.</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://xn--grntoverblik-wjb.dk/bibliotek/">Det Grønne Bibliotek</a></span><span class="footer"> - økologisk videns-samling</span>\r\n<table border="0" width="98%" cellspacing="3" cellpadding="0" align="center">\r\n<tbody>\r\n<tr>\r\n<td><img src="http://www.xn--grntoverblik-wjb.dk/shared/graphics/layout/empty.gif" /></td>\r\n<td><img src="http://www.xn--grntoverblik-wjb.dk/shared/graphics/layout/alertarrow.gif" width="14" height="8" /><a href="http://www.xn--grntoverblik-wjb.dk/art/index.asp">Se også <b>Artikeldatabasen</b></a></td>\r\n</tr>\r\n<tr>\r\n<td><img src="http://www.xn--grntoverblik-wjb.dk/shared/graphics/layout/empty.gif" /></td>\r\n<td><a href="http://www.xn--grntoverblik-wjb.dk/dgb/detail.asp?id=6828">Bondefangeri - ny bog fra Kjeld Hansen</a></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="http://www.xn--grntoverblik-wjb.dk/opsl/index.asp">Opslagstavlen</a></span><span class="footer"> - fra bruger til bruger</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://xn--grntoverblik-wjb.dk/aktuelt/">Aktuelt</a></span><span class="footer"> - Nyheder og andet aktualitetsstof</span></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'SEKTIONER', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2016-07-07 18:23:56', '2016-07-07 18:23:56', '', 42, 'https://xn--grntoverblik-wjb.dk/2016/07/07/42-revision-v1/', 0, 'revision', '', 0),
(203, 1, '2016-08-05 13:50:51', '2016-08-05 13:50:51', '<table style="height: 180px;" border="0" width="436" cellspacing="0" cellpadding="4" align="center">\r\n<tbody>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/sider/">De Grønne Sider</a> </span><span class="footer">- det økologiske modstykke til De Gule Sider</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/kalender">Øko-Kalenderen</a></span><span class="footer"> - guide til grønne events, kurser mv.</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/bibliotek/">Det Grønne Bibliotek</a></span><span class="footer"> - økologisk videns-samling</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"><span class="homeHeader"><a href="https://project08.websupport.dk/aktuelt/">Aktuelt</a></span><span class="footer"> - Nyheder og andet aktualitetsstof</span></td>\r\n</tr>\r\n<tr>\r\n<td colspan="2"></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'SEKTIONER', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2016-08-05 13:50:51', '2016-08-05 13:50:51', '', 42, 'https://project08.websupport.dk/2016/08/05/42-revision-v1/', 0, 'revision', '', 0),
(204, 1, '2016-08-05 13:52:38', '2016-08-05 13:52:38', 'CONTENTS', 'Kalender', 'CONTENTS', 'publish', 'closed', 'closed', '', 'kalender', '', '', '2016-08-05 13:56:51', '2016-08-05 13:56:51', '', 0, 'https://project08.websupport.dk/events/', 0, 'page', '', 0),
(205, 1, '2016-08-05 13:52:38', '2016-08-05 13:52:38', 'CONTENTS', 'Lokationer', '', 'publish', 'closed', 'open', '', 'lokationer', '', '', '2016-08-05 13:52:38', '2016-08-05 13:52:38', '', 204, 'https://project08.websupport.dk/events/lokationer/', 0, 'page', '', 0),
(206, 1, '2016-08-05 13:52:38', '2016-08-05 13:52:38', 'CONTENTS', 'Kategori', '', 'publish', 'closed', 'open', '', 'kategori', '', '', '2016-08-05 13:52:38', '2016-08-05 13:52:38', '', 204, 'https://project08.websupport.dk/events/kategori/', 0, 'page', '', 0),
(207, 1, '2016-08-05 13:52:38', '2016-08-05 13:52:38', 'CONTENTS', 'Tags', '', 'publish', 'closed', 'open', '', 'tags', '', '', '2016-08-05 13:52:38', '2016-08-05 13:52:38', '', 204, 'https://project08.websupport.dk/events/tags/', 0, 'page', '', 0),
(208, 1, '2016-08-05 13:52:38', '2016-08-05 13:52:38', 'CONTENTS', 'Mine tilmeldinger', '', 'publish', 'closed', 'open', '', 'mine-tilmeldinger', '', '', '2016-08-05 13:52:38', '2016-08-05 13:52:38', '', 204, 'https://project08.websupport.dk/events/mine-tilmeldinger/', 0, 'page', '', 0),
(210, 1, '2016-08-05 13:56:51', '2016-08-05 13:56:51', 'CONTENTS', 'Kalender', 'CONTENTS', 'inherit', 'closed', 'closed', '', '204-revision-v1', '', '', '2016-08-05 13:56:51', '2016-08-05 13:56:51', '', 204, 'https://project08.websupport.dk/2016/08/05/204-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2016-08-05 13:58:08', '2016-08-05 13:58:08', '', 'KALENDER', '', 'publish', 'closed', 'closed', '', '211', '', '', '2016-08-05 13:58:24', '2016-08-05 13:58:24', '', 0, 'https://project08.websupport.dk/?p=211', 6, 'nav_menu_item', '', 0),
(215, 1, '2016-09-03 15:32:18', '0000-00-00 00:00:00', '', 'Automatisk kladde', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-03 15:32:18', '0000-00-00 00:00:00', '', 0, 'https://project08.websupport.dk/?p=215', 0, 'post', '', 0),
(216, 1, '2016-09-03 15:32:58', '0000-00-00 00:00:00', '', 'Automatisk kladde', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2016-09-03 15:32:58', '0000-00-00 00:00:00', '', 0, 'https://project08.websupport.dk/sider/publikation/', 0, 'w2dc_listing', '', 0),
(217, 1, '2016-09-05 20:23:22', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2016-09-05 20:23:22', '0000-00-00 00:00:00', '', 0, 'https://project08.websupport.dk/sider/publikation/', 0, 'w2dc_listing', '', 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_redirection_404`
--

CREATE TABLE IF NOT EXISTS `go_redirection_404` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `url` (`url`(191)),
  KEY `ip` (`ip`),
  KEY `referrer` (`referrer`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Data dump for tabellen `go_redirection_404`
--

INSERT INTO `go_redirection_404` (`id`, `created`, `url`, `agent`, `referrer`, `ip`) VALUES
(1, '2016-09-03 15:32:06', '/admin', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36', NULL, 1346270420),
(2, '2016-09-03 15:33:14', '/wp/wp-admin/admin.php?page=w2dc_content_fields&action=edit&field_id=2', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36', 'https://project08.websupport.dk/wp/wp-admin/admin.php?page=w2dc_content_fields', 1346270420),
(3, '2016-09-03 15:33:14', '/wp/wp-admin/admin.php?page=w2dc_content_fields', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36', 'https://project08.websupport.dk/wp/wp-admin/', 1346270420);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_redirection_groups`
--

CREATE TABLE IF NOT EXISTS `go_redirection_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tracking` int(11) NOT NULL DEFAULT '1',
  `module_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `position` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_redirection_groups`
--

INSERT INTO `go_redirection_groups` (`id`, `name`, `tracking`, `module_id`, `status`, `position`) VALUES
(1, 'adgang', 1, 1, 'enabled', 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_redirection_items`
--

CREATE TABLE IF NOT EXISTS `go_redirection_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `url` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `regex` int(11) unsigned NOT NULL DEFAULT '0',
  `position` int(11) unsigned NOT NULL DEFAULT '0',
  `last_count` int(10) unsigned NOT NULL DEFAULT '0',
  `last_access` datetime NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `action_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_code` int(11) unsigned NOT NULL,
  `action_data` mediumtext COLLATE utf8mb4_unicode_ci,
  `match_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`(191)),
  KEY `status` (`status`),
  KEY `regex` (`regex`),
  KEY `group_idpos` (`group_id`,`position`),
  KEY `group` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_redirection_items`
--

INSERT INTO `go_redirection_items` (`id`, `url`, `regex`, `position`, `last_count`, `last_access`, `group_id`, `status`, `action_type`, `action_code`, `action_data`, `match_type`, `title`) VALUES
(1, '/wp/wp-login.php?action=register', 0, 0, 4, '2016-09-03 14:06:29', 1, 'enabled', 'url', 301, '/konto', 'url', NULL);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_redirection_logs`
--

CREATE TABLE IF NOT EXISTS `go_redirection_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `url` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_to` mediumtext COLLATE utf8mb4_unicode_ci,
  `agent` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer` mediumtext COLLATE utf8mb4_unicode_ci,
  `redirection_id` int(11) unsigned DEFAULT NULL,
  `ip` varchar(17) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `redirection_id` (`redirection_id`),
  KEY `ip` (`ip`),
  KEY `group_id` (`group_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_redirection_logs`
--

INSERT INTO `go_redirection_logs` (`id`, `created`, `url`, `sent_to`, `agent`, `referrer`, `redirection_id`, `ip`, `module_id`, `group_id`) VALUES
(1, '2016-09-03 12:06:29', '/wp/wp-login.php?action=register', '/konto', 'Mozilla/5.0 (Linux; Android 6.0.1; ONEPLUS A3003 Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.98 Mobile Safari/537.36', 'https://project08.websupport.dk/opret/', 1, '62.135.173.217', 0, 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_termmeta`
--

CREATE TABLE IF NOT EXISTS `go_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_terms`
--

CREATE TABLE IF NOT EXISTS `go_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=402 ;

--
-- Data dump for tabellen `go_terms`
--

INSERT INTO `go_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Ikke kategoriseret', 'ikke-kategoriseret', 0),
(54, 'Hovedmenu', 'hovedmenu', 0),
(55, 'simple', 'simple', 0),
(56, 'grouped', 'grouped', 0),
(57, 'variable', 'variable', 0),
(58, 'external', 'external', 0),
(59, 'Affald / Genbrug', 'affald-genbrug', 0),
(60, 'Arbejde', 'arbejde', 0),
(61, 'Børn og unge', 'boern-og-unge', 0),
(62, 'Byøkologi', 'byoekologi', 0),
(63, 'Design', 'design', 0),
(64, 'Dyr', 'dyr', 0),
(65, 'Energi', 'energi', 0),
(66, 'Fiskeri', 'fiskeri', 0),
(67, 'Forbrug', 'forbrug', 0),
(68, 'Forurening', 'forurening', 0),
(69, 'Genteknologi', 'genteknologi', 0),
(70, 'Handel (Fair trade)', 'handel-fair-trade', 0),
(71, 'Husholdning (Grøn livstil)', 'husholdning-groen-livstil', 0),
(72, 'Internationalt miljøarbejde', 'internationalt-miljoearbejde', 0),
(73, 'Klima', 'klima', 0),
(74, 'Miljø', 'miljoe', 0),
(75, 'Økologi i storkøkkener', 'oekologi-i-storkoekkener', 0),
(76, 'Økosamfund', 'oekosamfund', 0),
(77, 'Planlægning / strukturudvikling', 'planlaegning-strukturudvikling', 0),
(78, 'Sundhed / helse', 'sundhed-helse', 0),
(79, 'Tekstiler', 'tekstiler', 0),
(80, 'Turisme', 'turisme', 0),
(81, 'Undervisning / uddannelse', 'undervisning-uddannelse', 0),
(82, 'Agenda 21', 'agenda-21', 0),
(83, 'Bæredygtig udvikling', 'baeredygtig-udvikling', 0),
(84, 'Byggeri', 'byggeri', 0),
(85, 'Demokrati / andelsbevægelse', 'demokrati-andelsbevaegelse', 0),
(86, 'Diverse', 'diverse', 0),
(87, 'Eksperimentelle zoner', 'eksperimentelle-zoner', 0),
(88, 'Filosofi', 'filosofi', 0),
(89, 'Fødevarer', 'foedevarer', 0),
(90, 'Forskning', 'forskning', 0),
(91, 'Genbrug', 'genbrug', 0),
(92, 'Grøn virksomhedskultur', 'groen-virksomhedskultur', 0),
(93, 'Havebrug', 'havebrug', 0),
(94, 'Information / Rådgivning', 'information-raadgivning', 0),
(95, 'Kemikalier', 'kemikalier', 0),
(96, 'Landbrug', 'landbrug', 0),
(97, 'Natur', 'natur', 0),
(98, 'Økonomi', 'oekonomi', 0),
(99, 'Permakultur / bioregionalisme', 'permakultur-bioregionalisme', 0),
(100, 'Politik', 'politik', 0),
(101, 'Teknologi', 'teknologi', 0),
(102, 'Transport', 'transport', 0),
(103, 'Uddannelse for Bæredygtig Udvikling', 'uddannelse-for-baeredygtig-udvikling', 0),
(104, 'Vand', 'vand', 0),
(105, 'Agenda 21', 'agenda-21', 0),
(106, 'Agenda 21 i amter', 'agenda-21-i-amter', 0),
(107, 'Agenda 21-grupper', 'agenda-21-grupper', 0),
(108, 'Agenda 21 i kommuner', 'agenda-21-i-kommuner', 0),
(109, 'Bo grønt ude / Overnatning', 'bo-groent-ude-overnatning', 0),
(110, 'Bo grønt ude / Grøn turist', 'groen-turist', 0),
(111, 'Pension', 'pension', 0),
(112, 'Handel og Butikker', 'handel-butikker', 0),
(113, 'Bagerier og bagerbutikker', 'bagerier-og-bagerbutikker', 0),
(114, 'Butikker - non food', 'butikker-non-food', 0),
(115, 'Grøntsags-abonnementsordninger', 'groentsags-abonnementsordninger', 0),
(116, 'Internet-butikker', 'internet-butikker', 0),
(117, 'Torvesalg', 'torvesalg', 0),
(118, 'Gårdbutikker / Stalddørssalg', 'gaardbutikker-stalddoerssalg', 0),
(119, 'Helsekostbutikker / Øko-købmænd', 'helsekostbutikker-oeko-koebmaend', 0),
(120, 'Slagtere', 'slagtere', 0),
(121, 'I praksis', 'i-praksis', 0),
(122, 'Besøgslandbrug', 'besoegslandbrug', 0),
(123, 'Demonstrationsprojekter', 'demonstrationsprojekter', 0),
(124, 'Halmhuse i Danmark', 'halmhuse-i-danmark', 0),
(125, 'Seværdigheder / Grønne turist-besøgsmål', 'sevaerdigheder-groenne-turist-besoegsmaal', 0),
(126, 'Grønne projekter', 'groenne-projekter', 0),
(127, 'Økosamfund i Danmark', 'oekosamfund-i-danmark', 0),
(128, 'Information og Rådgivning', 'information-raadgivning', 0),
(129, 'Energitjenesten', 'energitjenesten', 0),
(130, 'Grønne guider', 'groenne-guider', 0),
(131, 'Miljøfakta / Grønne Råd', 'miljoefakta-groenne-raad', 0),
(132, 'Naturvejledere', 'naturvejledere', 0),
(133, 'Udstillinger om økologi og miljø', 'udstillinger-om-oekologi-og-miljoe', 0),
(134, 'Miljø -og Energikontorer', 'miljoe-og-energikontorer', 0),
(135, 'Miljøinstitutioner - offentlige', 'offentlige-miljoeinstitutioner', 0),
(136, 'Sund By - butikker / netværk', 'sund-by-butikker-netvaerk', 0),
(137, 'Videns- og Miljøcentre', 'videns-og-miljoecentre', 0),
(138, 'Internet og medier', 'internet-medier', 0),
(139, 'Emne- og portal-hjemmesider', 'emne-og-portal-hjemmesider', 0),
(140, 'Miljø og medier', 'miljoe-og-medier', 0),
(141, 'Organisationer', 'organisationer', 0),
(142, '92-gruppen', '92-gruppen', 0),
(143, 'Diverse organisationer', 'diverse-organisationer', 0),
(144, 'Forbruger- og interesse-organisationer', 'forbruger-og-interesse-organisationer', 0),
(145, 'Lokalkomiteer, Danmarks Naturfredningsforening', 'danmarks-naturfredningsforening-lokalkomiteer', 0),
(146, 'Miljøorganisationer - nationale', 'nationale-miljoeorganisationer', 0),
(147, 'Brancheforeninger', 'brancheforeninger', 0),
(148, 'Fonde / Støttemidler', 'fonde-stoettemidler', 0),
(149, 'Internationale organisationer', 'internationale-organisationer', 0),
(150, 'Miljøorganisationer - lokale', 'lokale-miljoeorganisationer', 0),
(151, 'Natur-organisationer', 'natur-organisationer', 0),
(152, 'Personer', 'personer', 0),
(153, 'Foredragsholdere', 'foredragsholdere', 0),
(154, 'Privatpersoner', 'privatpersoner', 0),
(155, 'Uddannelse', 'uddannelse', 0),
(156, 'Grønne uddannelses-steder', 'groenne-uddannelses-steder', 0),
(157, 'Oplysningsforbund, skoler mv.', 'oplysningsforbund-skoler-mv', 0),
(158, 'Miljø og skoletjenester', 'miljoe-og-skoletjenester', 0),
(159, 'Universiteter / Forskningsprojekter', 'universiteter-forskningsprojekter', 0),
(160, 'Virksomheder / Leverandører', 'virksomheder-leverandoerer', 0),
(161, 'Grønne konsulentfirmaer', 'groenne-konsulentfirmaer', 0),
(162, 'Spisesteder', 'spisesteder', 0),
(163, 'Håndværkere', 'haandvaerkere', 0),
(164, 'Firmaer', 'firmaer', 0),
(234, 'Hovedstaden', 'hovedstaden', 0),
(236, 'Albertslund', 'albertslund', 0),
(237, 'Allerød', 'alleroed', 0),
(238, 'Ballerup', 'ballerup', 0),
(239, 'Bornholm', 'bornholm', 0),
(240, 'Brøndby', 'broendby', 0),
(241, 'Dragør', 'dragoer', 0),
(242, 'Egedal', 'egedal', 0),
(243, 'Fredensborg', 'fredensborg', 0),
(244, 'Frederiksberg', 'frederiksberg', 0),
(245, 'Frederikssund', 'frederikssund', 0),
(246, 'Furesø', 'furesoe', 0),
(247, 'Gentofte', 'gentofte', 0),
(248, 'Gladsaxe', 'gladsaxe', 0),
(249, 'Glostrup', 'glostrup', 0),
(250, 'Gribeskov', 'gribeskov', 0),
(251, 'Halsnæs', 'halsnaes', 0),
(252, 'Helsingør', 'helsingoer', 0),
(253, 'Herlev', 'herlev', 0),
(254, 'Hillerød', 'hilleroed', 0),
(255, 'Hvidovre', 'hvidovre', 0),
(256, 'Høje-Taastrup', 'hoeje-taastrup', 0),
(257, 'Hørsholm', 'hoersholm', 0),
(258, 'Ishøj', 'ishoej', 0),
(259, 'København', 'koebenhavn', 0),
(260, 'Lyngby-Taarbæk', 'lyngby-taarbaek', 0),
(261, 'Rudersdal', 'rudersdal', 0),
(262, 'Rødovre', 'roedovre', 0),
(263, 'Tårnby', 'taarnby', 0),
(264, 'Vallensbæk', 'vallensbaek', 0),
(265, 'Syddanmark', 'syddanmark', 0),
(266, 'Midtjylland', 'midtjylland', 0),
(267, 'Nordjylland', 'nordjylland', 0),
(268, 'Sjælland', 'sjaelland', 0),
(269, 'Assens', 'assens', 0),
(270, 'Billund', 'billund', 0),
(271, 'Esbjerg', 'esbjerg', 0),
(272, 'Fanø', 'fanoe', 0),
(273, 'Fredericia', 'fredericia', 0),
(274, 'Faaborg-Midtfyn', 'faaborg-midtfyn', 0),
(275, 'Haderslev', 'haderslev', 0),
(276, 'Kerteminde', 'kerteminde', 0),
(277, 'Kolding', 'kolding', 0),
(278, 'Langeland', 'langeland', 0),
(279, 'Middelfart', 'middelfart', 0),
(280, 'Nordfyn', 'nordfyn', 0),
(281, 'Nyborg', 'nyborg', 0),
(282, 'Odense', 'odense', 0),
(283, 'Svendborg', 'svendborg', 0),
(284, 'Sønderborg', 'soenderborg', 0),
(285, 'Tønder', 'toender', 0),
(286, 'Varde', 'varde', 0),
(287, 'Vejen', 'vejen', 0),
(288, 'Vejle', 'vejle', 0),
(289, 'Aabenraa', 'aabenraa', 0),
(290, 'Ærø', 'aeroe', 0),
(291, 'Faxe', 'faxe', 0),
(292, 'Greve', 'greve', 0),
(293, 'Guldborgsund', 'guldborgsund', 0),
(294, 'Holbæk', 'holbaek', 0),
(295, 'Kalundborg', 'kalundborg', 0),
(296, 'Køge', 'koege', 0),
(297, 'Lejre', 'lejre', 0),
(298, 'Lolland', 'lolland', 0),
(299, 'Næstved', 'naestved', 0),
(300, 'Odsherred', 'odsherred', 0),
(301, 'Ringsted', 'ringsted', 0),
(302, 'Roskilde', 'roskilde', 0),
(303, 'Slagelse', 'slagelse', 0),
(304, 'Solrød', 'solroed', 0),
(305, 'Sorø', 'soroe', 0),
(306, 'Stevns', 'stevns', 0),
(307, 'Vordingborg', 'vordingborg', 0),
(308, 'Brønderslev', 'broenderslev', 0),
(309, 'Fredrikshavn', 'fredrikshavn', 0),
(310, 'Hjørring', 'hjoerring', 0),
(311, 'Jammerbugt', 'jammerbugt', 0),
(312, 'Læsø', 'laesoe', 0),
(313, 'Mariagerfjord', 'mariagerfjord', 0),
(314, 'Morsø', 'morsoe', 0),
(315, 'Rebild', 'rebild', 0),
(316, 'Thisted', 'thisted', 0),
(317, 'Vesthimmerlands', 'vesthimmerlands', 0),
(318, 'Aalborg', 'aalborg', 0),
(319, 'Favrskov', 'favrskov', 0),
(320, 'Hedensted', 'hedensted', 0),
(321, 'Herning', 'herning', 0),
(322, 'Holstebro', 'holstebro', 0),
(323, 'Horsens', 'horsens', 0),
(324, 'Ikast-Brande', 'ikast-brande', 0),
(325, 'Lemvig', 'lemvig', 0),
(326, 'Norddjurs', 'norddjurs', 0),
(327, 'Odder', 'odder', 0),
(328, 'Randers', 'randers', 0),
(329, 'RIngkøbing-Skjern', 'ringkoebing-skjern', 0),
(330, 'Samsø', 'samsoe', 0),
(331, 'Silkeborg', 'silkeborg', 0),
(332, 'Skanderborg', 'skanderborg', 0),
(333, 'Skive', 'skive', 0),
(334, 'Struer', 'struer', 0),
(335, 'Syddjurs', 'syddjurs', 0),
(336, 'Viborg', 'viborg', 0),
(337, 'Aarhus', 'aarhus', 0),
(338, 'Årbog', 'aarbog', 0),
(339, 'Bog', 'bog', 0),
(340, 'Emneorienterede hjemmesider', 'emneorienterede-hjemmesider', 0),
(341, 'Hæfte, pjece, folder', 'haefte-pjece-folder', 0),
(342, 'Lokale Miljø -og naturtidsskrifter', 'lokale-miljoe-og-naturtidsskrifter', 0),
(343, 'Radio / TV', 'radio-tv', 0),
(344, 'Spil', 'spil', 0),
(345, 'Andre Tidsskrifter', 'andre-tidsskrifter', 0),
(346, 'Artikel', 'artikel', 0),
(347, 'CD-medier', 'cd-medier', 0),
(348, 'Film, video', 'film-video', 0),
(349, 'Internet udgivelse', 'internet-udgivelse', 0),
(350, 'Nationale Miljø -og naturtidsskrifter', 'nationale-miljoe-og-naturtidsskrifter', 0),
(351, 'Rapport', 'rapport', 0),
(352, 'Tema-nummer', 'tema-nummer', 0),
(353, 'Affald / Genbrug', 'affald-genbrug', 0),
(354, 'Arbejde', 'arbejde', 0),
(355, 'Børn og unge', 'boern-og-unge', 0),
(356, 'Byøkologi', 'byoekologi', 0),
(357, 'Design', 'design', 0),
(358, 'Dyr', 'dyr', 0),
(359, 'Energi', 'energi', 0),
(360, 'Fiskeri', 'fiskeri', 0),
(361, 'Forbrug', 'forbrug', 0),
(362, 'Forurening', 'forurening', 0),
(363, 'Genteknologi', 'genteknologi', 0),
(364, 'Handel (Fair trade)', 'handel-fair-trade', 0),
(365, 'Husholdning (Grøn livsstil)', 'husholdning-groen-livsstil', 0),
(366, 'Internationalt miljøarbejde', 'internationalt-miljoearbejde', 0),
(367, 'Klima', 'klima', 0),
(368, 'Miljø', 'miljoe', 0),
(369, 'Økologi i storkøkkener', 'oekologi-i-storkoekkener', 0),
(370, 'Økosamfund', 'oekosamfund', 0),
(371, 'Planlægning / strukturudvikling', 'planlaegning-strukturudvikling', 0),
(372, 'Sundhed / helse', 'sundhed-helse', 0),
(373, 'Tekstiler', 'tekstiler', 0),
(374, 'Turisme', 'turisme', 0),
(375, 'Undervisning / uddannelse', 'undervisning-uddannelse', 0),
(376, 'Agenda 21', 'agenda-21', 0),
(377, 'Bæredygtig udvikling', 'baeredygtig-udvikling', 0),
(378, 'Byggeri', 'byggeri', 0),
(379, 'Demokrati / andelsbevægelse', 'demokrati-andelsbevaegelse', 0),
(380, 'Diverse', 'diverse', 0),
(381, 'Eksperimentelle zoner', 'eksperimentelle-zoner', 0),
(382, 'Filosofi', 'filosofi', 0),
(383, 'Fødevarer', 'foedevarer', 0),
(384, 'Forskning', 'forskning', 0),
(385, 'Genbrug', 'genbrug', 0),
(386, 'Grøn virksomhedskultur', 'groen-virksomhedskultur', 0),
(387, 'Havebrug', 'havebrug', 0),
(388, 'Information / Rådgivning', 'information-raadgivning', 0),
(389, 'Kemikalier', 'kemikalier', 0),
(390, 'Landbrug', 'landbrug', 0),
(391, 'Natur', 'natur', 0),
(392, 'Økonomi', 'oekonomi', 0),
(393, 'Permakultur / bioregionalisme', 'permakultur-bioregionalisme', 0),
(394, 'Politik', 'politik', 0),
(395, 'Teknologi', 'teknologi', 0),
(396, 'Transport', 'transport', 0),
(397, 'Uddannelse for Bæredygtig Udvikling', 'uddannelse-for-baeredygtig-udvikling', 0),
(398, 'Vand', 'vand', 0),
(399, 'Top', 'top', 0),
(400, 'Top (2)', 'top-2', 0),
(401, 'l', 'l', 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_term_relationships`
--

CREATE TABLE IF NOT EXISTS `go_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Data dump for tabellen `go_term_relationships`
--

INSERT INTO `go_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 54, 0),
(12, 54, 0),
(22, 54, 0),
(23, 54, 0),
(47, 54, 0),
(97, 54, 0),
(134, 399, 0),
(135, 399, 0),
(136, 399, 0),
(137, 399, 0),
(138, 400, 0),
(139, 400, 0),
(140, 400, 0),
(141, 400, 0),
(211, 54, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `go_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=402 ;

--
-- Data dump for tabellen `go_term_taxonomy`
--

INSERT INTO `go_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(54, 54, 'nav_menu', '', 0, 7),
(55, 55, 'product_type', '', 0, 0),
(56, 56, 'product_type', '', 0, 0),
(57, 57, 'product_type', '', 0, 0),
(58, 58, 'product_type', '', 0, 0),
(59, 59, 'w2dc-tag', '', 0, 0),
(60, 60, 'w2dc-tag', '', 0, 0),
(61, 61, 'w2dc-tag', '', 0, 0),
(62, 62, 'w2dc-tag', '', 0, 0),
(63, 63, 'w2dc-tag', '', 0, 0),
(64, 64, 'w2dc-tag', '', 0, 0),
(65, 65, 'w2dc-tag', '', 0, 0),
(66, 66, 'w2dc-tag', '', 0, 0),
(67, 67, 'w2dc-tag', '', 0, 0),
(68, 68, 'w2dc-tag', '', 0, 0),
(69, 69, 'w2dc-tag', '', 0, 0),
(70, 70, 'w2dc-tag', '', 0, 0),
(71, 71, 'w2dc-tag', '', 0, 0),
(72, 72, 'w2dc-tag', '', 0, 0),
(73, 73, 'w2dc-tag', '', 0, 0),
(74, 74, 'w2dc-tag', '', 0, 0),
(75, 75, 'w2dc-tag', '', 0, 0),
(76, 76, 'w2dc-tag', '', 0, 0),
(77, 77, 'w2dc-tag', '', 0, 0),
(78, 78, 'w2dc-tag', '', 0, 0),
(79, 79, 'w2dc-tag', '', 0, 0),
(80, 80, 'w2dc-tag', '', 0, 0),
(81, 81, 'w2dc-tag', '', 0, 0),
(82, 82, 'w2dc-tag', '', 0, 0),
(83, 83, 'w2dc-tag', '', 0, 0),
(84, 84, 'w2dc-tag', '', 0, 0),
(85, 85, 'w2dc-tag', '', 0, 0),
(86, 86, 'w2dc-tag', '', 0, 0),
(87, 87, 'w2dc-tag', '', 0, 0),
(88, 88, 'w2dc-tag', '', 0, 0),
(89, 89, 'w2dc-tag', '', 0, 0),
(90, 90, 'w2dc-tag', '', 0, 0),
(91, 91, 'w2dc-tag', '', 0, 0),
(92, 92, 'w2dc-tag', '', 0, 0),
(93, 93, 'w2dc-tag', '', 0, 0),
(94, 94, 'w2dc-tag', '', 0, 0),
(95, 95, 'w2dc-tag', '', 0, 0),
(96, 96, 'w2dc-tag', '', 0, 0),
(97, 97, 'w2dc-tag', '', 0, 0),
(98, 98, 'w2dc-tag', '', 0, 0),
(99, 99, 'w2dc-tag', '', 0, 0),
(100, 100, 'w2dc-tag', '', 0, 0),
(101, 101, 'w2dc-tag', '', 0, 0),
(102, 102, 'w2dc-tag', '', 0, 0),
(103, 103, 'w2dc-tag', '', 0, 0),
(104, 104, 'w2dc-tag', '', 0, 0),
(105, 105, 'w2dc-category', '', 0, 0),
(106, 106, 'w2dc-category', '', 105, 0),
(107, 107, 'w2dc-category', '', 105, 0),
(108, 108, 'w2dc-category', '', 105, 0),
(109, 109, 'w2dc-category', '', 0, 0),
(110, 110, 'w2dc-category', '', 109, 0),
(111, 111, 'w2dc-category', '', 109, 0),
(112, 112, 'w2dc-category', '', 0, 0),
(113, 113, 'w2dc-category', '', 112, 0),
(114, 114, 'w2dc-category', '', 112, 0),
(115, 115, 'w2dc-category', '', 112, 0),
(116, 116, 'w2dc-category', '', 112, 0),
(117, 117, 'w2dc-category', '', 112, 0),
(118, 118, 'w2dc-category', '', 112, 0),
(119, 119, 'w2dc-category', '', 112, 0),
(120, 120, 'w2dc-category', '', 112, 0),
(121, 121, 'w2dc-category', '', 0, 0),
(122, 122, 'w2dc-category', '', 121, 0),
(123, 123, 'w2dc-category', '', 121, 0),
(124, 124, 'w2dc-category', '', 121, 0),
(125, 125, 'w2dc-category', '', 121, 0),
(126, 126, 'w2dc-category', '', 121, 0),
(127, 127, 'w2dc-category', '', 121, 0),
(128, 128, 'w2dc-category', '', 0, 0),
(129, 129, 'w2dc-category', '', 128, 0),
(130, 130, 'w2dc-category', '', 128, 0),
(131, 131, 'w2dc-category', '', 128, 0),
(132, 132, 'w2dc-category', '', 128, 0),
(133, 133, 'w2dc-category', '', 128, 0),
(134, 134, 'w2dc-category', '', 128, 0),
(135, 135, 'w2dc-category', '', 128, 0),
(136, 136, 'w2dc-category', '', 128, 0),
(137, 137, 'w2dc-category', '', 128, 0),
(138, 138, 'w2dc-category', '', 0, 0),
(139, 139, 'w2dc-category', '', 138, 0),
(140, 140, 'w2dc-category', '', 138, 0),
(141, 141, 'w2dc-category', '', 0, 0),
(142, 142, 'w2dc-category', '', 141, 0),
(143, 143, 'w2dc-category', '', 141, 0),
(144, 144, 'w2dc-category', '', 141, 0),
(145, 145, 'w2dc-category', '', 141, 0),
(146, 146, 'w2dc-category', '', 141, 0),
(147, 147, 'w2dc-category', '', 141, 0),
(148, 148, 'w2dc-category', '', 141, 0),
(149, 149, 'w2dc-category', '', 141, 0),
(150, 150, 'w2dc-category', '', 141, 0),
(151, 151, 'w2dc-category', '', 141, 0),
(152, 152, 'w2dc-category', '', 0, 0),
(153, 153, 'w2dc-category', '', 152, 0),
(154, 154, 'w2dc-category', '', 152, 0),
(155, 155, 'w2dc-category', '', 0, 0),
(156, 156, 'w2dc-category', '', 155, 0),
(157, 157, 'w2dc-category', '', 155, 0),
(158, 158, 'w2dc-category', '', 155, 0),
(159, 159, 'w2dc-category', '', 155, 0),
(160, 160, 'w2dc-category', '', 0, 0),
(161, 161, 'w2dc-category', '', 160, 0),
(162, 162, 'w2dc-category', '', 160, 0),
(163, 163, 'w2dc-category', '', 160, 0),
(164, 164, 'w2dc-category', '', 160, 0),
(234, 234, 'w2dc-location', '', 0, 0),
(236, 236, 'w2dc-location', '', 234, 0),
(237, 237, 'w2dc-location', '', 234, 0),
(238, 238, 'w2dc-location', '', 234, 0),
(239, 239, 'w2dc-location', '', 234, 0),
(240, 240, 'w2dc-location', '', 234, 0),
(241, 241, 'w2dc-location', '', 234, 0),
(242, 242, 'w2dc-location', '', 234, 0),
(243, 243, 'w2dc-location', '', 234, 0),
(244, 244, 'w2dc-location', '', 234, 0),
(245, 245, 'w2dc-location', '', 234, 0),
(246, 246, 'w2dc-location', '', 234, 0),
(247, 247, 'w2dc-location', '', 234, 0),
(248, 248, 'w2dc-location', '', 234, 0),
(249, 249, 'w2dc-location', '', 234, 0),
(250, 250, 'w2dc-location', '', 234, 0),
(251, 251, 'w2dc-location', '', 234, 0),
(252, 252, 'w2dc-location', '', 234, 0),
(253, 253, 'w2dc-location', '', 234, 0),
(254, 254, 'w2dc-location', '', 234, 0),
(255, 255, 'w2dc-location', '', 234, 0),
(256, 256, 'w2dc-location', '', 234, 0),
(257, 257, 'w2dc-location', '', 234, 0),
(258, 258, 'w2dc-location', '', 234, 0),
(259, 259, 'w2dc-location', '', 234, 0),
(260, 260, 'w2dc-location', '', 234, 0),
(261, 261, 'w2dc-location', '', 234, 0),
(262, 262, 'w2dc-location', '', 234, 0),
(263, 263, 'w2dc-location', '', 234, 0),
(264, 264, 'w2dc-location', '', 234, 0),
(265, 265, 'w2dc-location', '', 0, 0),
(266, 266, 'w2dc-location', '', 0, 0),
(267, 267, 'w2dc-location', '', 0, 0),
(268, 268, 'w2dc-location', '', 0, 0),
(269, 269, 'w2dc-location', '', 265, 0),
(270, 270, 'w2dc-location', '', 265, 0),
(271, 271, 'w2dc-location', '', 265, 0),
(272, 272, 'w2dc-location', '', 265, 0),
(273, 273, 'w2dc-location', '', 265, 0),
(274, 274, 'w2dc-location', '', 265, 0),
(275, 275, 'w2dc-location', '', 265, 0),
(276, 276, 'w2dc-location', '', 265, 0),
(277, 277, 'w2dc-location', '', 265, 0),
(278, 278, 'w2dc-location', '', 265, 0),
(279, 279, 'w2dc-location', '', 265, 0),
(280, 280, 'w2dc-location', '', 265, 0),
(281, 281, 'w2dc-location', '', 265, 0),
(282, 282, 'w2dc-location', '', 265, 0),
(283, 283, 'w2dc-location', '', 265, 0),
(284, 284, 'w2dc-location', '', 265, 0),
(285, 285, 'w2dc-location', '', 265, 0),
(286, 286, 'w2dc-location', '', 265, 0),
(287, 287, 'w2dc-location', '', 265, 0),
(288, 288, 'w2dc-location', '', 265, 0),
(289, 289, 'w2dc-location', '', 265, 0),
(290, 290, 'w2dc-location', '', 265, 0),
(291, 291, 'w2dc-location', '', 268, 0),
(292, 292, 'w2dc-location', '', 268, 0),
(293, 293, 'w2dc-location', '', 268, 0),
(294, 294, 'w2dc-location', '', 268, 0),
(295, 295, 'w2dc-location', '', 268, 0),
(296, 296, 'w2dc-location', '', 268, 0),
(297, 297, 'w2dc-location', '', 268, 0),
(298, 298, 'w2dc-location', '', 268, 0),
(299, 299, 'w2dc-location', '', 268, 0),
(300, 300, 'w2dc-location', '', 268, 0),
(301, 301, 'w2dc-location', '', 268, 0),
(302, 302, 'w2dc-location', '', 268, 0),
(303, 303, 'w2dc-location', '', 268, 0),
(304, 304, 'w2dc-location', '', 268, 0),
(305, 305, 'w2dc-location', '', 268, 0),
(306, 306, 'w2dc-location', '', 268, 0),
(307, 307, 'w2dc-location', '', 268, 0),
(308, 308, 'w2dc-location', '', 267, 0),
(309, 309, 'w2dc-location', '', 267, 0),
(310, 310, 'w2dc-location', '', 267, 0),
(311, 311, 'w2dc-location', '', 267, 0),
(312, 312, 'w2dc-location', '', 267, 0),
(313, 313, 'w2dc-location', '', 267, 0),
(314, 314, 'w2dc-location', '', 267, 0),
(315, 315, 'w2dc-location', '', 267, 0),
(316, 316, 'w2dc-location', '', 267, 0),
(317, 317, 'w2dc-location', '', 267, 0),
(318, 318, 'w2dc-location', '', 267, 0),
(319, 319, 'w2dc-location', '', 266, 0),
(320, 320, 'w2dc-location', '', 266, 0),
(321, 321, 'w2dc-location', '', 266, 0),
(322, 322, 'w2dc-location', '', 266, 0),
(323, 323, 'w2dc-location', '', 266, 0),
(324, 324, 'w2dc-location', '', 266, 0),
(325, 325, 'w2dc-location', '', 266, 0),
(326, 326, 'w2dc-location', '', 266, 0),
(327, 327, 'w2dc-location', '', 266, 0),
(328, 328, 'w2dc-location', '', 266, 0),
(329, 329, 'w2dc-location', '', 266, 0),
(330, 330, 'w2dc-location', '', 266, 0),
(331, 331, 'w2dc-location', '', 266, 0),
(332, 332, 'w2dc-location', '', 266, 0),
(333, 333, 'w2dc-location', '', 266, 0),
(334, 334, 'w2dc-location', '', 266, 0),
(335, 335, 'w2dc-location', '', 266, 0),
(336, 336, 'w2dc-location', '', 266, 0),
(337, 337, 'w2dc-location', '', 266, 0),
(338, 338, 'knowledgebase_category', '', 0, 0),
(339, 339, 'knowledgebase_category', '', 0, 0),
(340, 340, 'knowledgebase_category', '', 0, 0),
(341, 341, 'knowledgebase_category', '', 0, 0),
(342, 342, 'knowledgebase_category', '', 0, 0),
(343, 343, 'knowledgebase_category', '', 0, 0),
(344, 344, 'knowledgebase_category', '', 0, 0),
(345, 345, 'knowledgebase_category', '', 0, 0),
(346, 346, 'knowledgebase_category', '', 0, 0),
(347, 347, 'knowledgebase_category', '', 0, 0),
(348, 348, 'knowledgebase_category', '', 0, 0),
(349, 349, 'knowledgebase_category', '', 0, 0),
(350, 350, 'knowledgebase_category', '', 0, 0),
(351, 351, 'knowledgebase_category', '', 0, 0),
(352, 352, 'knowledgebase_category', '', 0, 0),
(353, 353, 'knowledgebase_tags', '', 0, 0),
(354, 354, 'knowledgebase_tags', '', 0, 0),
(355, 355, 'knowledgebase_tags', '', 0, 0),
(356, 356, 'knowledgebase_tags', '', 0, 0),
(357, 357, 'knowledgebase_tags', '', 0, 0),
(358, 358, 'knowledgebase_tags', '', 0, 0),
(359, 359, 'knowledgebase_tags', '', 0, 0),
(360, 360, 'knowledgebase_tags', '', 0, 0),
(361, 361, 'knowledgebase_tags', '', 0, 0),
(362, 362, 'knowledgebase_tags', '', 0, 0),
(363, 363, 'knowledgebase_tags', '', 0, 0),
(364, 364, 'knowledgebase_tags', '', 0, 0),
(365, 365, 'knowledgebase_tags', '', 0, 0),
(366, 366, 'knowledgebase_tags', '', 0, 0),
(367, 367, 'knowledgebase_tags', '', 0, 0),
(368, 368, 'knowledgebase_tags', '', 0, 0),
(369, 369, 'knowledgebase_tags', '', 0, 0),
(370, 370, 'knowledgebase_tags', '', 0, 0),
(371, 371, 'knowledgebase_tags', '', 0, 0),
(372, 372, 'knowledgebase_tags', '', 0, 0),
(373, 373, 'knowledgebase_tags', '', 0, 0),
(374, 374, 'knowledgebase_tags', '', 0, 0),
(375, 375, 'knowledgebase_tags', '', 0, 0),
(376, 376, 'knowledgebase_tags', '', 0, 0),
(377, 377, 'knowledgebase_tags', '', 0, 0),
(378, 378, 'knowledgebase_tags', '', 0, 0),
(379, 379, 'knowledgebase_tags', '', 0, 0),
(380, 380, 'knowledgebase_tags', '', 0, 0),
(381, 381, 'knowledgebase_tags', '', 0, 0),
(382, 382, 'knowledgebase_tags', '', 0, 0),
(383, 383, 'knowledgebase_tags', '', 0, 0),
(384, 384, 'knowledgebase_tags', '', 0, 0),
(385, 385, 'knowledgebase_tags', '', 0, 0),
(386, 386, 'knowledgebase_tags', '', 0, 0),
(387, 387, 'knowledgebase_tags', '', 0, 0),
(388, 388, 'knowledgebase_tags', '', 0, 0),
(389, 389, 'knowledgebase_tags', '', 0, 0),
(390, 390, 'knowledgebase_tags', '', 0, 0),
(391, 391, 'knowledgebase_tags', '', 0, 0),
(392, 392, 'knowledgebase_tags', '', 0, 0),
(393, 393, 'knowledgebase_tags', '', 0, 0),
(394, 394, 'knowledgebase_tags', '', 0, 0),
(395, 395, 'knowledgebase_tags', '', 0, 0),
(396, 396, 'knowledgebase_tags', '', 0, 0),
(397, 397, 'knowledgebase_tags', '', 0, 0),
(398, 398, 'knowledgebase_tags', '', 0, 0),
(399, 399, 'nav_menu', '', 0, 4),
(400, 400, 'nav_menu', '', 0, 4),
(401, 401, 'w2dc-tag', '', 0, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_usermeta`
--

CREATE TABLE IF NOT EXISTS `go_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=63 ;

--
-- Data dump for tabellen `go_usermeta`
--

INSERT INTO `go_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'thom855j'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'go_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'go_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '0'),
(14, 1, 'session_tokens', 'a:2:{s:64:"3725c62669d4f3a2963c4655fa1602ff702429ba02f25fad16815f1d534e0e37";a:4:{s:10:"expiration";i:1473279449;s:2:"ip";s:11:"80.62.116.8";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473106649;}s:64:"ed321434473dfef4cb324a8e206fb32ee4043b71e90c63b08873caf83a37381b";a:4:{s:10:"expiration";i:1473319105;s:2:"ip";s:11:"80.62.116.8";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473146305;}}'),
(15, 1, 'go_user-settings', 'editor=tinymce&libraryContent=browse&align=none'),
(16, 1, 'go_user-settings-time', '1467827292'),
(17, 1, 'go_dashboard_quick_press_last_post_id', '215'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:6:{i:0;s:26:"add-post-type-w2dc_listing";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";i:3;s:17:"add-w2dc-category";i:4;s:17:"add-w2dc-location";i:5;s:12:"add-w2dc-tag";}'),
(20, 1, 'nav_menu_recently_edited', '54'),
(21, 1, 'manageedit-shop_ordercolumnshidden', 'a:1:{i:0;s:15:"billing_address";}'),
(22, 1, 'wpseo_ignore_tour', '1'),
(23, 1, 'wpseo_seen_about_version', '3.2.5'),
(24, 1, 'metaboxhidden_w2dc_listing', 'a:4:{i:0;s:9:"authordiv";i:1;s:13:"trackbacksdiv";i:2;s:16:"commentstatusdiv";i:3;s:10:"postcustom";}'),
(25, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:0:{}}'),
(26, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(27, 1, 'metaboxhidden_dashboard', 'a:1:{i:0;s:17:"dashboard_primary";}'),
(28, 1, 'closedpostboxes_w2dc_listing', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(29, 1, 'go_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:179:"Overse ikke dine gennemgangsfejl: <a href="https://project08.websupport.dk/wp/wp-admin/admin.php?page=wpseo_search_console&tab=settings">Forbind med Google Search Console her</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:162:"Yoast SEO has been updated to version 3.4.2. <a href="https://project08.websupport.dk/wp/wp-admin/admin.php?page=wpseo_dashboard&intro=1">Find out what''s new!</a>";s:7:"options";a:8:{s:4:"type";s:7:"updated";s:2:"id";s:19:"wpseo-dismiss-about";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(30, 2, 'nickname', 'lmn'),
(31, 2, 'first_name', 'Lars'),
(32, 2, 'last_name', 'Myrthu-Nielsen'),
(33, 2, 'description', ''),
(34, 2, 'rich_editing', 'true'),
(35, 2, 'comment_shortcuts', 'false'),
(36, 2, 'admin_color', 'fresh'),
(37, 2, 'use_ssl', '0'),
(38, 2, 'show_admin_bar_front', 'true'),
(39, 2, 'go_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(40, 2, 'go_user_level', '10'),
(41, 2, '_yoast_wpseo_profile_updated', '1467736381'),
(42, 2, 'dismissed_wp_pointers', ''),
(43, 1, 'closedpostboxes_kbe_knowledgebase', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(44, 1, 'metaboxhidden_kbe_knowledgebase', 'a:1:{i:0;s:7:"slugdiv";}'),
(45, 1, 'closedpostboxes_encyclopedia', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(46, 1, 'metaboxhidden_encyclopedia', 'a:1:{i:0;s:7:"slugdiv";}'),
(47, 1, 'closedpostboxes_yada_wiki', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(48, 1, 'metaboxhidden_yada_wiki', 'a:1:{i:0;s:7:"slugdiv";}'),
(49, 1, 'closedpostboxes_incsub_wiki', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(50, 1, 'metaboxhidden_incsub_wiki', 'a:1:{i:0;s:7:"slugdiv";}'),
(51, 2, 'session_tokens', 'a:1:{s:64:"9914e33b29fad9e875f49a09ce3cebebdfd23eec619c4ab15f22e7ea480ff265";a:4:{s:10:"expiration";i:1469627343;s:2:"ip";s:12:"80.62.116.85";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36";s:5:"login";i:1469454543;}}'),
(52, 2, 'go_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:179:"Overse ikke dine gennemgangsfejl: <a href="https://project08.websupport.dk/wp/wp-admin/admin.php?page=wpseo_search_console&tab=settings">Forbind med Google Search Console her</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:272:"Du bruger stadig Wordpressʼ standardtagline, men selv en tom er sandsynligvis bedre. <a href="https://project08.websupport.dk/wp/wp-admin/customize.php?url=https%3A%2F%2Fproject08.websupport.dk%2Fwp%2Fwp-admin%2Fpost.php">Du kan ændre dette i tilpasning i WordPress</a>.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:28:"wpseo-dismiss-tagline-notice";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(53, 2, 'manageedit-shop_ordercolumnshidden', 'a:1:{i:0;s:15:"billing_address";}'),
(54, 2, 'go_dashboard_quick_press_last_post_id', '195'),
(55, 2, 'closedpostboxes_knowledgebase', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(56, 2, 'metaboxhidden_knowledgebase', 'a:1:{i:0;s:7:"slugdiv";}'),
(57, 2, 'metaboxhidden_w2dc_listing', 'a:4:{i:0;s:9:"authordiv";i:1;s:13:"trackbacksdiv";i:2;s:16:"commentstatusdiv";i:3;s:10:"postcustom";}'),
(58, 2, 'closedpostboxes_w2dc_listing', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(59, 2, 'nav_menu_recently_edited', '54'),
(60, 2, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(61, 2, 'metaboxhidden_nav-menus', 'a:12:{i:0;s:30:"woocommerce_endpoints_nav_link";i:1;s:26:"add-post-type-w2dc_listing";i:2;s:21:"add-post-type-product";i:3;s:27:"add-post-type-knowledgebase";i:4;s:12:"add-post_tag";i:5;s:17:"add-w2dc-category";i:6;s:17:"add-w2dc-location";i:7;s:12:"add-w2dc-tag";i:8;s:15:"add-product_cat";i:9;s:15:"add-product_tag";i:10;s:26:"add-knowledgebase_category";i:11;s:22:"add-knowledgebase_tags";}'),
(62, 1, 'manageedit-eventcolumnshidden', 'a:1:{i:0;s:8:"event-id";}');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_users`
--

CREATE TABLE IF NOT EXISTS `go_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Data dump for tabellen `go_users`
--

INSERT INTO `go_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'thom855j', '$2y$10$tpTM33RhzNIXA7m6656KCOCK0VShZpjGIh35aROa0Anp/IaMogRaW', 'thom855j', 'sde.thom855j@gmail.com', '', '2016-05-06 09:46:20', '', 0, 'thom855j'),
(2, 'lmn', '$2y$10$tkHBxf7LJvnq0b6jVlwOCOhXx0X9xAgs/Jo1DfLCV/x.qWsw5wYNa', 'lmn', 'lmn@eco-net.dk', '', '2016-07-05 16:33:01', '', 0, 'Lars Myrthu-Nielsen');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_content_fields`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_content_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_core_field` tinyint(1) NOT NULL DEFAULT '0',
  `order_num` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `icon_image` varchar(255) NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_configuration_page` tinyint(1) NOT NULL DEFAULT '0',
  `is_search_configuration_page` tinyint(1) NOT NULL DEFAULT '0',
  `is_ordered` tinyint(1) NOT NULL DEFAULT '0',
  `is_hide_name` tinyint(1) NOT NULL DEFAULT '0',
  `on_exerpt_page` tinyint(1) NOT NULL DEFAULT '0',
  `on_listing_page` tinyint(1) NOT NULL DEFAULT '0',
  `on_search_form` tinyint(1) NOT NULL DEFAULT '0',
  `on_map` tinyint(1) NOT NULL DEFAULT '0',
  `advanced_search_form` tinyint(1) NOT NULL,
  `categories` text NOT NULL,
  `options` text NOT NULL,
  `search_options` text NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Data dump for tabellen `go_w2dc_content_fields`
--

INSERT INTO `go_w2dc_content_fields` (`id`, `is_core_field`, `order_num`, `name`, `slug`, `description`, `type`, `icon_image`, `is_required`, `is_configuration_page`, `is_search_configuration_page`, `is_ordered`, `is_hide_name`, `on_exerpt_page`, `on_listing_page`, `on_search_form`, `on_map`, `advanced_search_form`, `categories`, `options`, `search_options`, `group_id`) VALUES
(1, 1, 1, 'Kort beskrivelse', 'summary', '', 'excerpt', '', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '', '', '', 0),
(2, 1, 2, 'Adresse', 'address', '', 'address', 'w2dc-fa-map-marker', 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, '', '', '', 1),
(3, 1, 3, 'Beskrivelse', 'content', '', 'content', '', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '', '', '', 0),
(4, 1, 4, 'Kategorier', 'categories_list', '', 'categories', '', 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '', '', '', 0),
(5, 1, 5, 'Emneord', 'listing_tags', '', 'tags', '', 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, '', '', '', 0),
(6, 0, 6, 'Telefon', 'telefon', '', 'string', 'w2dc-fa-phone', 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 'a:1:{i:0;s:0:"";}', 'a:2:{s:10:"max_length";s:2:"25";s:5:"regex";s:0:"";}', '', 1),
(7, 0, 8, 'Hjemmeside', 'hjemmeside', '', 'website', 'w2dc-fa-globe', 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 'a:1:{i:0;s:0:"";}', 'a:5:{s:8:"is_blank";i:1;s:11:"is_nofollow";i:1;s:13:"use_link_text";i:1;s:17:"default_link_text";s:19:"se vores hjemmeside";s:21:"use_default_link_text";i:1;}', '', 1),
(8, 0, 9, 'Email', 'email', '', 'email', 'w2dc-fa-envelope-o', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '', '', '', 1),
(9, 0, 7, 'Fax', 'fax', '', 'string', 'w2dc-fa-fax', 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 'a:1:{i:0;s:0:"";}', 'a:2:{s:10:"max_length";s:2:"25";s:5:"regex";s:0:"";}', '', 1),
(10, 0, 10, 'Kontaktperson', 'kontaktperson', '', 'string', 'w2dc-fa-user', 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 'a:1:{i:0;s:0:"";}', '', '', 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_content_fields_groups`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_content_fields_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `on_tab` tinyint(1) NOT NULL DEFAULT '0',
  `hide_anonymous` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_w2dc_content_fields_groups`
--

INSERT INTO `go_w2dc_content_fields_groups` (`id`, `name`, `on_tab`, `hide_anonymous`) VALUES
(1, 'Contact Information', 0, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_levels`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_num` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `active_years` tinyint(1) NOT NULL,
  `active_months` tinyint(1) NOT NULL,
  `active_days` tinyint(1) NOT NULL,
  `raiseup_enabled` tinyint(1) NOT NULL,
  `sticky` tinyint(1) NOT NULL,
  `featured` tinyint(1) NOT NULL,
  `nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `listings_own_page` tinyint(1) NOT NULL DEFAULT '1',
  `categories_number` tinyint(1) NOT NULL,
  `unlimited_categories` tinyint(1) NOT NULL,
  `locations_number` tinyint(1) NOT NULL,
  `google_map` tinyint(1) NOT NULL,
  `google_map_markers` tinyint(1) NOT NULL,
  `ratings_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `logo_enabled` tinyint(1) NOT NULL,
  `images_number` tinyint(1) NOT NULL,
  `videos_number` tinyint(1) NOT NULL,
  `categories` text NOT NULL,
  `content_fields` text NOT NULL,
  `upgrade_meta` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`order_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `go_w2dc_levels`
--

INSERT INTO `go_w2dc_levels` (`id`, `order_num`, `name`, `description`, `active_years`, `active_months`, `active_days`, `raiseup_enabled`, `sticky`, `featured`, `nofollow`, `listings_own_page`, `categories_number`, `unlimited_categories`, `locations_number`, `google_map`, `google_map_markers`, `ratings_enabled`, `logo_enabled`, `images_number`, `videos_number`, `categories`, `content_fields`, `upgrade_meta`) VALUES
(1, 1, 'Standard', '', 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 3, 1, 1, 1, 1, 6, 3, '', '', '');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_levels_relationships`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_levels_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`level_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=104 ;

--
-- Data dump for tabellen `go_w2dc_levels_relationships`
--

INSERT INTO `go_w2dc_levels_relationships` (`id`, `post_id`, `level_id`) VALUES
(1, 14, 1),
(2, 17, 1),
(3, 18, 1),
(4, 19, 1),
(5, 29, 1),
(6, 30, 1),
(7, 31, 1),
(8, 32, 1),
(9, 33, 1),
(10, 34, 1),
(11, 35, 1),
(12, 36, 1),
(13, 37, 1),
(14, 39, 1),
(15, 40, 1),
(16, 44, 1),
(17, 49, 1),
(18, 52, 1),
(19, 54, 1),
(20, 55, 1),
(21, 56, 1),
(22, 57, 1),
(23, 58, 1),
(24, 59, 1),
(25, 60, 1),
(26, 61, 1),
(27, 62, 1),
(28, 63, 1),
(29, 64, 1),
(30, 65, 1),
(31, 66, 1),
(32, 67, 1),
(33, 68, 1),
(34, 69, 1),
(35, 70, 1),
(37, 76, 1),
(38, 77, 1),
(39, 78, 1),
(40, 80, 1),
(41, 84, 1),
(42, 90, 1),
(43, 92, 1),
(44, 93, 1),
(46, 101, 1),
(47, 102, 1),
(48, 103, 1),
(50, 122, 1),
(63, 163, 1),
(64, 164, 1),
(65, 165, 1),
(67, 167, 1),
(69, 169, 1),
(73, 173, 1),
(76, 176, 1),
(91, 192, 1),
(92, 193, 1),
(93, 194, 1),
(95, 197, 1),
(98, 202, 1),
(99, 209, 1),
(100, 213, 1),
(101, 214, 1),
(102, 216, 1),
(103, 217, 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_locations_levels`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_locations_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `in_widget` tinyint(1) NOT NULL,
  `in_address_line` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `in_select_widget` (`in_widget`,`in_address_line`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Data dump for tabellen `go_w2dc_locations_levels`
--

INSERT INTO `go_w2dc_locations_levels` (`id`, `name`, `in_widget`, `in_address_line`) VALUES
(1, 'Region', 1, 1),
(2, 'Kommune', 1, 1),
(4, 'By', 0, 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_w2dc_locations_relationships`
--

CREATE TABLE IF NOT EXISTS `go_w2dc_locations_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) NOT NULL,
  `zip_or_postal_index` varchar(25) NOT NULL,
  `additional_info` text NOT NULL,
  `manual_coords` tinyint(1) NOT NULL,
  `map_coords_1` float(10,6) NOT NULL,
  `map_coords_2` float(10,6) NOT NULL,
  `map_icon_file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_wiki_subscriptions`
--

CREATE TABLE IF NOT EXISTS `go_wiki_subscriptions` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `wiki_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_api_keys`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_api_keys` (
  `key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_attribute_taxonomies`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` longtext COLLATE utf8mb4_unicode_ci,
  `attribute_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_downloadable_product_permissions`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(191),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_order_itemmeta`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_order_items`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_payment_tokenmeta`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_payment_tokens`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_payment_tokens` (
  `token_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_sessions`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=16 ;

--
-- Data dump for tabellen `go_woocommerce_sessions`
--

INSERT INTO `go_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(15, '1', 'a:18:{s:4:"cart";s:6:"a:0:{}";s:15:"applied_coupons";s:6:"a:0:{}";s:23:"coupon_discount_amounts";s:6:"a:0:{}";s:27:"coupon_discount_tax_amounts";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:19:"cart_contents_total";i:0;s:5:"total";i:0;s:8:"subtotal";i:0;s:15:"subtotal_ex_tax";i:0;s:9:"tax_total";i:0;s:5:"taxes";s:6:"a:0:{}";s:14:"shipping_taxes";s:6:"a:0:{}";s:13:"discount_cart";i:0;s:17:"discount_cart_tax";i:0;s:14:"shipping_total";i:0;s:18:"shipping_tax_total";i:0;s:9:"fee_total";i:0;s:4:"fees";s:6:"a:0:{}";}', 1473279449);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_shipping_zones`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_shipping_zones` (
  `zone_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_shipping_zone_locations`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) NOT NULL,
  `location_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`(90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_shipping_zone_methods`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) NOT NULL,
  `instance_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `method_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_tax_rates`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`(191)),
  KEY `tax_rate_state` (`tax_rate_state`(191)),
  KEY `tax_rate_class` (`tax_rate_class`(191)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_tax_rate_locations`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`(90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `go_woocommerce_termmeta`
--

CREATE TABLE IF NOT EXISTS `go_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
