<?php

/**
 * Add REST API support to an already registered post type.
 */
add_action( 'init', function() {

  global $wp_post_types;
 
  //be sure to set this to the name of your post type!
  $post_type_name = 'w2dc_listing';
  if( isset( $wp_post_types[ $post_type_name ] ) ) {
    $wp_post_types[$post_type_name]->show_in_rest = true;
    // Optionally customize the rest_base or controller class
    $wp_post_types[$post_type_name]->rest_base = 'go';
    $wp_post_types[$post_type_name]->rest_controller_class = 'WP_REST_Posts_Controller';
  }

}, 25 );


// W2DC postmeta
add_action( 'rest_api_init', function() {
 
	 // register_rest_field ( 'name-of-post-type', 'name-of-field-to-return', array-of-callbacks-and-schema() )
	 register_rest_field( 'w2dc_listing', 'postmeta', array(
	 'get_callback' => function( $object ) {
		 //get the id of the post object array
		 $post_id = $object['id'];
		  
		 //return the post meta
		 return get_post_meta( $post_id );

		},
	 'schema' => null,
	 )
 );

});
 


/**
 * Add REST API support to an already registered taxonomy.
 */

// W2DC categories
add_action( 'init', function() {

  global $wp_taxonomies;
 
  //be sure to set this to the name of your taxonomy!
  $taxonomy_name = 'w2dc-category';
 
  if ( isset( $wp_taxonomies[ $taxonomy_name ] ) ) {
    $wp_taxonomies[ $taxonomy_name ]->show_in_rest = true;
 
    // Optionally customize the rest_base or controller class
    $wp_taxonomies[ $taxonomy_name ]->rest_base = 'go-categories';
    $wp_taxonomies[ $taxonomy_name ]->rest_controller_class = 'WP_REST_Terms_Controller';
  }

}, 25 );


// GO tags
add_action( 'init', function() {

  global $wp_taxonomies;
 
  //be sure to set this to the name of your taxonomy!
  $taxonomy_name = 'w2dc-tag';
 
  if ( isset( $wp_taxonomies[ $taxonomy_name ] ) ) {
    $wp_taxonomies[ $taxonomy_name ]->show_in_rest = true;
 
    // Optionally customize the rest_base or controller class
    $wp_taxonomies[ $taxonomy_name ]->rest_base = 'go-tags';
    $wp_taxonomies[ $taxonomy_name ]->rest_controller_class = 'WP_REST_Terms_Controller';
  }

}, 25 );


// W2DC locations
add_action( 'init', function() {

  global $wp_taxonomies;
 
  //be sure to set this to the name of your taxonomy!
  $taxonomy_name = 'w2dc-location';
 
  if ( isset( $wp_taxonomies[ $taxonomy_name ] ) ) {
    $wp_taxonomies[ $taxonomy_name ]->show_in_rest = true;
 
    // Optionally customize the rest_base or controller class
    $wp_taxonomies[ $taxonomy_name ]->rest_base = 'go-locations';
    $wp_taxonomies[ $taxonomy_name ]->rest_controller_class = 'WP_REST_Terms_Controller';
  }

}, 25 );



/**
 * Custom insert hook for w2dc using the WP Rest API
 */
add_action('rest_insert_w2dc_listing', function (\WP_Post $post, $request, $creating) {
  
  	  // get the WP DB
  	  global $wpdb;   

  	  // get default meta
	  global $w2dc_meta_defaults;

      // get valid meta fields
	  global $w2dc_valid_meta;

  	  // get meta data from post request
      $metas = $request->get_param("meta");	
  
  	  // merge meta data and defaults
      $metas = array_merge($metas, $w2dc_meta_defaults); 
  
  
  	  // validate and insert meta
     if (is_array($metas)) {

     // check for location data
      if(!empty($metas['_address_line_1'])) {


      	// insert location data
	      $locations_relationships = $wpdb->prefix.'w2dc_locations_relationships';  

	      $wpdb->insert( $locations_relationships, array(
	        'post_id' => $post->ID,
			'location_id' => $metas['_location_id'],
			'address_line_1' => $metas['_address_line_1'],
			'zip_or_postal_index' => $metas['_zip_or_postal_index'],
	        ));
       }
                    
      // insert level data
      $levels_relationships = $wpdb->prefix.'w2dc_levels_relationships';

      $wpdb->insert( $levels_relationships, array(
        'post_id' => $post->ID,
		'level_id' => $metas['_listings_level'],
      ));
   }

   	// validate and insert meta data
    foreach ($metas as $name => $value) {

        if(in_array($name, $w2dc_valid_meta)) {

          if(is_array($value)) {

           $value = maybe_serialize($value);

          }
            update_post_meta($post->ID, $name, $value);
        }
    }


}, 10, 3);