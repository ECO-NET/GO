<?php

/**
 * Plugin Name: W2DC REST API
 * Plugin URI: https://github.com/eco-net/go/
 * Description: Custom functions for the W2DC-plugin
 * Author: Thomas Elvin
 * Author URI: http://websuport.dk
 * Version: 1.0
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

  	global $w2dc_meta_defaults;

  	$w2dc_meta_defaults = [
        '_directory_id' => 1,
     	'_listing_status' => 'active',
        '_order_date' => time(),
        '_listing_created' => 1,  
    ];

    global $w2dc_valid_meta;
    
    $w2dc_valid_meta= [
    	'_directory_id',
    	'_listings_level',
    	'_listing_status',
    	'_order_date',
    	'_listing_created',
    	'_contact_email',
    	'_location_id',
    	'_address_line_1',
    	'_address_line_2',
        '_zip_or_postal_index',
        '_content_field_6',
        '_content_field_7',
        '_content_field_8',
        '_content_field_9',
    	'_content_field_10',
    	'_content_field_11',
        '_content_field_13',
        '_content_field_14',
        '_content_field_15',
        '_content_field_16',
        '_content_field_17',
        '_content_field_18',
        '_content_field_22',
        '_content_field_24',
    	'_content_field_25',
    	'_content_field_26',
        '_content_field_27',
    	'_content_field_28',
    	'_content_field_29',
    	'_content_field_30',
    	'_content_field_31',
    	'_content_field_32',
        '_content_field_33',
    	'_content_field_34',
        '_content_field_35',
        '_content_field_36',
    	'_attached_image',
    	'_attached_image_as_logo',
    	'_thumbnail_id',
    ];


require_once('includes/functions.php');

require_once('includes/filters.php');

require_once('includes/actions.php');


