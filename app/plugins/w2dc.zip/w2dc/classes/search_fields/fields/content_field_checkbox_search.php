<?php 

class w2dc_content_field_checkbox_search extends w2dc_content_field_select_search {

}
?>