<?php _e('Listing title:', 'W2DC'); ?> <?php echo $listing_title; ?>

<?php _e('Listing URL:', 'W2DC'); ?> <?php echo $listing_url; ?>

<?php _e('Name:', 'W2DC'); ?> <?php echo $contact_name; ?>

<?php _e('Email:', 'W2DC'); ?> <?php echo $contact_email; ?>

<?php _e('Message:', 'W2DC'); ?>


<?php echo $contact_message; ?>